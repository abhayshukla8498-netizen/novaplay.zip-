package com.example.downloader.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.*
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.downloader.model.DetectedVideo
import com.example.downloader.model.DownloadStatus
import com.example.downloader.model.DownloadedVideoItem
import com.example.downloader.model.VideoQualityOption
import com.example.downloader.viewmodel.DownloaderViewModel
import com.example.downloader.viewmodel.DownloaderViewModelFactory
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloaderScreen(
    onPlayVideo: (File) -> Unit,
    onOpenStatusSaver: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val application = context.applicationContext as android.app.Application
    val downloaderViewModel: DownloaderViewModel = viewModel(
        factory = DownloaderViewModelFactory(application)
    )

    val urlInput by downloaderViewModel.urlInput.collectAsState()
    val isAnalyzing by downloaderViewModel.isAnalyzing.collectAsState()
    val detectedVideo by downloaderViewModel.detectedVideo.collectAsState()
    val selectedQuality by downloaderViewModel.selectedQuality.collectAsState()
    val activeCardDownloadId by downloaderViewModel.activeCardDownloadId.collectAsState()
    val hiddenWebViewUrl by downloaderViewModel.hiddenWebViewUrl.collectAsState()

    val downloadedVideos by downloaderViewModel.downloadedVideos.collectAsState()
    val activeDownloads by downloaderViewModel.activeDownloads.collectAsState()
    val warningMessage by downloaderViewModel.warningMessage.collectAsState()
    val infoMessage by downloaderViewModel.infoMessage.collectAsState()

    val clipboardManager = LocalClipboardManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(warningMessage) {
        warningMessage?.let {
            snackbarHostState.showSnackbar(it)
            downloaderViewModel.clearWarningMessage()
        }
    }

    LaunchedEffect(infoMessage) {
        infoMessage?.let {
            snackbarHostState.showSnackbar(it)
            downloaderViewModel.clearInfoMessage()
        }
    }

    // Find if the currently detected video is downloading in activeDownloads
    val cardActiveDownload = remember(activeCardDownloadId, activeDownloads) {
        activeCardDownloadId?.let { activeDownloads[it] }
    }

    val otherActiveDownloads = remember(cardActiveDownload, activeDownloads) {
        activeDownloads.values.filter {
            (cardActiveDownload == null || it.downloadId != cardActiveDownload.downloadId) &&
            (it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.PAUSED)
        }
    }

    androidx.activity.compose.BackHandler(enabled = detectedVideo != null || isAnalyzing) {
        downloaderViewModel.clearDetectedVideo()
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF10B981), Color(0xFF059669))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Download Now",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Supported Platforms • Reels • Videos • Clips",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.6f)
                            )
                        }
                    }
                },
                actions = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        // 1. WhatsApp Status Saver Icon
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF25D366).copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF25D366).copy(alpha = 0.45f)),
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .clickable {
                                    onOpenStatusSaver?.invoke()
                                }
                                .testTag("downloader_status_saver_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.SaveAlt,
                                    contentDescription = "Status Saver",
                                    tint = Color(0xFF25D366),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // 2. Storage / Downloads Folder Icon
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF00E5FF).copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f)),
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .clickable {
                                    downloaderViewModel.refreshDownloads()
                                }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Folder,
                                    contentDescription = "Downloads Storage",
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // 3. Refresh Downloads Icon
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF10B981).copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.45f)),
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .clickable { downloaderViewModel.refreshDownloads() }
                                .testTag("refresh_downloads_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Refresh Downloads",
                                    tint = Color(0xFF10B981),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F172A)
                )
            )
        },
        containerColor = Color(0xFF0A0F1D)
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp)
            ) {
                // 1. TOP: Clean input box + Paste button + Big "Get Video" button
                item(key = "top_input_section") {
                    TopInputSection(
                        urlInput = urlInput,
                        isAnalyzing = isAnalyzing,
                        onUrlChange = { downloaderViewModel.setUrlInput(it) },
                        onPaste = {
                            val clipText = clipboardManager.getText()?.text?.trim()
                            if (!clipText.isNullOrEmpty()) {
                                downloaderViewModel.setUrlInput(clipText)
                            }
                        },
                        onGetVideo = {
                            keyboardController?.hide()
                            downloaderViewModel.getVideo(urlInput)
                        }
                    )
                }

                // 1.5 WhatsApp Status Saver Shortcut Banner
                if (onOpenStatusSaver != null) {
                    item(key = "whatsapp_status_saver_banner") {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = Color(0xFF0F241D)
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF25D366).copy(alpha = 0.5f), Color(0xFF128C7E).copy(alpha = 0.25f))
                                )
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { onOpenStatusSaver.invoke() }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0xFF25D366), Color(0xFF128C7E))
                                                )
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SaveAlt,
                                            contentDescription = null,
                                            tint = Color.Black,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "Saved Statuses",
                                                fontSize = 13.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = Color(0xFF25D366)
                                            ) {
                                                Text(
                                                    text = "FREE",
                                                    color = Color.Black,
                                                    fontSize = 8.5.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "1-Tap Save Statuses & Media to Gallery",
                                            fontSize = 11.sp,
                                            color = Color(0xFFA7F3D0)
                                        )
                                    }
                                }

                                Button(
                                    onClick = { onOpenStatusSaver.invoke() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF25D366)
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text(
                                        text = "Open",
                                        color = Color.Black,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. MIDDLE: Preview Card (Appears after Get Video)
                if (isAnalyzing) {
                    item(key = "analyzing_card") {
                        AnalyzingCard(
                            onCancel = { downloaderViewModel.clearDetectedVideo() }
                        )
                    }
                } else if (detectedVideo != null) {
                    item(key = "detected_video_card") {
                        VideoPreviewCard(
                            video = detectedVideo!!,
                            selectedQuality = selectedQuality,
                            activeDownload = cardActiveDownload,
                            onQualitySelected = { downloaderViewModel.setSelectedQuality(it) },
                            onDownloadNow = { downloaderViewModel.downloadCurrentVideo() },
                            onCancelDownload = { downloaderViewModel.cancelDownload(it) },
                            onPlayDownloaded = { filePath ->
                                onPlayVideo(File(filePath))
                            }
                        )
                    }
                }

                // Small Disclaimer Text (Mandatory Rule)
                item(key = "disclaimer_text") {
                    Text(
                        text = "For public videos only. Download only public videos with owner permission. We are not responsible for copyright violations.",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.45f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    )
                }

                // 2.5 ACTIVE ONGOING DOWNLOADS SECTION (Animated progress, speed & MB)
                if (otherActiveDownloads.isNotEmpty()) {
                    item(key = "active_downloads_header") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF06B6D4).copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = null,
                                        tint = Color(0xFF06B6D4),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Active Downloads",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = CircleShape,
                                    color = Color(0xFF06B6D4).copy(alpha = 0.25f)
                                ) {
                                    Text(
                                        text = "${otherActiveDownloads.size}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF06B6D4),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Text(
                                text = "Live Progress & Speed",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.5f)
                            )
                        }
                    }

                    items(
                        items = otherActiveDownloads,
                        key = { "active_${it.id}" }
                    ) { task ->
                        AnimatedDownloadProgressCard(
                            download = task,
                            onCancel = { task.downloadId?.let { id -> downloaderViewModel.cancelDownload(id) } },
                            onPlay = { filePath -> onPlayVideo(File(filePath)) }
                        )
                    }
                }

                // 3. BOTTOM: List of Downloaded Videos
                item(key = "downloaded_header") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Folder,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Downloaded Videos",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFF1E293B)
                            ) {
                                Text(
                                    text = "${downloadedVideos.size}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF10B981),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = "/Vidiopen/Downloads",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.5f)
                        )
                    }
                }

                if (downloadedVideos.isEmpty()) {
                    item(key = "empty_downloads") {
                        EmptyDownloadsCard()
                    }
                } else {
                    items(
                        items = downloadedVideos,
                        key = { it.id }
                    ) { item ->
                        DownloadedVideoRow(
                            item = item,
                            onPlay = { onPlayVideo(File(item.filePath)) },
                            onShare = { downloaderViewModel.shareDownloadedVideo(item) },
                            onDelete = { downloaderViewModel.deleteDownloadedVideo(item) }
                        )
                    }
                }
            }

            // Hidden background WebView for silent MP4 detection ONLY while actively analyzing
            if (isAnalyzing && !hiddenWebViewUrl.isNullOrBlank()) {
                HiddenBackgroundWebView(
                    targetUrl = hiddenWebViewUrl,
                    onVideoDetected = { mp4Url, pageTitle, thumbnail ->
                        downloaderViewModel.onVideoDetected(mp4Url, pageTitle, thumbnail)
                    }
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 1. TOP INPUT SECTION
// -----------------------------------------------------------------------------
@Composable
fun TopInputSection(
    urlInput: String,
    isAnalyzing: Boolean,
    onUrlChange: (String) -> Unit,
    onPaste: () -> Unit,
    onGetVideo: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1E293B)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Input Box with Paste Button
            OutlinedTextField(
                value = urlInput,
                onValueChange = onUrlChange,
                placeholder = {
                    Text(
                        text = "Paste video link (Reels, Shorts, Video Clips...)",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.45f)
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = "Link",
                        tint = Color(0xFF10B981)
                    )
                },
                trailingIcon = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        if (urlInput.isNotEmpty()) {
                            IconButton(
                                onClick = { onUrlChange("") },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear",
                                    tint = Color.White.copy(alpha = 0.6f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        // Paste Button
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF334155),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onPaste() }
                                .testTag("paste_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentPaste,
                                    contentDescription = "Paste",
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Paste",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                },
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { onGetVideo() }),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF10B981),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = Color(0xFF0F172A),
                    unfocusedContainerColor = Color(0xFF0F172A)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("video_link_input")
            )

            // -------------------------------------------------------------
            // Ultra-Attractive Supported Platforms Showcase (Reels, Feeds, Posts, Shorts, Videos)
            // -------------------------------------------------------------
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "SUPPORTED PLATFORMS • समर्थित ऐप्स",
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White.copy(alpha = 0.6f),
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "Tap to paste link",
                    fontSize = 10.sp,
                    color = Color(0xFF10B981),
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 5 Media Platform Cards with Generic Icons & Gradient Backgrounds
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. REELS
                SocialPlatformButton(
                    name = "Reels",
                    badge = "Clips",
                    gradient = Brush.linearGradient(
                        listOf(Color(0xFF833AB4), Color(0xFFC13584), Color(0xFFE1306C), Color(0xFFFD1D1D), Color(0xFFFCAF45))
                    ),
                    icon = {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = "Reels",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    onClick = { onPaste() }
                )

                // 2. SOCIAL FEEDS
                SocialPlatformButton(
                    name = "Feeds",
                    badge = "Watch",
                    gradient = Brush.linearGradient(
                        listOf(Color(0xFF1877F2), Color(0xFF0D5BBF))
                    ),
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Public,
                            contentDescription = "Social Feeds",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    onClick = { onPaste() }
                )

                // 3. POSTS
                SocialPlatformButton(
                    name = "Posts",
                    badge = "Trends",
                    gradient = Brush.linearGradient(
                        listOf(Color(0xFF18181B), Color(0xFF09090B))
                    ),
                    borderColor = Color.White.copy(alpha = 0.35f),
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Link,
                            contentDescription = "Posts",
                            tint = Color.White,
                            modifier = Modifier.size(19.dp)
                        )
                    },
                    onClick = { onPaste() }
                )

                // 4. SHORTS
                SocialPlatformButton(
                    name = "Shorts",
                    badge = "Trending",
                    gradient = Brush.linearGradient(
                        listOf(Color(0xFFFF0055), Color(0xFFFF5E00), Color(0xFFFFCC00))
                    ),
                    icon = {
                        Icon(
                            imageVector = Icons.Default.ElectricBolt,
                            contentDescription = "Shorts",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    onClick = { onPaste() }
                )

                // 5. VIDEOS
                SocialPlatformButton(
                    name = "Videos",
                    badge = "Clips",
                    gradient = Brush.linearGradient(
                        listOf(Color(0xFFFF2A54), Color(0xFFFF5722), Color(0xFFFF9800))
                    ),
                    icon = {
                        Icon(
                            imageVector = Icons.Default.VideoLibrary,
                            contentDescription = "Videos",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    onClick = { onPaste() }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Big "Get Video" Button
            Button(
                onClick = onGetVideo,
                enabled = !isAnalyzing && urlInput.isNotBlank(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF2563EB), // Vibrant Royal Blue
                    disabledContainerColor = Color(0xFF1E293B).copy(alpha = 0.7f)
                ),
                contentPadding = PaddingValues(vertical = 14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("get_video_button")
            ) {
                if (isAnalyzing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.5.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Analyzing Video Link...",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Get Video",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// ATTRACTIVE SOCIAL PLATFORM BUTTON (Instagram, Facebook, X, Moj, Josh)
// -----------------------------------------------------------------------------
@Composable
fun SocialPlatformButton(
    name: String,
    badge: String,
    gradient: Brush,
    borderColor: Color = Color.Transparent,
    icon: @Composable () -> Unit,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 2.dp)
    ) {
        // Glowing Icon Badge
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(gradient)
                .then(
                    if (borderColor != Color.Transparent) {
                        Modifier.border(1.dp, borderColor, RoundedCornerShape(13.dp))
                    } else {
                        Modifier.border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(13.dp))
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            icon()
        }

        Spacer(modifier = Modifier.height(5.dp))

        // Platform Name
        Text(
            text = name,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        // Subtitle badge
        Text(
            text = badge,
            fontSize = 9.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White.copy(alpha = 0.55f)
        )
    }
}

// -----------------------------------------------------------------------------
// 2. MIDDLE: ULTRA-ATTRACTIVE REELS SEARCHING RADAR ANIMATION CARD
// -----------------------------------------------------------------------------
@Composable
fun AnalyzingCard(
    onCancel: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "reels_radar_transition")

    // Continuous 360-degree rotation for radar scanner & neon gradient aura
    val scannerAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = LinearEasing)
        ),
        label = "scanner_rotation"
    )

    // Primary pulsating radar wave
    val pulseWave1 by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.45f,
        animationSpec = infiniteRepeatable(
            animation = tween(1700, easing = FastOutSlowInEasing)
        ),
        label = "pulse_wave_1"
    )
    val pulseAlpha1 by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1700, easing = FastOutSlowInEasing)
        ),
        label = "pulse_alpha_1"
    )

    // Secondary delayed pulsating radar wave
    val pulseWave2 by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(2300, delayMillis = 350, easing = FastOutSlowInEasing)
        ),
        label = "pulse_wave_2"
    )
    val pulseAlpha2 by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2300, delayMillis = 350, easing = FastOutSlowInEasing)
        ),
        label = "pulse_alpha_2"
    )

    // Center icon breathing scale
    val centerScale by infiniteTransition.animateFloat(
        initialValue = 0.93f,
        targetValue = 1.07f,
        animationSpec = infiniteRepeatable(
            animation = tween(850, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "center_scale"
    )

    // Beacon blink for "LIVE" indicator
    val beaconAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "beacon_alpha"
    )

    // Shimmer offset for progress line
    val shimmerOffset by infiniteTransition.animateFloat(
        initialValue = -350f,
        targetValue = 700f,
        animationSpec = infiniteRepeatable(
            animation = tween(1900, easing = LinearEasing)
        ),
        label = "shimmer_offset"
    )

    // Dynamic step messages
    val stepMessages = remember {
        listOf(
            "Connecting to Reels Server • रील सर्वर से कनेक्ट हो रहा है",
            "Scanning Video Stream & HD Audio • वीडियो और ऑडियो स्कैन हो रही है",
            "Resolving 1080p / 720p Direct MP4 • बेस्ट क्वालिटी तैयार हो रही है",
            "Almost Done! Finalizing Video Stream • बस कुछ ही सेकंड..."
        )
    }
    var stepIndex by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(2000)
            stepIndex = (stepIndex + 1) % stepMessages.size
        }
    }

    val animatedBorderBrush = remember(scannerAngle) {
        Brush.sweepGradient(
            colors = listOf(
                Color(0xFF833AB4), // Instagram Purple
                Color(0xFFFD1D1D), // Instagram Red
                Color(0xFFFCB045), // Instagram Gold
                Color(0xFF10B981), // Emerald
                Color(0xFF06B6D4), // Cyan
                Color(0xFF833AB4)
            )
        )
    }

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF0F172A).copy(alpha = 0.95f)
        ),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, animatedBorderBrush),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("analyzing_reels_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Top Status Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFFE1306C).copy(alpha = 0.18f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE1306C).copy(alpha = 0.4f))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981).copy(alpha = beaconAlpha))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "LIVE REEL SCANNER",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFFFD54F),
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF1E293B)
                ) {
                    Text(
                        text = "1080P HD DETECT",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF06B6D4),
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 2. Cinematic Reels Hologram Radar Scanner
            Box(
                modifier = Modifier.size(150.dp),
                contentAlignment = Alignment.Center
            ) {
                // Background Radar Waves & Rotating Scanner Beam
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val baseRadius = 38.dp.toPx()

                    // Concentric guide circles
                    drawCircle(
                        color = Color(0xFF334155).copy(alpha = 0.35f),
                        radius = baseRadius * 1.05f,
                        style = Stroke(1.dp.toPx())
                    )
                    drawCircle(
                        color = Color(0xFF334155).copy(alpha = 0.25f),
                        radius = baseRadius * 1.4f,
                        style = Stroke(1.dp.toPx())
                    )
                    drawCircle(
                        color = Color(0xFF334155).copy(alpha = 0.15f),
                        radius = baseRadius * 1.75f,
                        style = Stroke(1.dp.toPx())
                    )

                    // Expanding Pulse Wave 1 (Neon Cyan)
                    drawCircle(
                        color = Color(0xFF06B6D4).copy(alpha = pulseAlpha1),
                        radius = baseRadius * pulseWave1,
                        style = Stroke(2.2.dp.toPx())
                    )

                    // Expanding Pulse Wave 2 (Instagram Magenta)
                    drawCircle(
                        color = Color(0xFFE1306C).copy(alpha = pulseAlpha2),
                        radius = baseRadius * pulseWave2,
                        style = Stroke(2.2.dp.toPx())
                    )

                    // Rotating Radar Scanner Beam Arc
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(
                                Color.Transparent,
                                Color(0xFF06B6D4).copy(alpha = 0.1f),
                                Color(0xFFE1306C).copy(alpha = 0.45f)
                            )
                        ),
                        startAngle = scannerAngle,
                        sweepAngle = 65f,
                        useCenter = true,
                        topLeft = Offset(cx - baseRadius * 1.6f, cy - baseRadius * 1.6f),
                        size = androidx.compose.ui.geometry.Size(baseRadius * 3.2f, baseRadius * 3.2f)
                    )

                    // Orbiting Satellite Sparkle 1
                    val rad1 = (scannerAngle * (PI / 180.0)).toFloat()
                    val p1X = cx + (baseRadius * 1.25f) * cos(rad1)
                    val p1Y = cy + (baseRadius * 1.25f) * sin(rad1)
                    drawCircle(
                        color = Color(0xFF06B6D4),
                        radius = 3.5.dp.toPx(),
                        center = Offset(p1X, p1Y)
                    )

                    // Orbiting Satellite Sparkle 2 (Opposite direction, different radius)
                    val rad2 = ((scannerAngle * 1.4f + 140f) * (PI / 180.0)).toFloat()
                    val p2X = cx + (baseRadius * 1.55f) * cos(rad2)
                    val p2Y = cy + (baseRadius * 1.55f) * sin(rad2)
                    drawCircle(
                        color = Color(0xFFFFD54F),
                        radius = 2.8.dp.toPx(),
                        center = Offset(p2X, p2Y)
                    )
                }

                // Central Breathing Reels Portal Disc
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .graphicsLayer(
                            scaleX = centerScale,
                            scaleY = centerScale
                        )
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color(0xFFFD1D1D),
                                    Color(0xFF833AB4),
                                    Color(0xFF0B0F19)
                                )
                            )
                        )
                        .border(
                            2.dp,
                            Brush.linearGradient(
                                listOf(Color(0xFFFFD54F), Color(0xFFE1306C), Color(0xFF06B6D4))
                            ),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = "Searching Reel",
                        tint = Color.White,
                        modifier = Modifier.size(38.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3. Audio/Video Equalizer Waves
            Row(
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.height(28.dp)
            ) {
                for (i in 0 until 9) {
                    val angleOffset = (scannerAngle * (PI / 180.0) * 1.6 + i * 0.7).toFloat()
                    val barHeight = (sin(angleOffset) * 9f + 14f).coerceIn(5f, 26f).dp

                    Box(
                        modifier = Modifier
                            .width(3.5.dp)
                            .height(barHeight)
                            .clip(CircleShape)
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color(0xFF06B6D4),
                                        Color(0xFF10B981),
                                        Color(0xFFE1306C)
                                    )
                                )
                            )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 4. Live Changing Step Message with Hindi subtitle
            AnimatedContent(
                targetState = stepIndex,
                transitionSpec = {
                    (fadeIn(animationSpec = tween(300)) + slideInVertically { it / 2 })
                        .togetherWith(fadeOut(animationSpec = tween(200)))
                },
                label = "step_message_anim"
            ) { index ->
                Text(
                    text = stepMessages[index],
                    fontSize = 14.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Scanning public video stream • फुल स्पीड से डाउनलोड तैयार हो रहा है",
                fontSize = 11.5.sp,
                color = Color.White.copy(alpha = 0.55f),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 5. High-Tech Shimmering Progress Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E293B))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.35f)
                        .fillMaxHeight()
                        .offset(x = (shimmerOffset * 0.35f).dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color.Transparent,
                                    Color(0xFF10B981),
                                    Color(0xFF06B6D4),
                                    Color(0xFFE1306C),
                                    Color.Transparent
                                )
                            )
                        )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 6. Cancel Search Button
            OutlinedButton(
                onClick = onCancel,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.5f)),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFFFCA5A5)
                ),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                modifier = Modifier.testTag("cancel_search_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Cancel",
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Cancel Search • खोज रद्द करें",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFFCA5A5)
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 2. MIDDLE: VIDEO PREVIEW CARD (THUMBNAIL, TITLE, QUALITY + MB, LIVE SPEED)
// -----------------------------------------------------------------------------
@Composable
fun VideoPreviewCard(
    video: DetectedVideo,
    selectedQuality: String,
    activeDownload: DownloadedVideoItem?,
    onQualitySelected: (String) -> Unit,
    onDownloadNow: () -> Unit,
    onCancelDownload: (Long) -> Unit,
    onPlayDownloaded: (String) -> Unit
) {
    val selectedOption = video.qualities.find { it.label.equals(selectedQuality, ignoreCase = true) }
        ?: video.qualities.firstOrNull()

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1E293B)
        ),
        border = androidx.compose.foundation.BorderStroke(1.2.dp, Color(0xFF10B981).copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("video_preview_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header with badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF10B981).copy(alpha = 0.2f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "VIDEO READY FOR DOWNLOAD",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF10B981)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF334155)
                ) {
                    Text(
                        text = video.sourceDomain.uppercase(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Video Preview + Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Thumbnail / Video Preview Box
                Box(
                    modifier = Modifier
                        .size(width = 104.dp, height = 78.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFF0D9488))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (!video.thumbnail.isNullOrBlank()) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(video.thumbnail)
                                .crossfade(true)
                                .setHeader("User-Agent", "Mozilla/5.0")
                                .build(),
                            contentDescription = "Video Thumbnail",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayCircle,
                                contentDescription = null,
                                tint = Color(0xFF10B981).copy(alpha = 0.85f),
                                modifier = Modifier.size(30.dp)
                            )
                            Text(
                                text = "HD VIDEO",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF38BDF8)
                            )
                        }
                    }
                    // Play icon overlay
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Title and details
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = video.title,
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Format: MP4 Video • Fast Save",
                        fontSize = 12.sp,
                        color = Color(0xFF38BDF8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = Color(0xFF334155).copy(alpha = 0.7f))
            Spacer(modifier = Modifier.height(14.dp))

            // Quality Options with clear MB sizes for each P!
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Choose Quality & Download Size (MB):",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Har resolution (P) ke mutabik MB dekhein aur select karein",
                        fontSize = 11.5.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 2x2 Grid of Quality Cards displaying exact MB for each P!
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val row1 = video.qualities.take(2)
                val row2 = video.qualities.drop(2).take(2)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    row1.forEach { q ->
                        QualityCard(
                            quality = q,
                            isSelected = selectedQuality.equals(q.label, ignoreCase = true),
                            onClick = { onQualitySelected(q.label) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                if (row2.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        row2.forEach { q ->
                            QualityCard(
                                quality = q,
                                isSelected = selectedQuality.equals(q.label, ignoreCase = true),
                                onClick = { onQualitySelected(q.label) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Informational Banner showing exactly how many MB this choice will use!
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF0F172A),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Selected: ${selectedOption?.label ?: selectedQuality} (${selectedOption?.resolution ?: ""}) • Requires ${selectedOption?.estimatedSize ?: ""} storage & data",
                        fontSize = 12.sp,
                        color = Color(0xFFE2E8F0),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Live Animated Download Progress Card (if actively downloading in this card)
            if (activeDownload != null) {
                AnimatedDownloadProgressCard(
                    download = activeDownload,
                    onCancel = { activeDownload.downloadId?.let { onCancelDownload(it) } },
                    onPlay = onPlayDownloaded
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Big Vibrant "Download Now" Button with Selected Resolution & Estimated MB
            Button(
                onClick = onDownloadNow,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF10B981) // Vibrant Emerald
                ),
                contentPadding = PaddingValues(vertical = 15.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_download_now_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                val sizeText = selectedOption?.estimatedSize?.let { " ($it)" } ?: ""
                Text(
                    text = "Download $selectedQuality$sizeText",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

/**
 * Animated network transmission bars (visual equalizer effect)
 */
@Composable
fun NetworkEqualizerBars(
    isActive: Boolean,
    tint: Color = Color(0xFF10B981),
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "equalizer")
    val phase1 by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(420, easing = LinearEasing), RepeatMode.Reverse),
        label = "eq1"
    )
    val phase2 by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(tween(340, easing = LinearEasing), RepeatMode.Reverse),
        label = "eq2"
    )
    val phase3 by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(520, easing = LinearEasing), RepeatMode.Reverse),
        label = "eq3"
    )
    val phase4 by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(380, easing = LinearEasing), RepeatMode.Reverse),
        label = "eq4"
    )

    Row(
        modifier = modifier.height(14.dp),
        horizontalArrangement = Arrangement.spacedBy(2.5.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        val h1 = if (isActive) phase1 else 0.3f
        val h2 = if (isActive) phase2 else 0.4f
        val h3 = if (isActive) phase3 else 0.5f
        val h4 = if (isActive) phase4 else 0.3f

        Box(Modifier.width(3.dp).fillMaxHeight(h1).clip(RoundedCornerShape(2.dp)).background(tint))
        Box(Modifier.width(3.dp).fillMaxHeight(h2).clip(RoundedCornerShape(2.dp)).background(tint))
        Box(Modifier.width(3.dp).fillMaxHeight(h3).clip(RoundedCornerShape(2.dp)).background(tint))
        Box(Modifier.width(3.dp).fillMaxHeight(h4).clip(RoundedCornerShape(2.dp)).background(tint))
    }
}

/**
 * Animated Glowing Progress Bar with smooth progress interpolation and moving light streak
 */
@Composable
fun AnimatedDownloadProgressBar(
    progressPercent: Int,
    modifier: Modifier = Modifier
) {
    val progressFraction = (progressPercent / 100f).coerceIn(0f, 1f)
    val animatedFraction by animateFloatAsState(
        targetValue = progressFraction,
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "smooth_progress"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "shimmer_bar")
    val shimmerOffset by infiniteTransition.animateFloat(
        initialValue = -300f,
        targetValue = 900f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_offset"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(12.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF1E293B))
    ) {
        // Filled bar with animated gradient
        if (animatedFraction > 0f) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction = animatedFraction)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                Color(0xFF0284C7), // Blue
                                Color(0xFF06B6D4), // Cyan
                                Color(0xFF10B981)  // Emerald
                            )
                        )
                    )
            )

            // Shimmer light sweep passing through the progress bar
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction = animatedFraction)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = 0.35f),
                                Color.Transparent
                            ),
                            start = androidx.compose.ui.geometry.Offset(shimmerOffset, 0f),
                            end = androidx.compose.ui.geometry.Offset(shimmerOffset + 180f, 0f)
                        )
                    )
            )
        }
    }
}

@Composable
fun QualityCard(
    quality: VideoQualityOption,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = if (isSelected) Color(0xFF10B981) else Color(0xFF334155)
    val bgColor = if (isSelected) Color(0xFF10B981).copy(alpha = 0.16f) else Color(0xFF0F172A)

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = bgColor,
        border = androidx.compose.foundation.BorderStroke(if (isSelected) 2.dp else 1.dp, borderColor),
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = quality.label,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isSelected) Color(0xFF10B981) else Color.White
                    )
                    if (isSelected) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Selected",
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(5.dp),
                    color = if (isSelected) Color(0xFF10B981).copy(alpha = 0.25f) else Color(0xFF1E293B)
                ) {
                    Text(
                        text = quality.badge,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isSelected) Color(0xFF10B981) else Color(0xFF94A3B8),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.5.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Prominently display MB size in a highlighted chip!
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = if (isSelected) Color(0xFF10B981).copy(alpha = 0.25f) else Color(0xFF0284C7).copy(alpha = 0.18f),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSelected) Color(0xFF10B981).copy(alpha = 0.5f) else Color(0xFF38BDF8).copy(alpha = 0.35f)
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "⚡ ${quality.estimatedSize}",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isSelected) Color(0xFF34D399) else Color(0xFF38BDF8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = quality.resolution,
                fontSize = 10.5.sp,
                color = Color.White.copy(alpha = 0.65f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (quality.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = quality.description,
                    fontSize = 9.5.sp,
                    color = Color(0xFF94A3B8),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun AnimatedDownloadProgressCard(
    download: DownloadedVideoItem,
    onCancel: () -> Unit,
    onPlay: (String) -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "download_shimmer")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    val isCompleted = download.status == DownloadStatus.COMPLETED

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131D31)),
        border = androidx.compose.foundation.BorderStroke(
            1.2.dp,
            if (isCompleted) Color(0xFF10B981) else Color(0xFF06B6D4).copy(alpha = 0.6f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("animated_download_progress_card_${download.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Row 1: Status & Speedometer Pill with Live Equalizer Animation
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                if (isCompleted) Color(0xFF10B981)
                                else Color(0xFF06B6D4).copy(alpha = pulseAlpha)
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isCompleted) "Download Completed! ✅" else "Downloading ${download.qualityLabel} Video",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                // Real-time Speed Meter Pill with animated Equalizer
                if (!isCompleted) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color(0xFF06B6D4).copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF06B6D4).copy(alpha = 0.5f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                        ) {
                            NetworkEqualizerBars(
                                isActive = download.speedBytesPerSec > 0,
                                tint = Color(0xFF38BDF8)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "⚡ ${download.formattedSpeed}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF38BDF8)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Row 2: Live MB Counter, Percentage, and Time Remaining (ETA)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                // Downloaded MB block
                Column {
                    Text(
                        text = "DATA DOWNLOADED",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF94A3B8),
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = download.formattedProgressMb,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF38BDF8) // Vibrant Sky Blue
                    )
                }

                // ETA block
                if (!isCompleted) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "TIME REMAINING",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF94A3B8),
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = Color(0xFFFBBF24),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = download.formattedEta,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFBBF24)
                            )
                        }
                    }
                }

                // Large Progress Percentage
                Text(
                    text = "${download.progressPercent}%",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = if (isCompleted) Color(0xFF10B981) else Color(0xFF10B981)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Animated glowing progress bar with shimmer sweep
            AnimatedDownloadProgressBar(
                progressPercent = download.progressPercent,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Bottom action & directory info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Folder,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "/Vidiopen/Downloads",
                        fontSize = 11.5.sp,
                        color = Color.White.copy(alpha = 0.55f)
                    )
                }

                if (!isCompleted) {
                    OutlinedButton(
                        onClick = onCancel,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFFEF4444)
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.5f)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cancel",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Cancel",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (isCompleted) {
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = { onPlay(download.filePath) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(vertical = 13.dp),
                    modifier = Modifier.fillMaxWidth().testTag("play_downloaded_button_${download.id}")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Play Video Now in Vidiopen",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.5.sp
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 3. BOTTOM: DOWNLOADED VIDEOS LIST & EMPTY STATE
// -----------------------------------------------------------------------------
@Composable
fun EmptyDownloadsCard() {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Outlined.CloudDownload,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.4f),
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "No Downloaded Videos Yet",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Paste a link above from supported platforms and click 'Get Video' to download.",
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.55f),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun DownloadedVideoRow(
    item: DownloadedVideoItem,
    onPlay: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("downloaded_item_${item.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Video Thumbnail / Play Box
            Box(
                modifier = Modifier
                    .size(width = 72.dp, height = 54.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F172A))
                    .clickable { onPlay() },
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(File(item.filePath))
                        .crossfade(true)
                        .build(),
                    contentDescription = item.fileName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                // Play overlay
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.5f),
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = Color(0xFF10B981),
                        modifier = Modifier.padding(4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // File Name & Details
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onPlay() }
            ) {
                Text(
                    text = item.fileName.removeSuffix(".mp4"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.formattedSize,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF10B981)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "•",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.4f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(item.dateDownloaded)),
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.45f)
                    )
                }
            }

            // Actions: Share & Delete
            IconButton(
                onClick = onShare,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share",
                    tint = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = Color(0xFFEF4444).copy(alpha = 0.8f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// HIDDEN BACKGROUND WEBVIEW (SNIFFS MP4 / STREAMS FROM TARGET URL)
// -----------------------------------------------------------------------------
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun HiddenBackgroundWebView(
    targetUrl: String?,
    onVideoDetected: (url: String, title: String?, thumbnail: String?) -> Unit
) {
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var loadedTargetUrl by remember { mutableStateOf<String?>(null) }
    var cachedPageTitle by remember { mutableStateOf<String?>(null) }
    val mainHandler = remember { android.os.Handler(android.os.Looper.getMainLooper()) }

    DisposableEffect(Unit) {
        onDispose {
            try {
                webViewInstance?.stopLoading()
                webViewInstance?.onPause()
            } catch (_: Exception) {}
        }
    }

    // Kept on-screen with compact dimensions and near-zero alpha so Chromium fully executes DOM scripts and media observers
    Box(
        modifier = Modifier
            .size(320.dp, 240.dp)
            .alpha(0.005f)
    ) {
        AndroidView<WebView>(
            factory = { ctx ->
                // Ensure Chromium cache folders
                try {
                    val codeCacheDir = File(ctx.cacheDir, "WebView/Default/HTTP Cache/Code Cache")
                    File(codeCacheDir, "wasm").mkdirs()
                    File(codeCacheDir, "js").mkdirs()
                } catch (_: Exception) {}

                try {
                    WebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(1080, 720)

                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            databaseEnabled = true
                            mediaPlaybackRequiresUserGesture = false
                            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
                            loadWithOverviewMode = true
                            useWideViewPort = true
                            setSupportMultipleWindows(false)
                            javaScriptCanOpenWindowsAutomatically = false
                            cacheMode = WebSettings.LOAD_DEFAULT
                        }

                        val cookieMgr = android.webkit.CookieManager.getInstance()
                        cookieMgr.setAcceptCookie(true)
                        cookieMgr.setAcceptThirdPartyCookies(this, true)

                        var discoveredThumbnail: String? = null

                        // JavaScript Interface for DOM sniffing (executed on background JavaBridge thread)
                        addJavascriptInterface(
                            object {
                                @JavascriptInterface
                                fun onMediaFound(videoSrc: String, pageTitle: String?, thumbnail: String?) {
                                    if (videoSrc.isNotBlank() && !videoSrc.startsWith("blob:") && !videoSrc.startsWith("data:")) {
                                        val cleanMediaUrl = com.example.downloader.util.VideoExtractorUtil.cleanVideoUrl(videoSrc)
                                        val effectiveThumb = thumbnail?.takeIf { it.isNotBlank() } ?: discoveredThumbnail
                                        mainHandler.post {
                                            onVideoDetected(cleanMediaUrl, pageTitle ?: cachedPageTitle, effectiveThumb)
                                        }
                                    }
                                }
                            },
                            "VidiopenSniffer"
                        )

                        webChromeClient = object : WebChromeClient() {
                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                super.onReceivedTitle(view, title)
                                if (!title.isNullOrBlank()) {
                                    cachedPageTitle = title
                                }
                            }

                            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                                return false
                            }
                        }

                        webViewClient = object : WebViewClient() {
                            // CRITICAL: Block external intent schemes (intent://, instagram://, fb://, market://)
                            // This stops ActivityNotFoundException crashes and prevents kicking the user out of the app!
                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                val url = request?.url?.toString() ?: return true
                                if (!url.startsWith("http://", ignoreCase = true) && !url.startsWith("https://", ignoreCase = true)) {
                                    return true // Block non-http/https intent schemes completely
                                }
                                return false
                            }

                            // CRITICAL: Prevent host app process termination if Chromium renderer exits
                            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                                timber.log.Timber.w("HiddenBackgroundWebView: render process exited gracefully")
                                try {
                                    view?.destroy()
                                } catch (_: Exception) {}
                                return true
                            }

                            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                                super.onReceivedError(view, request, error)
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                if (!view?.title.isNullOrBlank()) {
                                    cachedPageTitle = view?.title
                                }
                                // Inject HTML5 video & meta sniffer script with MutationObserver and interval polling for dynamic feeds
                                val js = """
                                    (function() {
                                        function scanMedia() {
                                            try {
                                                var title = document.title || '';
                                                var thumb = '';
                                                var ogImg = document.querySelector('meta[property="og:image"], meta[name="twitter:image"], link[rel="image_src"]');
                                                if (ogImg) thumb = ogImg.content || ogImg.href || '';

                                                // 1. Check JSON-LD structured data
                                                var jsonLdScripts = document.querySelectorAll('script[type="application/ld+json"]');
                                                for (var j = 0; j < jsonLdScripts.length; j++) {
                                                    try {
                                                        var data = JSON.parse(jsonLdScripts[j].innerText);
                                                        var vUrl = data.contentUrl || (data.video && data.video.contentUrl);
                                                        var tUrl = data.thumbnailUrl || (data.video && data.video.thumbnailUrl) || data.image;
                                                        if (vUrl && vUrl.indexOf('http') === 0) {
                                                            window.VidiopenSniffer.onMediaFound(vUrl, data.name || title, tUrl || thumb);
                                                            return true;
                                                        }
                                                    } catch(e) {}
                                                }

                                                // 2. Check OpenGraph & Twitter player stream
                                                var ogVideo = document.querySelector('meta[property="og:video:secure_url"], meta[property="og:video"], meta[property="og:video:url"], meta[name="twitter:player:stream"]');
                                                if (ogVideo && ogVideo.content && ogVideo.content.indexOf('blob:') !== 0 && ogVideo.content.indexOf('http') === 0) {
                                                    window.VidiopenSniffer.onMediaFound(ogVideo.content, title, thumb);
                                                    return true;
                                                }

                                                // 3. Scan script tags for video_url / playable_url
                                                var scripts = document.getElementsByTagName('script');
                                                for (var s = 0; s < scripts.length; s++) {
                                                    var sText = scripts[s].innerText || '';
                                                    if (sText.indexOf('video_url') !== -1 || sText.indexOf('playable_url') !== -1 || sText.indexOf('browser_native_hd_url') !== -1) {
                                                        var m = sText.match(/"(?:playable_url_quality_hd|browser_native_hd_url|video_url|playable_url|browser_native_sd_url)":\s*"([^"]+)"/);
                                                        if (m && m[1]) {
                                                            var cleanUrl = m[1].replace(/\\u0026/g, '&').replace(/\\\//g, '/');
                                                            var thumbMatch = sText.match(/"(?:display_url|thumbnail_url)":\s*"([^"]+)"/);
                                                            var cleanThumb = thumbMatch ? thumbMatch[1].replace(/\\u0026/g, '&').replace(/\\\//g, '/') : thumb;
                                                            window.VidiopenSniffer.onMediaFound(cleanUrl, title, cleanThumb);
                                                            return true;
                                                        }
                                                    }
                                                }

                                                // 4. Check HTML5 video elements (currentSrc, src, or source tags)
                                                var videos = document.getElementsByTagName('video');
                                                for (var i = 0; i < videos.length; i++) {
                                                    var v = videos[i];
                                                    var vSrc = v.currentSrc || v.src;
                                                    var vPoster = v.poster || thumb;
                                                    if (vSrc && vSrc.indexOf('blob:') !== 0 && vSrc.indexOf('http') === 0) {
                                                        window.VidiopenSniffer.onMediaFound(vSrc, title, vPoster);
                                                        return true;
                                                    }
                                                    var sources = v.getElementsByTagName('source');
                                                    for (var k = 0; k < sources.length; k++) {
                                                        var sSrc = sources[k].src;
                                                        if (sSrc && sSrc.indexOf('blob:') !== 0 && sSrc.indexOf('http') === 0) {
                                                            window.VidiopenSniffer.onMediaFound(sSrc, title, vPoster);
                                                            return true;
                                                        }
                                                    }
                                                }
                                            } catch(e) {}
                                            return false;
                                        }

                                        if (!scanMedia()) {
                                            var count = 0;
                                            var timer = setInterval(function() {
                                                count++;
                                                if (scanMedia() || count > 14) clearInterval(timer);
                                            }, 800);
                                            var obs = new MutationObserver(function() {
                                                if (scanMedia()) {
                                                    clearInterval(timer);
                                                    obs.disconnect();
                                                }
                                            });
                                            obs.observe(document.body || document.documentElement, { childList: true, subtree: true });
                                            setTimeout(function() { obs.disconnect(); clearInterval(timer); }, 15000);
                                        }
                                    })();
                                """.trimIndent()
                                view?.evaluateJavascript(js, null)
                            }

                            override fun shouldInterceptRequest(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): WebResourceResponse? {
                                val reqUrl = request?.url?.toString()
                                if (!reqUrl.isNullOrBlank()) {
                                    val lower = reqUrl.lowercase()
                                    // Capture high-quality thumbnail candidate from image requests
                                    val isImg = (lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") ||
                                            lower.endsWith(".webp") || lower.contains("/v/t51.") || lower.contains("format=jpg") ||
                                            lower.contains("format=webp") || lower.contains("format=png")) &&
                                            !lower.contains("favicon") && !lower.contains("icon") && !lower.contains("avatar") && !lower.contains("logo") &&
                                            !lower.contains("pixel") && !lower.contains("1x1")

                                    if (isImg) {
                                        discoveredThumbnail = reqUrl
                                    } else {
                                        val isFbOrInsta = (lower.contains("fbcdn.net") || lower.contains("cdninstagram.com")) &&
                                                (lower.contains(".mp4") || lower.contains("/v/") || lower.contains("bytestart=") || lower.contains("/o1/v/")) &&
                                                !lower.endsWith(".jpg") && !lower.endsWith(".jpeg") && !lower.endsWith(".png") && !lower.endsWith(".webp") &&
                                                !lower.contains("format=jpg") && !lower.contains("format=webp")

                                        val isMedia = (isFbOrInsta ||
                                                lower.contains(".mp4") || lower.contains(".webm") || lower.contains(".mkv") || lower.contains(".mov") || lower.contains(".m4v") ||
                                                lower.contains("mime_type=video") ||
                                                (lower.contains("twimg.com") && lower.contains("video")) ||
                                                (lower.contains("tiktokcdn.com") && lower.contains("video")) ||
                                                lower.contains("v.redd.it") ||
                                                (lower.contains("pinimg.com") && lower.contains("video")) ||
                                                (lower.contains("moj") && lower.contains(".mp4")) ||
                                                (lower.contains("josh") && lower.contains(".mp4"))) &&
                                                !lower.contains("youtube.com") && !lower.contains("youtu.be") && !lower.contains("googlevideo.com") &&
                                                !lower.startsWith("blob:") && !lower.startsWith("data:") &&
                                                !lower.contains("mime_type=audio")

                                        if (isMedia) {
                                            val cleanMediaUrl = com.example.downloader.util.VideoExtractorUtil.cleanVideoUrl(reqUrl)
                                            mainHandler.post {
                                                onVideoDetected(cleanMediaUrl, cachedPageTitle, discoveredThumbnail)
                                            }
                                        }
                                    }
                                }
                                return super.shouldInterceptRequest(view, request)
                            }
                        }

                        webViewInstance = this
                    }
                } catch (e: Exception) {
                    timber.log.Timber.e(e, "Could not initialize WebView")
                    WebView(ctx)
                }
            },
            update = { webView ->
                if (!targetUrl.isNullOrBlank()) {
                    val normalizedUrl = if (targetUrl.contains("instagram.com", ignoreCase = true) || targetUrl.contains("instagr.am", ignoreCase = true)) {
                        val code = com.example.downloader.util.VideoExtractorUtil.extractInstagramShortcode(targetUrl)
                        if (code != null) "https://www.instagram.com/reel/$code/" else targetUrl.substringBefore("?")
                    } else {
                        targetUrl
                    }
                    if (normalizedUrl != loadedTargetUrl) {
                        loadedTargetUrl = normalizedUrl
                        webView.loadUrl(normalizedUrl)
                    }
                }
            },
            onRelease = { webView ->
                try {
                    webView.stopLoading()
                    webView.onPause()
                } catch (_: Exception) {}
            }
        )
    }
}
