package com.example.downloader.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.io.File
import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

data class ExtractedVideoResult(
    val videoUrl: String,
    val title: String,
    val thumbnail: String?,
    val sourceDomain: String,
    val hdUrl: String? = null,
    val sdUrl: String? = null,
    val contentLengthBytes: Long = 0L
)

object VideoExtractorUtil {

    private val okHttpClient = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .callTimeout(3, TimeUnit.SECONDS)
        .build()

    // Non-redirecting client to trace redirects manually when needed
    private val noRedirectClient = OkHttpClient.Builder()
        .followRedirects(false)
        .followSslRedirects(false)
        .connectTimeout(2, TimeUnit.SECONDS)
        .readTimeout(2, TimeUnit.SECONDS)
        .build()

    private const val MOBILE_USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Mobile; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"
    private const val DESKTOP_USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
    private const val IOS_USER_AGENT =
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
    private const val CRAWLER_USER_AGENT =
        "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"

    /**
     * Cleans range and chunk probe parameters from video stream URLs.
     * Prevents servers from serving only 1KB-64KB range fragments instead of the complete MP4 video.
     */
    fun cleanVideoUrl(url: String): String {
        var clean = url.trim()
        clean = clean.replace(Regex("&?bytestart=\\d+"), "")
        clean = clean.replace(Regex("&?byteend=\\d+"), "")
        clean = clean.replace(Regex("&?range=\\d+-\\d+"), "")
        clean = clean.replace(Regex("\\?&"), "?").replace(Regex("&&+"), "&").trimEnd('?', '&')
        return clean
    }

    /**
     * Extracts a video frame thumbnail using Android's built-in MediaMetadataRetriever
     * and saves it to app cache so Coil can immediately render it without black/blank boxes.
     */
    suspend fun extractFrameThumbnail(context: android.content.Context, videoUrl: String): String? = withContext(Dispatchers.IO) {
        var retriever: android.media.MediaMetadataRetriever? = null
        try {
            retriever = android.media.MediaMetadataRetriever()
            val headers = HashMap<String, String>()
            headers["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/128.0.0.0 Mobile Safari/537.36"
            retriever.setDataSource(videoUrl, headers)
            val bitmap = retriever.getFrameAtTime(1_000_000, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.getFrameAtTime(0)
            if (bitmap != null) {
                val cacheDir = File(context.cacheDir, "video_thumbs")
                if (!cacheDir.exists()) cacheDir.mkdirs()
                val thumbFile = File(cacheDir, "thumb_${System.currentTimeMillis()}_${(100..999).random()}.jpg")
                java.io.FileOutputStream(thumbFile).use { out ->
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out)
                }
                thumbFile.absolutePath
            } else null
        } catch (_: Exception) {
            null
        } finally {
            try { retriever?.release() } catch (_: Exception) {}
        }
    }

    /**
     * Robust URL extraction that handles:
     * - "Check this reel out: https://www.instagram.com/reel/C8xyz123/?igsh=abc"
     * - "instagram.com/reel/C8xyz123/" (no protocol)
     * - "fb.watch/xyz123"
     * - Punctuation, trailing brackets, quotes, query parameters
     */
    fun extractCleanUrl(input: String): String? {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return null

        // 1. Look for explicit http(s) URL
        val urlPattern = Pattern.compile("(https?://[^\\s\"'<>]+)", Pattern.CASE_INSENSITIVE)
        val matcher = urlPattern.matcher(trimmed)
        if (matcher.find()) {
            val found = matcher.group(1)?.trim() ?: return null
            return cleanUrlPunctuation(found)
        }

        // 2. Look for known social domains without protocol in arbitrary text
        val domainPattern = Pattern.compile(
            "((?:[a-zA-Z0-9-]+\\.)*(?:instagram\\.com|facebook\\.com|fb\\.watch|fb\\.com|twitter\\.com|x\\.com|pin\\.it|pinterest\\.com|tiktok\\.com|reddit\\.com|threads\\.net|mojapp\\.in|myjosh\\.in|sharechat\\.com|dailymotion\\.com|dai\\.ly|vimeo\\.com)[^\\s\"'<>]*)",
            Pattern.CASE_INSENSITIVE
        )
        val domainMatcher = domainPattern.matcher(trimmed)
        if (domainMatcher.find()) {
            val found = domainMatcher.group(1)?.trim() ?: return null
            return "https://${cleanUrlPunctuation(found)}"
        }

        // 3. Fallback for simple domain/path string without spaces
        if (!trimmed.contains(" ") && trimmed.contains(".")) {
            val clean = trimmed.removePrefix("https://").removePrefix("http://")
            return "https://${cleanUrlPunctuation(clean)}"
        }

        return null
    }

    private fun cleanUrlPunctuation(url: String): String {
        return url.trimEnd('.', ',', ')', ']', '}', '"', '\'', '>', ';')
    }

    /**
     * Resolves shortlinks (e.g. fb.watch, pin.it, bit.ly, t.co, vt.tiktok.com) to their canonical final URL.
     */
    private fun resolveShortlink(initialUrl: String): String {
        var currentUrl = initialUrl
        val shortDomains = listOf("fb.watch", "bit.ly", "tinyurl.com", "t.co", "pin.it", "vt.tiktok.com", "vm.tiktok.com", "dai.ly", "instagram.com/share", "instagram.com/reels/share")
        if (!shortDomains.any { currentUrl.contains(it, ignoreCase = true) }) {
            return currentUrl
        }

        try {
            var hops = 0
            while (hops < 5) {
                hops++
                val request = Request.Builder()
                    .url(currentUrl)
                    .header("User-Agent", DESKTOP_USER_AGENT)
                    .build()
                val response = noRedirectClient.newCall(request).execute()
                val code = response.code
                if (code in 300..399) {
                    val location = response.header("Location")
                    response.close()
                    if (!location.isNullOrBlank()) {
                        currentUrl = if (location.startsWith("http")) location else URI(currentUrl).resolve(location).toString()
                    } else {
                        break
                    }
                } else {
                    response.close()
                    break
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "resolveShortlink error for $initialUrl")
        }
        return currentUrl
    }

    suspend fun extractVideo(rawUrl: String): ExtractedVideoResult? = withContext(Dispatchers.IO) {
        val initialUrl = extractCleanUrl(rawUrl) ?: return@withContext null

        // Rule: Strictly enforce NO YouTube downloader anywhere
        if (isYouTube(initialUrl)) {
            return@withContext null
        }

        // Expand shortlinks (fb.watch, pin.it, etc.)
        val targetUrl = resolveShortlink(initialUrl)
        if (isYouTube(targetUrl)) {
            return@withContext null
        }

        // 1. Direct media file check (.mp4, .webm, .mkv, .mov, .3gp)
        if (isDirectMediaUrl(targetUrl)) {
            val fileName = targetUrl.substringAfterLast("/").substringBefore("?").ifBlank { "video.mp4" }
            val length = checkContentLength(targetUrl)
            return@withContext ExtractedVideoResult(
                videoUrl = targetUrl,
                title = cleanTitle(fileName),
                thumbnail = null,
                sourceDomain = extractDomain(targetUrl),
                hdUrl = targetUrl,
                sdUrl = targetUrl,
                contentLengthBytes = length
            )
        }

        val domain = extractDomain(targetUrl).lowercase()

        // 2. Platform-Specific Extractors
        try {
            when {
                domain.contains("instagram") -> {
                    val igResult = extractInstagram(targetUrl)
                    if (igResult != null) return@withContext igResult
                }
                domain.contains("facebook") -> {
                    val fbResult = extractFacebook(targetUrl)
                    if (fbResult != null) return@withContext fbResult
                }
                domain.contains("twitter") || domain.contains("x") -> {
                    val twResult = extractTwitter(targetUrl)
                    if (twResult != null) return@withContext twResult
                }
                domain.contains("pinterest") -> {
                    val pinResult = extractPinterest(targetUrl)
                    if (pinResult != null) return@withContext pinResult
                }
                domain.contains("reddit") -> {
                    val redditResult = extractReddit(targetUrl)
                    if (redditResult != null) return@withContext redditResult
                }
                domain.contains("tiktok") -> {
                    val ttResult = extractTikTok(targetUrl)
                    if (ttResult != null) return@withContext ttResult
                }
                domain.contains("moj") || domain.contains("josh") || domain.contains("sharechat") -> {
                    val indianAppResult = extractMojAndJosh(targetUrl)
                    if (indianAppResult != null) return@withContext indianAppResult
                }
                domain.contains("vimeo") -> {
                    val vimeoResult = extractVimeo(targetUrl)
                    if (vimeoResult != null) return@withContext vimeoResult
                }
                domain.contains("drive.google") -> {
                    val gdriveResult = extractGoogleDrive(targetUrl)
                    if (gdriveResult != null) return@withContext gdriveResult
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Platform-specific extractor error for $targetUrl")
        }

        // 3. Universal HTML5 & OpenGraph Scraper (works for any web page)
        try {
            val mobileResult = fetchAndParseHtml(targetUrl, MOBILE_USER_AGENT)
            if (mobileResult != null) return@withContext mobileResult

            val desktopResult = fetchAndParseHtml(targetUrl, DESKTOP_USER_AGENT)
            if (desktopResult != null) return@withContext desktopResult
        } catch (e: Exception) {
            Timber.w(e, "Universal HTML scraper error for $targetUrl")
        }

        // 4. Public Open Video Resolver API Fallback (Handles complex JS-obfuscated reels/posts)
        try {
            val publicResult = extractWithPublicResolverFallback(targetUrl)
            if (publicResult != null) return@withContext publicResult
        } catch (e: Exception) {
            Timber.w(e, "Public resolver fallback error for $targetUrl")
        }

        null
    }

    private fun isYouTube(url: String): Boolean {
        return url.contains("youtube.com", ignoreCase = true) ||
                url.contains("youtu.be", ignoreCase = true) ||
                url.contains("googlevideo.com", ignoreCase = true)
    }

    private fun isDirectMediaUrl(url: String): Boolean {
        val cleanPath = url.substringBefore("?").lowercase()
        return cleanPath.endsWith(".mp4") ||
                cleanPath.endsWith(".webm") ||
                cleanPath.endsWith(".mkv") ||
                cleanPath.endsWith(".mov") ||
                cleanPath.endsWith(".3gp")
    }

    private fun checkContentLength(url: String): Long {
        return try {
            val req = Request.Builder().url(url).head().build()
            val resp = okHttpClient.newCall(req).execute()
            val len = resp.header("Content-Length")?.toLongOrNull() ?: 0L
            resp.close()
            len
        } catch (_: Exception) {
            0L
        }
    }

    // =========================================================================
    // =========================================================================
    // 1. INSTAGRAM EXTRACTOR (Crawler OpenGraph, Embeds, GraphQL, and Public Web APIs)
    // =========================================================================
    private fun extractInstagram(targetUrl: String): ExtractedVideoResult? {
        val shortcode = extractInstagramShortcode(targetUrl) ?: return null

        // Vector A: Desktop fetch (Instagram desktop serves complete OpenGraph and JSON-LD for public posts)
        try {
            val pageUrl = "https://www.instagram.com/reel/$shortcode/"
            val req = Request.Builder()
                .url(pageUrl)
                .header("User-Agent", DESKTOP_USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.9")
                .header("Sec-Fetch-Mode", "navigate")
                .build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            val ogVideo = extractFirstMatch(body, "property=[\"']og:video:secure_url[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "property=[\"']og:video[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "[\"']video_url[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "\"video_versions\":\\s*\\[\\s*\\{\\s*\"url\":\\s*\"([^\"]+)\"")
            val ogThumb = extractFirstMatch(body, "property=[\"']og:image[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "[\"']display_url[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
            val ogTitle = extractFirstMatch(body, "property=[\"']og:title[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: "Instagram Reel"

            if (!ogVideo.isNullOrBlank() && !ogVideo.startsWith("blob:")) {
                val cleanVideo = cleanVideoUrl(unescapeUrl(ogVideo))
                val cleanThumb = ogThumb?.let { unescapeUrl(it) }
                return ExtractedVideoResult(
                    videoUrl = cleanVideo,
                    title = cleanTitle(ogTitle),
                    thumbnail = cleanThumb,
                    sourceDomain = "Instagram",
                    hdUrl = cleanVideo,
                    sdUrl = cleanVideo
                )
            }
        } catch (e: Exception) {
            Timber.w(e, "Instagram desktop vector failed")
        }

        // Vector B: Social Crawler fetch (Facebook External Hit receives unauthenticated OpenGraph)
        try {
            val pageUrl = "https://www.instagram.com/p/$shortcode/"
            val req = Request.Builder()
                .url(pageUrl)
                .header("User-Agent", CRAWLER_USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.9")
                .build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            val ogVideo = extractFirstMatch(body, "property=[\"']og:video:secure_url[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "property=[\"']og:video[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "[\"']video_url[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
            val ogThumb = extractFirstMatch(body, "property=[\"']og:image[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "[\"']display_url[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
            val ogTitle = extractFirstMatch(body, "property=[\"']og:title[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: "Instagram Reel"

            if (!ogVideo.isNullOrBlank() && !ogVideo.startsWith("blob:")) {
                val cleanVideo = cleanVideoUrl(unescapeUrl(ogVideo))
                val cleanThumb = ogThumb?.let { unescapeUrl(it) }
                return ExtractedVideoResult(
                    videoUrl = cleanVideo,
                    title = cleanTitle(ogTitle),
                    thumbnail = cleanThumb,
                    sourceDomain = "Instagram",
                    hdUrl = cleanVideo,
                    sdUrl = cleanVideo
                )
            }
        } catch (e: Exception) {
            Timber.w(e, "Instagram crawler vector failed")
        }

        // Vector C: Instagram Embed (Public iframe)
        val embedUrl = "https://www.instagram.com/p/$shortcode/embed/"
        try {
            val req = Request.Builder()
                .url(embedUrl)
                .header("User-Agent", DESKTOP_USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Sec-Fetch-Dest", "iframe")
                .build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            val videoMatch = extractFirstMatch(body, "<video[^>]+src=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "[\"']video_url[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "\"video_versions\":\\s*\\[\\s*\\{\\s*\"url\":\\s*\"([^\"]+)\"")
            val thumbnail = extractFirstMatch(body, "<img[^>]+class=[\"'][^\"']*EmbeddedMediaImage[^\"']*[\"'][^>]+src=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "[\"']display_url[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
            val caption = extractFirstMatch(body, "<div[^>]+class=[\"']Caption[\"'][^>]*>([\\s\\S]*?)<\\/div>")
                ?.replace("<[^>]+>".toRegex(), " ")?.trim()

            if (!videoMatch.isNullOrBlank() && !videoMatch.startsWith("blob:")) {
                val cleanVideo = cleanVideoUrl(unescapeUrl(videoMatch))
                return ExtractedVideoResult(
                    videoUrl = cleanVideo,
                    title = cleanTitle(caption ?: "Instagram Reel"),
                    thumbnail = thumbnail?.let { unescapeUrl(it) },
                    sourceDomain = "Instagram",
                    hdUrl = cleanVideo,
                    sdUrl = cleanVideo
                )
            }
        } catch (e: Exception) {
            Timber.w(e, "Instagram embed vector failed")
        }

        // Vector D: Instagram Web API with App ID Header
        try {
            val apiUrl = "https://www.instagram.com/p/$shortcode/?__a=1&__d=dis"
            val req = Request.Builder()
                .url(apiUrl)
                .header("User-Agent", DESKTOP_USER_AGENT)
                .header("X-IG-App-ID", "936619743392459")
                .header("Accept", "*/*")
                .build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            if (body.contains("\"video_versions\"") || body.contains("\"video_url\"")) {
                val json = JSONObject(body)
                var videoUrl: String? = null
                var thumbUrl: String? = null
                var captionText = "Instagram Reel"

                if (json.has("items")) {
                    val item = json.getJSONArray("items").optJSONObject(0)
                    if (item != null) {
                        val versions = item.optJSONArray("video_versions")
                        if (versions != null && versions.length() > 0) {
                            videoUrl = versions.getJSONObject(0).optString("url")
                        }
                        val imageVersions = item.optJSONObject("image_versions2")?.optJSONArray("candidates")
                        if (imageVersions != null && imageVersions.length() > 0) {
                            thumbUrl = imageVersions.getJSONObject(0).optString("url")
                        }
                        captionText = item.optJSONObject("caption")?.optString("text") ?: captionText
                    }
                } else if (json.has("graphql")) {
                    val media = json.getJSONObject("graphql").optJSONObject("shortcode_media")
                    if (media != null) {
                        videoUrl = media.optString("video_url")
                        thumbUrl = media.optString("display_url")
                    }
                }

                if (!videoUrl.isNullOrBlank()) {
                    val cleanVideo = cleanVideoUrl(unescapeUrl(videoUrl))
                    return ExtractedVideoResult(
                        videoUrl = cleanVideo,
                        title = cleanTitle(captionText),
                        thumbnail = thumbUrl?.let { unescapeUrl(it) },
                        sourceDomain = "Instagram",
                        hdUrl = cleanVideo,
                        sdUrl = cleanVideo
                    )
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Instagram Web API vector failed")
        }

        return null
    }

    fun extractInstagramShortcode(url: String): String? {
        val clean = url.substringBefore("?")
        val patterns = listOf(
            "(?:instagram\\.com|instagr\\.am)/(?:[a-zA-Z0-9_.-]+/)*(?:reel|reels|p|tv)/([A-Za-z0-9_-]+)",
            "(?:instagram\\.com|instagr\\.am)/share/(?:reel|p)/([A-Za-z0-9_-]+)",
            "/(?:reel|reels|p|tv)/([A-Za-z0-9_-]+)"
        )
        for (pat in patterns) {
            val matcher = Pattern.compile(pat, Pattern.CASE_INSENSITIVE).matcher(clean)
            if (matcher.find()) {
                val code = matcher.group(1)
                if (!code.isNullOrBlank() && code != "share" && code != "reel" && code != "reels" && code != "p" && code != "tv") {
                    return code
                }
            }
        }
        val rawMatcher = Pattern.compile("/([A-Za-z0-9_-]{10,12})/?", Pattern.CASE_INSENSITIVE).matcher(clean)
        if (rawMatcher.find()) {
            return rawMatcher.group(1)
        }
        return null
    }

    // =========================================================================
    // =========================================================================
    // 2. FACEBOOK EXTRACTOR (Social Crawler, Video Plugin & Scraper)
    // =========================================================================
    private fun extractFacebook(targetUrl: String): ExtractedVideoResult? {
        // Vector A: Social Crawler fetch (Facebook external hit receives full OpenGraph media)
        try {
            val req = Request.Builder()
                .url(targetUrl)
                .header("User-Agent", CRAWLER_USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.9")
                .build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            val fbResult = parseFacebookHtml(body, "Feeds")
            if (fbResult != null) return fbResult
        } catch (e: Exception) {
            Timber.w(e, "Facebook crawler vector failed")
        }

        // Vector B: Facebook Video Player Plugin (Official public iframe, no login required)
        try {
            val encodedTarget = URLEncoder.encode(targetUrl, "UTF-8")
            val pluginUrl = "https://www.facebook.com/plugins/video.php?href=$encodedTarget"
            val req = Request.Builder()
                .url(pluginUrl)
                .header("User-Agent", DESKTOP_USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Sec-Fetch-Dest", "iframe")
                .build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            val fbResult = parseFacebookHtml(body, "Feeds")
            if (fbResult != null) return fbResult
        } catch (e: Exception) {
            Timber.w(e, "Facebook plugin vector failed")
        }

        // Vector C: Direct Desktop fetch
        try {
            val req = Request.Builder()
                .url(targetUrl)
                .header("User-Agent", DESKTOP_USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Sec-CH-UA-Mobile", "?0")
                .build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            val fbResult = parseFacebookHtml(body, "Feeds")
            if (fbResult != null) return fbResult
        } catch (e: Exception) {
            Timber.w(e, "Facebook desktop vector failed")
        }

        return null
    }

    private fun parseFacebookHtml(body: String, domain: String): ExtractedVideoResult? {
        val fbHd = extractFirstMatch(body, "[\"']playable_url_quality_hd[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
            ?: extractFirstMatch(body, "[\"']browser_native_hd_url[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
            ?: extractFirstMatch(body, "[\"']hd_src[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
            ?: extractFirstMatch(body, "[\"']hd_src_no_ratelimit[\"']\\s*:\\s*[\"']([^\"']+)[\"']")

        val fbSd = extractFirstMatch(body, "[\"']playable_url[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
            ?: extractFirstMatch(body, "[\"']browser_native_sd_url[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
            ?: extractFirstMatch(body, "[\"']sd_src[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
            ?: extractFirstMatch(body, "[\"']sd_src_no_ratelimit[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
            ?: extractFirstMatch(body, "property=[\"']og:video:secure_url[\"']\\s+content=[\"']([^\"']+)[\"']")
            ?: extractFirstMatch(body, "property=[\"']og:video[\"']\\s+content=[\"']([^\"']+)[\"']")

        if (!fbHd.isNullOrBlank() || !fbSd.isNullOrBlank()) {
            val cleanHd = fbHd?.let { cleanVideoUrl(unescapeUrl(it)) }
            val cleanSd = fbSd?.let { cleanVideoUrl(unescapeUrl(it)) }
            val best = cleanHd ?: cleanSd!!
            val rawTitle = extractFirstMatch(body, "property=[\"']og:title[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "<title>([^<]+)</title>")
                ?: "Social Video"
            val thumbnail = extractFirstMatch(body, "property=[\"']og:image[\"']\\s+content=[\"']([^\"']+)[\"']")

            return ExtractedVideoResult(
                videoUrl = best,
                title = cleanTitle(rawTitle),
                thumbnail = thumbnail?.let { unescapeUrl(it) },
                sourceDomain = domain,
                hdUrl = cleanHd ?: cleanSd,
                sdUrl = cleanSd ?: cleanHd
            )
        }
        return null
    }

    // =========================================================================
    // 3. TWITTER / X EXTRACTOR (Official Syndication CDN API & Embeds)
    // =========================================================================
    private fun extractTwitter(targetUrl: String): ExtractedVideoResult? {
        val tweetId = extractTweetId(targetUrl) ?: return null

        // Vector A: Official Twitter Syndication CDN API (Extremely fast, public, zero auth)
        try {
            val syndicationUrl = "https://cdn.syndication.twimg.com/tweet-result?id=$tweetId&lang=en"
            val req = Request.Builder()
                .url(syndicationUrl)
                .header("User-Agent", DESKTOP_USER_AGENT)
                .header("Accept", "application/json")
                .build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            if (body.contains("\"variants\"") || body.contains("\"video\"")) {
                val json = JSONObject(body)
                val text = json.optString("text", "Online Video")
                var thumbnail: String? = null

                val mediaArray = json.optJSONArray("mediaDetails")
                var variantsArray: JSONArray? = null

                if (mediaArray != null && mediaArray.length() > 0) {
                    val mediaObj = mediaArray.getJSONObject(0)
                    thumbnail = mediaObj.optString("media_url_https")
                    val videoInfo = mediaObj.optJSONObject("video_info")
                    variantsArray = videoInfo?.optJSONArray("variants")
                } else if (json.has("video")) {
                    val videoObj = json.getJSONObject("video")
                    variantsArray = videoObj.optJSONArray("variants")
                }

                if (variantsArray != null && variantsArray.length() > 0) {
                    var bestHd: String? = null
                    var bestSd: String? = null
                    var maxBitrate = -1L
                    var minBitrate = Long.MAX_VALUE

                    for (i in 0 until variantsArray.length()) {
                        val v = variantsArray.getJSONObject(i)
                        val contentType = v.optString("content_type")
                        val url = v.optString("url")
                        val bitrate = v.optLong("bitrate", 0L)

                        if (contentType == "video/mp4" && url.isNotBlank()) {
                            if (bitrate >= maxBitrate) {
                                maxBitrate = bitrate
                                bestHd = url
                            }
                            if (bitrate <= minBitrate) {
                                minBitrate = bitrate
                                bestSd = url
                            }
                        }
                    }

                    val chosen = bestHd ?: bestSd
                    if (!chosen.isNullOrBlank()) {
                        return ExtractedVideoResult(
                            videoUrl = chosen,
                            title = cleanTitle(text),
                            thumbnail = thumbnail,
                            sourceDomain = "X",
                            hdUrl = bestHd ?: chosen,
                            sdUrl = bestSd ?: chosen
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Twitter syndication vector failed")
        }

        // Vector B: VxTwitter / FxTwitter API proxy
        try {
            val vxUrl = "https://api.vxtwitter.com/Twitter/status/$tweetId"
            val req = Request.Builder().url(vxUrl).header("User-Agent", "facebookexternalhit/1.1").build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            val json = JSONObject(body)
            val mediaUrl = json.optString("mediaURLs")
            val text = json.optString("text", "X Video")
            val mediaArr = json.optJSONArray("media_extended")
            if (mediaArr != null && mediaArr.length() > 0) {
                val first = mediaArr.getJSONObject(0)
                val u = first.optString("url")
                val thumb = first.optString("thumbnail_url")
                if (u.isNotBlank() && (u.endsWith(".mp4") || first.optString("type") == "video")) {
                    return ExtractedVideoResult(
                        videoUrl = u,
                        title = cleanTitle(text),
                        thumbnail = thumb,
                        sourceDomain = "X",
                        hdUrl = u,
                        sdUrl = u
                    )
                }
            }
        } catch (_: Exception) {}

        return null
    }

    private fun extractTweetId(url: String): String? {
        val pattern = Pattern.compile("(?:twitter\\.com|x\\.com)/[^/]+/status/([0-9]+)", Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(url)
        return if (matcher.find()) matcher.group(1) else null
    }

    // =========================================================================
    // 4. PINTEREST EXTRACTOR
    // =========================================================================
    private fun extractPinterest(targetUrl: String): ExtractedVideoResult? {
        try {
            val req = Request.Builder()
                .url(targetUrl)
                .header("User-Agent", DESKTOP_USER_AGENT)
                .header("Accept", "text/html")
                .build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            val videoMatch = extractFirstMatch(body, "\"720P\":\\s*\\{\\s*\"url\":\\s*\"([^\"]+)\"")
                ?: extractFirstMatch(body, "\"url\":\\s*\"(https://v\\.pinimg\\.com/videos/[^\"]+\\.mp4)\"")
                ?: extractFirstMatch(body, "property=[\"']og:video[\"']\\s+content=[\"']([^\"']+)[\"']")

            val thumbnail = extractFirstMatch(body, "property=[\"']og:image[\"']\\s+content=[\"']([^\"']+)[\"']")
            val title = extractFirstMatch(body, "<title>([^<]+)</title>") ?: "Pinterest Video"

            if (!videoMatch.isNullOrBlank()) {
                val clean = unescapeUrl(videoMatch)
                return ExtractedVideoResult(
                    videoUrl = clean,
                    title = cleanTitle(title),
                    thumbnail = thumbnail?.let { unescapeUrl(it) },
                    sourceDomain = "Pinterest",
                    hdUrl = clean,
                    sdUrl = clean
                )
            }
        } catch (e: Exception) {
            Timber.w(e, "Pinterest extractor error")
        }
        return null
    }

    // =========================================================================
    // 5. REDDIT EXTRACTOR
    // =========================================================================
    private fun extractReddit(targetUrl: String): ExtractedVideoResult? {
        try {
            val clean = targetUrl.substringBefore("?").trimEnd('/')
            val jsonUrl = "$clean.json"
            val req = Request.Builder()
                .url(jsonUrl)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Vidiopen/1.0")
                .build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            val fallbackUrl = extractFirstMatch(body, "\"fallback_url\":\\s*\"([^\"]+)\"")
            val title = extractFirstMatch(body, "\"title\":\\s*\"([^\"]+)\"") ?: "Reddit Video"
            val thumbnail = extractFirstMatch(body, "\"thumbnail\":\\s*\"([^\"]+)\"")

            if (!fallbackUrl.isNullOrBlank()) {
                val cleanUrl = unescapeUrl(fallbackUrl)
                return ExtractedVideoResult(
                    videoUrl = cleanUrl,
                    title = cleanTitle(title),
                    thumbnail = thumbnail?.let { unescapeUrl(it) },
                    sourceDomain = "Reddit",
                    hdUrl = cleanUrl,
                    sdUrl = cleanUrl
                )
            }
        } catch (e: Exception) {
            Timber.w(e, "Reddit extractor error")
        }
        return null
    }

    // =========================================================================
    // 6. TIKTOK EXTRACTOR (TikWM HD API & Embeds)
    // =========================================================================
    private fun extractTikTok(targetUrl: String): ExtractedVideoResult? {
        // Vector A: TikWM Public HD Video & Cover API
        try {
            val encoded = URLEncoder.encode(targetUrl, "UTF-8")
            val apiUrl = "https://www.tikwm.com/api/?url=$encoded"
            val req = Request.Builder()
                .url(apiUrl)
                .header("User-Agent", MOBILE_USER_AGENT)
                .header("Accept", "application/json")
                .build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            if (body.isNotBlank() && body.contains("\"data\"")) {
                val json = JSONObject(body)
                if (json.optInt("code", -1) == 0) {
                    val data = json.getJSONObject("data")
                    val play = data.optString("play")
                    val hdplay = data.optString("hdplay").ifBlank { play }
                    val cover = data.optString("cover")
                    val title = data.optString("title", "Short Video")

                    val chosen = if (hdplay.isNotBlank()) hdplay else play
                    if (chosen.isNotBlank() && chosen.startsWith("http")) {
                        val cleanVideo = cleanVideoUrl(unescapeUrl(chosen))
                        val cleanCover = if (cover.isNotBlank()) unescapeUrl(cover) else null
                        return ExtractedVideoResult(
                            videoUrl = cleanVideo,
                            title = cleanTitle(title),
                            thumbnail = cleanCover,
                            sourceDomain = "Shorts",
                            hdUrl = cleanVideo,
                            sdUrl = cleanVideo
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "TikWM vector failed")
        }

        // Vector B: TikTok Embeds API
        try {
            val videoId = extractFirstMatch(targetUrl, "/video/([0-9]+)")
            if (!videoId.isNullOrBlank()) {
                val embedUrl = "https://www.tiktok.com/embed/v2/$videoId"
                val req = Request.Builder()
                    .url(embedUrl)
                    .header("User-Agent", DESKTOP_USER_AGENT)
                    .build()
                val resp = okHttpClient.newCall(req).execute()
                val body = resp.body?.string() ?: ""
                resp.close()

                val videoSrc = extractFirstMatch(body, "<video[^>]+src=[\"']([^\"']+)[\"']")
                    ?: extractFirstMatch(body, "\"playAddr\":\"([^\"]+)\"")
                val thumb = extractFirstMatch(body, "\"cover\":\"([^\"]+)\"")

                if (!videoSrc.isNullOrBlank()) {
                    val clean = cleanVideoUrl(unescapeUrl(videoSrc))
                    return ExtractedVideoResult(
                        videoUrl = clean,
                        title = "Short Video",
                        thumbnail = thumb?.let { unescapeUrl(it) },
                        sourceDomain = "Shorts",
                        hdUrl = clean,
                        sdUrl = clean
                    )
                }
            }
        } catch (_: Exception) {}
        return null
    }

    // =========================================================================
    // 7. MOJ, JOSH, SHARECHAT EXTRACTOR
    // =========================================================================
    private fun extractMojAndJosh(targetUrl: String): ExtractedVideoResult? {
        try {
            val req = Request.Builder()
                .url(targetUrl)
                .header("User-Agent", MOBILE_USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,*/*")
                .build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            val domain = extractDomain(targetUrl)
            val videoUrl = extractFirstMatch(body, "property=[\"']og:video:secure_url[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "property=[\"']og:video[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "[\"']downloadUrl[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "[\"']mediaUrl[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "[\"']videoUrl[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "itemprop=[\"']contentUrl[\"']\\s+content=[\"']([^\"']+)[\"']")

            val thumb = extractFirstMatch(body, "property=[\"']og:image[\"']\\s+content=[\"']([^\"']+)[\"']")
            val title = extractFirstMatch(body, "property=[\"']og:title[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(body, "<title>([^<]+)</title>")
                ?: "$domain Video"

            if (!videoUrl.isNullOrBlank() && !videoUrl.startsWith("blob:")) {
                val clean = cleanVideoUrl(unescapeUrl(videoUrl))
                return ExtractedVideoResult(
                    videoUrl = clean,
                    title = cleanTitle(title),
                    thumbnail = thumb?.let { unescapeUrl(it) },
                    sourceDomain = domain,
                    hdUrl = clean,
                    sdUrl = clean
                )
            }
        } catch (_: Exception) {}
        return null
    }

    // =========================================================================
    // 8. VIMEO EXTRACTOR
    // =========================================================================
    private fun extractVimeo(targetUrl: String): ExtractedVideoResult? {
        try {
            val videoId = extractFirstMatch(targetUrl, "vimeo\\.com/(?:video/)?([0-9]+)") ?: return null
            val apiUrl = "https://vimeo.com/api/v2/video/$videoId.json"
            val req = Request.Builder().url(apiUrl).build()
            val resp = okHttpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            resp.close()

            val arr = JSONArray(body)
            if (arr.length() > 0) {
                val obj = arr.getJSONObject(0)
                val title = obj.optString("title", "Vimeo Video")
                val thumb = obj.optString("thumbnail_large")
                // Config player fetch
                val configUrl = "https://player.vimeo.com/video/$videoId/config"
                val configReq = Request.Builder().url(configUrl).header("User-Agent", DESKTOP_USER_AGENT).build()
                val configResp = okHttpClient.newCall(configReq).execute()
                val configBody = configResp.body?.string() ?: ""
                configResp.close()

                val progressive = extractFirstMatch(configBody, "\"url\":\"(https://vod-progressive[^\"]+)\"")
                if (!progressive.isNullOrBlank()) {
                    val clean = unescapeUrl(progressive)
                    return ExtractedVideoResult(
                        videoUrl = clean,
                        title = cleanTitle(title),
                        thumbnail = thumb,
                        sourceDomain = "Vimeo",
                        hdUrl = clean,
                        sdUrl = clean
                    )
                }
            }
        } catch (_: Exception) {}
        return null
    }

    // =========================================================================
    // 9. GOOGLE DRIVE EXTRACTOR
    // =========================================================================
    private fun extractGoogleDrive(targetUrl: String): ExtractedVideoResult? {
        val fileId = extractFirstMatch(targetUrl, "drive\\.google\\.com/file/d/([a-zA-Z0-9_-]+)")
            ?: extractFirstMatch(targetUrl, "id=([a-zA-Z0-9_-]+)")
        if (!fileId.isNullOrBlank()) {
            val directStream = "https://drive.google.com/uc?export=download&id=$fileId"
            return ExtractedVideoResult(
                videoUrl = directStream,
                title = "Google Drive Video",
                thumbnail = null,
                sourceDomain = "Google Drive",
                hdUrl = directStream,
                sdUrl = directStream
            )
        }
        return null
    }

    // =========================================================================
    // 10. UNIVERSAL HTML5 & OPENGRAPH SCRAPER (Any website)
    // =========================================================================
    private fun fetchAndParseHtml(targetUrl: String, userAgent: String): ExtractedVideoResult? {
        try {
            val request = Request.Builder()
                .url(targetUrl)
                .header("User-Agent", userAgent)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,video/*,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.9,hi;q=0.8")
                .header("Sec-Fetch-Mode", "navigate")
                .build()

            val response = okHttpClient.newCall(request).execute()
            val finalUrl = response.request.url.toString()
            val contentType = response.header("Content-Type")?.lowercase() ?: ""

            // Directly redirected to a video stream
            if (contentType.contains("video/") || finalUrl.endsWith(".mp4", ignoreCase = true)) {
                val title = finalUrl.substringAfterLast("/").substringBefore("?").ifBlank { "Social Video" }
                val len = response.header("Content-Length")?.toLongOrNull() ?: 0L
                response.close()
                return ExtractedVideoResult(
                    videoUrl = finalUrl,
                    title = cleanTitle(title),
                    thumbnail = null,
                    sourceDomain = extractDomain(finalUrl),
                    hdUrl = finalUrl,
                    sdUrl = finalUrl,
                    contentLengthBytes = len
                )
            }

            val responseBody = response.body?.string() ?: return null
            response.close()

            val domain = extractDomain(finalUrl)

            // Thumbnail
            val thumbnail = extractFirstMatch(responseBody, "property=[\"']og:image[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "content=[\"']([^\"']+)[\"']\\s+property=[\"']og:image[\"']")
                ?: extractFirstMatch(responseBody, "name=[\"']twitter:image[\"']\\s+content=[\"']([^\"']+)[\"']")

            // Title
            val rawTitle = extractFirstMatch(responseBody, "property=[\"']og:title[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "<title>([^<]+)</title>")
                ?: "$domain Video"
            val title = cleanTitle(rawTitle)

            // OpenGraph / Twitter video tags
            val ogVideo = extractFirstMatch(responseBody, "property=[\"']og:video:secure_url[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "property=[\"']og:video:url[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "property=[\"']og:video[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "content=[\"']([^\"']+)[\"']\\s+property=[\"']og:video[\"']")
                ?: extractFirstMatch(responseBody, "name=[\"']twitter:player:stream[\"']\\s+content=[\"']([^\"']+)[\"']")

            if (!ogVideo.isNullOrBlank() && !ogVideo.startsWith("blob:") && !ogVideo.startsWith("data:")) {
                val cleanVideo = cleanVideoUrl(unescapeUrl(ogVideo))
                return ExtractedVideoResult(
                    videoUrl = cleanVideo,
                    title = title,
                    thumbnail = thumbnail?.let { unescapeUrl(it) },
                    sourceDomain = domain,
                    hdUrl = cleanVideo,
                    sdUrl = cleanVideo
                )
            }

            // JSON-LD or Embedded video attributes
            val jsonVideo = extractFirstMatch(responseBody, "[\"']contentUrl[\"']\\s*:\\s*[\"']([^\"']+\\.mp4[^\"']*)[\"']")
                ?: extractFirstMatch(responseBody, "[\"']downloadUrl[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "[\"']mediaUrl[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "[\"']video_url[\"']\\s*:\\s*[\"']([^\"']+)[\"']")

            if (!jsonVideo.isNullOrBlank() && !jsonVideo.startsWith("blob:")) {
                val cleanVideo = cleanVideoUrl(unescapeUrl(jsonVideo))
                return ExtractedVideoResult(
                    videoUrl = cleanVideo,
                    title = title,
                    thumbnail = thumbnail?.let { unescapeUrl(it) },
                    sourceDomain = domain,
                    hdUrl = cleanVideo,
                    sdUrl = cleanVideo
                )
            }

            // HTML5 video tag
            val html5Video = extractFirstMatch(responseBody, "<video[^>]+src=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "<source[^>]+src=[\"']([^\"']+)[\"']")

            if (!html5Video.isNullOrBlank() && !html5Video.startsWith("blob:") &&
                (html5Video.contains(".mp4", ignoreCase = true) || html5Video.contains("video", ignoreCase = true))
            ) {
                val cleanVideo = cleanVideoUrl(unescapeUrl(html5Video))
                return ExtractedVideoResult(
                    videoUrl = cleanVideo,
                    title = title,
                    thumbnail = thumbnail?.let { unescapeUrl(it) },
                    sourceDomain = domain,
                    hdUrl = cleanVideo,
                    sdUrl = cleanVideo
                )
            }

            // Any quoted https://...mp4 link
            val anyMp4 = extractFirstMatch(responseBody, "[\"'](https://[^\"'\\s]+\\.mp4[^\"'\\s]*)[\"']")
            if (!anyMp4.isNullOrBlank() && !anyMp4.contains("youtube.com")) {
                val cleanVideo = cleanVideoUrl(unescapeUrl(anyMp4))
                return ExtractedVideoResult(
                    videoUrl = cleanVideo,
                    title = title,
                    thumbnail = thumbnail?.let { unescapeUrl(it) },
                    sourceDomain = domain,
                    hdUrl = cleanVideo,
                    sdUrl = cleanVideo
                )
            }

        } catch (e: Exception) {
            Timber.w(e, "fetchAndParseHtml error for $targetUrl")
        }
        return null
    }

    // =========================================================================
    // 11. PUBLIC OPEN VIDEO RESOLVER API FALLBACK
    // =========================================================================
    private fun extractWithPublicResolverFallback(targetUrl: String): ExtractedVideoResult? {
        val resolverEndpoints = listOf(
            "https://cobalt.api.kwiatekm.pl/api/json"
        )

        for (endpoint in resolverEndpoints) {
            try {
                val jsonPayload = JSONObject().apply {
                    put("url", targetUrl)
                }
                val body = jsonPayload.toString().toRequestBody("application/json".toMediaTypeOrNull())
                val req = Request.Builder()
                    .url(endpoint)
                    .post(body)
                    .header("Accept", "application/json")
                    .header("User-Agent", "Mozilla/5.0")
                    .build()

                val resp = noRedirectClient.newCall(req).execute()
                val respStr = resp.body?.string() ?: ""
                resp.close()

                if (respStr.isNotBlank() && respStr.contains("\"url\"")) {
                    val resJson = JSONObject(respStr)
                    val status = resJson.optString("status")
                    val videoUrl = resJson.optString("url")
                    val filename = resJson.optString("filename", "Social Video")

                    if ((status == "stream" || status == "redirect" || status == "success" || videoUrl.isNotBlank()) &&
                        videoUrl.startsWith("http")
                    ) {
                        return ExtractedVideoResult(
                            videoUrl = videoUrl,
                            title = cleanTitle(filename),
                            thumbnail = null,
                            sourceDomain = extractDomain(targetUrl),
                            hdUrl = videoUrl,
                            sdUrl = videoUrl
                        )
                    }
                }
            } catch (_: Exception) {
                // Ignore silently
            }
        }
        return null
    }

    // =========================================================================
    // UTILITIES
    // =========================================================================
    private fun extractFirstMatch(html: String, regexPattern: String): String? {
        return try {
            val pattern = Pattern.compile(regexPattern, Pattern.CASE_INSENSITIVE)
            val matcher = pattern.matcher(html)
            if (matcher.find()) {
                matcher.group(1)?.trim()
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun unescapeUrl(url: String): String {
        return url.replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("&amp;", "&")
            .replace("\\u0025", "%")
            .replace("\\\"", "\"")
            .replace("&quot;", "\"")
            .replace("\\u003C", "<")
            .replace("\\u003E", ">")
            .trim()
    }

    private fun cleanTitle(title: String): String {
        return title.replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("\\n", " ")
            .replace("\n", " ")
            .take(65)
            .trim()
    }

    fun extractDomain(url: String): String {
        return try {
            val uri = URI(url)
            val host = uri.host?.lowercase() ?: ""
            when {
                host.contains("facebook") || host.contains("fb.") || host.contains("fbcdn") -> "Facebook"
                host.contains("instagram") || host.contains("cdninstagram") -> "Instagram"
                host.contains("twitter") || host.contains("x.com") || host.contains("twimg") -> "X"
                host.contains("pinterest") || host.contains("pinimg") -> "Pinterest"
                host.contains("reddit") || host.contains("redd.it") -> "Reddit"
                host.contains("tiktok") -> "TikTok"
                host.contains("threads") -> "Threads"
                host.contains("moj") -> "Moj"
                host.contains("josh") -> "Josh"
                host.contains("sharechat") -> "ShareChat"
                host.contains("vimeo") -> "Vimeo"
                host.contains("dailymotion") || host.contains("dai.ly") -> "Dailymotion"
                host.contains("drive.google") -> "Google Drive"
                else -> host.removePrefix("www.").substringBefore(".")
                    .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
            }
        } catch (_: Exception) {
            "Social Video"
        }
    }
}
