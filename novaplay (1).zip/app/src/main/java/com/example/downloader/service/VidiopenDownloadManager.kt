package com.example.downloader.service

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.webkit.CookieManager
import androidx.core.content.FileProvider
import com.example.downloader.model.DownloadStatus
import com.example.downloader.model.DownloadedVideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File

class VidiopenDownloadManager(private val context: Context) {

    private val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    
    // Directory: Public Downloads/Vidiopen/Downloads
    val downloadsFolder: File
        get() {
            val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val dir = File(publicDownloads, "Vidiopen/Downloads")
            if (!dir.exists()) {
                dir.mkdirs()
            }
            return dir
        }

    private val _downloadedVideos = MutableStateFlow<List<DownloadedVideoItem>>(emptyList())
    val downloadedVideos: StateFlow<List<DownloadedVideoItem>> = _downloadedVideos.asStateFlow()

    private val _activeDownloads = MutableStateFlow<Map<Long, DownloadedVideoItem>>(emptyMap())
    val activeDownloads: StateFlow<Map<Long, DownloadedVideoItem>> = _activeDownloads.asStateFlow()

    private val directDownloadJobs = java.util.concurrent.ConcurrentHashMap<Long, kotlinx.coroutines.Job>()
    private val okHttpClient = okhttp3.OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .connectionPool(okhttp3.ConnectionPool(8, 5, java.util.concurrent.TimeUnit.MINUTES))
        .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private val onDownloadCompleteReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == DownloadManager.ACTION_DOWNLOAD_COMPLETE) {
                val downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
                if (downloadId != -1L) {
                    handleDownloadCompleted(downloadId)
                }
            }
        }
    }

    init {
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(onDownloadCompleteReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(onDownloadCompleteReceiver, filter)
        }
        refreshDownloadedVideos()
    }

    fun unregister() {
        try {
            context.unregisterReceiver(onDownloadCompleteReceiver)
        } catch (_: Exception) {}
    }

    /**
     * Downloads video stream directly with full HTTP header control, media validation,
     * and live 60fps speed and progress tracking.
     */
    fun enqueueDownload(
        videoUrl: String,
        rawTitle: String,
        qualityLabel: String = "720p",
        expectedSizeBytes: Long = 0L,
        userAgent: String = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
    ): Long? {
        return startDirectDownload(videoUrl, rawTitle, qualityLabel, expectedSizeBytes, userAgent)
    }

    fun startDirectDownload(
        videoUrl: String,
        rawTitle: String,
        qualityLabel: String = "720p",
        expectedSizeBytes: Long = 0L,
        userAgent: String = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
    ): Long {
        val sanitizedBaseTitle = rawTitle.replace("[^a-zA-Z0-9._-]".toRegex(), "_")
            .trim('_')
            .ifEmpty { "vidiopen_video" }
        val timestamp = System.currentTimeMillis()
        val fileName = "${sanitizedBaseTitle}_${qualityLabel}_$timestamp.mp4"
        val destFile = File(downloadsFolder, fileName)
        val tempFile = File(downloadsFolder, "${fileName}.download.tmp")
        val downloadId = timestamp
        val cleanUrl = com.example.downloader.util.VideoExtractorUtil.cleanVideoUrl(videoUrl)

        val activeItem = DownloadedVideoItem(
            id = downloadId.toString(),
            fileName = fileName,
            filePath = destFile.absolutePath,
            fileSizeBytes = if (expectedSizeBytes > 0) expectedSizeBytes else 0L,
            expectedSizeBytes = expectedSizeBytes,
            downloadedBytes = 0L,
            dateDownloaded = timestamp,
            downloadId = downloadId,
            status = DownloadStatus.DOWNLOADING,
            progressPercent = 1,
            speedBytesPerSec = 0L,
            qualityLabel = qualityLabel
        )

        val updatedMap = _activeDownloads.value.toMutableMap()
        updatedMap[downloadId] = activeItem
        _activeDownloads.value = updatedMap

        val job = kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            var input: java.io.InputStream? = null
            var output: java.io.OutputStream? = null
            try {
                val reqBuilder = okhttp3.Request.Builder()
                    .url(cleanUrl)
                    .header("User-Agent", userAgent)
                    .header("Accept", "*/*")
                    .header("Accept-Language", "en-US,en;q=0.9")
                    .header("Accept-Encoding", "identity")
                    .header("Connection", "keep-alive")

                // Intelligent Referer (never pass direct CDN video URL as referer!)
                when {
                    cleanUrl.contains("instagram.com") || cleanUrl.contains("cdninstagram.com") ->
                        reqBuilder.header("Referer", "https://www.instagram.com/")
                    cleanUrl.contains("facebook.com") || cleanUrl.contains("fbcdn.net") ->
                        reqBuilder.header("Referer", "https://www.facebook.com/")
                    cleanUrl.contains("twimg.com") || cleanUrl.contains("x.com") || cleanUrl.contains("twitter.com") ->
                        reqBuilder.header("Referer", "https://x.com/")
                    cleanUrl.contains("tiktokcdn.com") || cleanUrl.contains("tiktok.com") ->
                        reqBuilder.header("Referer", "https://www.tiktok.com/")
                    cleanUrl.contains("pinimg.com") ->
                        reqBuilder.header("Referer", "https://www.pinterest.com/")
                }

                val cookies = CookieManager.getInstance().getCookie(cleanUrl)
                if (!cookies.isNullOrBlank()) {
                    reqBuilder.header("Cookie", cookies)
                }

                val response = okHttpClient.newCall(reqBuilder.build()).execute()
                val body = response.body
                val contentType = response.header("Content-Type")?.lowercase() ?: ""

                // Reject non-media responses (like 403 HTML walls or error JSONs that cause "few KB file" bug)
                if (!response.isSuccessful || body == null) {
                    response.close()
                    timber.log.Timber.w("Direct download rejected: HTTP ${response.code}")
                    if (tempFile.exists()) tempFile.delete()
                    markDownloadFailed(downloadId)
                    return@launch
                }

                if (contentType.contains("text/html") || contentType.contains("application/xml") ||
                    contentType.contains("text/xml") || contentType.contains("application/json")) {
                    response.close()
                    timber.log.Timber.w("Direct download rejected: Server sent non-video content type '$contentType'")
                    if (tempFile.exists()) tempFile.delete()
                    markDownloadFailed(downloadId)
                    return@launch
                }

                val contentLength = body.contentLength().takeIf { it > 0 } ?: expectedSizeBytes
                input = java.io.BufferedInputStream(body.byteStream(), 262144)
                output = java.io.BufferedOutputStream(java.io.FileOutputStream(tempFile), 262144)

                // High throughput 256KB buffer for maximum download acceleration
                val buffer = ByteArray(262144)
                var bytesRead: Int
                var totalRead = 0L
                var lastTime = System.currentTimeMillis()
                var lastBytes = 0L
                var firstReportSent = false

                while (input.read(buffer).also { bytesRead = it } != -1) {
                    if (!isActive) {
                        break
                    }
                    output.write(buffer, 0, bytesRead)
                    totalRead += bytesRead

                    val now = System.currentTimeMillis()
                    if (!firstReportSent || now - lastTime >= 180) {
                        firstReportSent = true
                        val diffTime = (now - lastTime) / 1000.0
                        val diffBytes = totalRead - lastBytes
                        val speed = if (diffTime > 0) (diffBytes / diffTime).toLong() else 0L
                        val percent = if (contentLength > 0) ((totalRead * 100) / contentLength).toInt().coerceIn(1, 99) else 1

                        val curMap = _activeDownloads.value.toMutableMap()
                        curMap[downloadId]?.let { cur ->
                            curMap[downloadId] = cur.copy(
                                downloadedBytes = totalRead,
                                fileSizeBytes = if (contentLength > 0) contentLength else totalRead,
                                progressPercent = percent,
                                speedBytesPerSec = speed,
                                lastUpdateTimestamp = now
                            )
                            _activeDownloads.value = curMap
                        }

                        lastTime = now
                        lastBytes = totalRead
                    }
                }

                output.flush()
                response.close()

                // Validate minimum download size - if less than 150KB was read, delete corrupt/partial file!
                if (totalRead < 150_000) {
                    timber.log.Timber.w("Direct download failed: Downloaded only $totalRead bytes (corrupt or partial stream)")
                    if (tempFile.exists()) tempFile.delete()
                    markDownloadFailed(downloadId)
                    return@launch
                }

                // Atomically finalize file from temp to final destination
                if (destFile.exists()) destFile.delete()
                val moved = tempFile.renameTo(destFile)
                if (!moved) {
                    tempFile.copyTo(destFile, overwrite = true)
                    tempFile.delete()
                }

                // Mark completed and notify Android media scanner
                MediaScannerConnection.scanFile(context, arrayOf(destFile.absolutePath), arrayOf("video/mp4"), null)
                val finalMap = _activeDownloads.value.toMutableMap()
                finalMap.remove(downloadId)
                _activeDownloads.value = finalMap
                directDownloadJobs.remove(downloadId)
                refreshDownloadedVideos()

            } catch (e: Exception) {
                timber.log.Timber.e(e, "OkHttp direct download error")
                if (tempFile.exists()) tempFile.delete()
                if (destFile.exists() && destFile.length() < 150_000) {
                    destFile.delete()
                }
                markDownloadFailed(downloadId)
            } finally {
                try { input?.close() } catch (_: Exception) {}
                try { output?.close() } catch (_: Exception) {}
            }
        }

        directDownloadJobs[downloadId] = job
        return downloadId
    }

    private fun markDownloadFailed(downloadId: Long) {
        val curMap = _activeDownloads.value.toMutableMap()
        curMap[downloadId]?.let { cur ->
            curMap[downloadId] = cur.copy(status = DownloadStatus.FAILED)
            _activeDownloads.value = curMap
        }
        directDownloadJobs.remove(downloadId)
    }

    fun cancelDownload(downloadId: Long) {
        directDownloadJobs[downloadId]?.cancel()
        directDownloadJobs.remove(downloadId)
        try {
            downloadManager.remove(downloadId)
        } catch (_: Exception) {}
        val updated = _activeDownloads.value.toMutableMap()
        val item = updated.remove(downloadId)
        _activeDownloads.value = updated
        if (item != null) {
            val temp = File(downloadsFolder, "${item.fileName}.download.tmp")
            if (temp.exists()) temp.delete()
            val dest = File(item.filePath)
            if (dest.exists() && dest.length() < 150_000) dest.delete()
        }
    }

    private fun handleDownloadCompleted(downloadId: Long) {
        val query = DownloadManager.Query().setFilterById(downloadId)
        val cursor = downloadManager.query(query)
        if (cursor != null && cursor.moveToFirst()) {
            val statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val localUriIndex = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)
            val status = if (statusIndex != -1) cursor.getInt(statusIndex) else -1
            val localUriString = if (localUriIndex != -1) cursor.getString(localUriIndex) else null

            cursor.close()

            if (status == DownloadManager.STATUS_SUCCESSFUL) {
                if (localUriString != null) {
                    val localUri = Uri.parse(localUriString)
                    val localPath = localUri.path
                    if (localPath != null) {
                        MediaScannerConnection.scanFile(context, arrayOf(localPath), arrayOf("video/mp4"), null)
                    }
                }
                // Refresh list
                refreshDownloadedVideos()
            }
        }
        val updatedMap = _activeDownloads.value.toMutableMap()
        updatedMap.remove(downloadId)
        _activeDownloads.value = updatedMap
    }

    private val durationCache = java.util.concurrent.ConcurrentHashMap<String, Long>()

    /**
     * Poll progress for ongoing active downloads with live speed, accurate MB counter, and ETA.
     * Runs strictly on Dispatchers.IO and only emits updates when download state actually changes.
     */
    suspend fun updateActiveProgress() = withContext(Dispatchers.IO) {
        val currentActive = _activeDownloads.value
        if (currentActive.isEmpty()) return@withContext

        var hasChanged = false
        val updatedMap = currentActive.toMutableMap()
        for ((downloadId, item) in currentActive) {
            val query = DownloadManager.Query().setFilterById(downloadId)
            val cursor = downloadManager.query(query)
            if (cursor != null && cursor.moveToFirst()) {
                val bytesIndex = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                val totalIndex = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                val statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)

                val bytesDownloaded = if (bytesIndex != -1) cursor.getLong(bytesIndex) else 0L
                val totalBytes = if (totalIndex != -1) cursor.getLong(totalIndex) else 0L
                val status = if (statusIndex != -1) cursor.getInt(statusIndex) else DownloadManager.STATUS_RUNNING

                val effectiveTotal = when {
                    totalBytes > 0L -> totalBytes
                    item.fileSizeBytes > 0L -> item.fileSizeBytes
                    item.expectedSizeBytes > 0L -> item.expectedSizeBytes
                    else -> 0L
                }

                val progress = if (effectiveTotal > 0L) {
                    ((bytesDownloaded * 100) / effectiveTotal).toInt().coerceIn(0, 100)
                } else {
                    0
                }

                val downloadStatus = when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> DownloadStatus.COMPLETED
                    DownloadManager.STATUS_FAILED -> DownloadStatus.FAILED
                    DownloadManager.STATUS_PAUSED -> DownloadStatus.PAUSED
                    else -> DownloadStatus.DOWNLOADING
                }

                val now = System.currentTimeMillis()
                val timeDiffSec = (now - item.lastUpdateTimestamp) / 1000.0
                val bytesDiff = (bytesDownloaded - item.downloadedBytes).coerceAtLeast(0L)
                val rawSpeed = if (timeDiffSec >= 0.3 && bytesDiff > 0) {
                    (bytesDiff / timeDiffSec).toLong()
                } else {
                    item.speedBytesPerSec
                }
                // Smooth speed using moving average
                val smoothedSpeed = if (item.speedBytesPerSec > 0 && rawSpeed > 0) {
                    ((0.7 * rawSpeed) + (0.3 * item.speedBytesPerSec)).toLong()
                } else {
                    rawSpeed
                }

                if (downloadStatus == DownloadStatus.COMPLETED) {
                    updatedMap.remove(downloadId)
                    hasChanged = true
                    refreshDownloadedVideos()
                } else {
                    if (item.downloadedBytes != bytesDownloaded || 
                        item.progressPercent != progress || 
                        item.status != downloadStatus ||
                        Math.abs(item.speedBytesPerSec - smoothedSpeed) > 1024L) {
                        hasChanged = true
                        updatedMap[downloadId] = item.copy(
                            fileSizeBytes = if (totalBytes > 0L) totalBytes else effectiveTotal,
                            downloadedBytes = bytesDownloaded,
                            progressPercent = progress,
                            status = downloadStatus,
                            speedBytesPerSec = smoothedSpeed,
                            lastUpdateTimestamp = if (timeDiffSec >= 0.3) now else item.lastUpdateTimestamp
                        )
                    }
                }
                cursor.close()
            }
        }
        if (hasChanged || updatedMap.size != currentActive.size) {
            _activeDownloads.value = updatedMap
        }
    }

    /**
     * Reads all video files present in /Vidiopen/Downloads directory.
     * Uses background Dispatchers.IO and cached durations to avoid expensive metadata re-parsing.
     */
    fun refreshDownloadedVideos() {
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            val folder = downloadsFolder
            val files = folder.listFiles() ?: emptyArray()
            val videoExtensions = listOf("mp4", "mkv", "webm", "3gp", "mov", "avi")

            val resultList = mutableListOf<DownloadedVideoItem>()
            var retriever: MediaMetadataRetriever? = null

            for (file in files) {
                if (file.isFile && videoExtensions.any { file.name.endsWith(it, ignoreCase = true) }) {
                    val cacheKey = "${file.absolutePath}_${file.lastModified()}"
                    var duration = durationCache[cacheKey] ?: 0L

                    if (duration <= 0L) {
                        try {
                            if (retriever == null) retriever = MediaMetadataRetriever()
                            retriever.setDataSource(file.absolutePath)
                            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                            duration = durationStr?.toLongOrNull() ?: 0L
                            if (duration > 0L) {
                                durationCache[cacheKey] = duration
                            }
                        } catch (_: Exception) {}
                    }

                    resultList.add(
                        DownloadedVideoItem(
                            id = file.absolutePath,
                            fileName = file.name,
                            filePath = file.absolutePath,
                            fileUri = Uri.fromFile(file),
                            fileSizeBytes = file.length(),
                            dateDownloaded = file.lastModified(),
                            durationMs = duration,
                            status = DownloadStatus.COMPLETED,
                            progressPercent = 100
                        )
                    )
                }
            }
            try {
                retriever?.release()
            } catch (_: Exception) {}

            // Sort latest first
            resultList.sortByDescending { it.dateDownloaded }
            _downloadedVideos.value = resultList
        }
    }

    fun deleteDownloadedVideo(item: DownloadedVideoItem): Boolean {
        val file = File(item.filePath)
        val deleted = if (file.exists()) file.delete() else false
        if (deleted) {
            MediaScannerConnection.scanFile(context, arrayOf(item.filePath), null, null)
            refreshDownloadedVideos()
        }
        return deleted
    }

    fun shareDownloadedVideo(item: DownloadedVideoItem) {
        val file = File(item.filePath)
        if (!file.exists()) return

        try {
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share Video").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            // Fallback for direct uri
            try {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file))
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(intent, "Share Video").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            } catch (err: Exception) {
                timber.log.Timber.e(err, "Failed to share video")
            }
        }
    }
}
