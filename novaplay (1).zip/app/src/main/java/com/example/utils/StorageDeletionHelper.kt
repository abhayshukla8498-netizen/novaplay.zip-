package com.example.utils

import android.content.ContentUris
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.provider.MediaStore
import com.example.data.database.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object StorageDeletionHelper {

    /**
     * Completely and permanently deletes a media file (video or music) from:
     * 1. The physical storage of the device (File.delete)
     * 2. Android MediaStore system database (so it disappears from gallery, file manager, other apps)
     * 3. System MediaScanner (notifies Android OS that the file no longer exists)
     * 4. Internal Room Database (MediaEntity, RecycleBin, WatchHistory, Bookmarks)
     * 5. Any associated thumbnail or subtitle cache files
     */
    suspend fun deletePermanently(
        context: Context,
        path: String?,
        uriString: String? = null,
        mediaId: String? = null,
        isAudio: Boolean = false
    ): Boolean = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        var anyDeletionSucceeded = false

        // Normalize actual physical file path
        var resolvedPath = path
        if (resolvedPath != null && resolvedPath.startsWith("file://")) {
            resolvedPath = Uri.parse(resolvedPath).path
        }

        // 1. Physical file deletion via Java IO
        if (!resolvedPath.isNullOrBlank() && !resolvedPath.startsWith("content://") && !resolvedPath.startsWith("http://") && !resolvedPath.startsWith("https://")) {
            try {
                val file = File(resolvedPath)
                if (file.exists()) {
                    if (!file.canWrite()) {
                        file.setWritable(true)
                    }
                    // Try truncating to 0 bytes so even if delete is delayed, file is empty and unreadable
                    try {
                        java.io.RandomAccessFile(file, "rw").use { raf ->
                            raf.setLength(0L)
                        }
                    } catch (_: Exception) {}
                    val deleted = file.delete()
                    if (deleted || !file.exists()) {
                        anyDeletionSucceeded = true
                    }
                } else {
                    anyDeletionSucceeded = true
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // 2. Exact Content URI deletion via ContentResolver
        val contentUriToTry = when {
            !uriString.isNullOrBlank() && uriString.startsWith("content://") -> Uri.parse(uriString)
            !resolvedPath.isNullOrBlank() && resolvedPath.startsWith("content://") -> Uri.parse(resolvedPath)
            else -> null
        }

        if (contentUriToTry != null) {
            try {
                // Truncate via content provider if possible
                try {
                    appContext.contentResolver.openFileDescriptor(contentUriToTry, "rwt")?.use { pfd ->
                        android.system.Os.ftruncate(pfd.fileDescriptor, 0L)
                    }
                } catch (_: Exception) {}
                val rows = appContext.contentResolver.delete(contentUriToTry, null, null)
                if (rows > 0) anyDeletionSucceeded = true
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // 3. MediaStore deletion via ContentResolver queries
        if (!resolvedPath.isNullOrBlank() && !resolvedPath.startsWith("http://") && !resolvedPath.startsWith("https://")) {
            val file = File(resolvedPath)
            val fileName = file.name

            // A. Delete by exact DATA path from Video, Images, Audio, Files, and Downloads tables
            val collections = mutableListOf(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                MediaStore.Files.getContentUri("external")
            )
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                try {
                    collections.add(MediaStore.Downloads.EXTERNAL_CONTENT_URI)
                } catch (_: Exception) {}
            }

            for (collectionUri in collections) {
                try {
                    val rows = appContext.contentResolver.delete(
                        collectionUri,
                        "${MediaStore.MediaColumns.DATA}=?",
                        arrayOf(resolvedPath)
                    )
                    if (rows > 0) anyDeletionSucceeded = true
                } catch (e: Exception) {
                    // Ignore and proceed
                }
            }

            // B. Query MediaStore for ID matching the file path or display name and delete by ContentUri
            for (collectionUri in collections) {
                try {
                    val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DATA)
                    val selection = "${MediaStore.MediaColumns.DATA}=? OR (${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.SIZE}=?)"
                    val selectionArgs = arrayOf(
                        resolvedPath,
                        fileName,
                        if (file.exists()) file.length().toString() else "0"
                    )

                    appContext.contentResolver.query(
                        collectionUri,
                        projection,
                        selection,
                        selectionArgs,
                        null
                    )?.use { cursor ->
                        val idColumn = cursor.getColumnIndex(MediaStore.MediaColumns._ID)
                        if (idColumn >= 0) {
                            while (cursor.moveToNext()) {
                                val id = cursor.getLong(idColumn)
                                val itemUri = ContentUris.withAppendedId(collectionUri, id)
                                try {
                                    val rows = appContext.contentResolver.delete(itemUri, null, null)
                                    if (rows > 0) anyDeletionSucceeded = true
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            // 4. Also delete any accompanying sidecars (.srt, .vtt, thumbnails)
            try {
                val baseName = file.nameWithoutExtension
                val parentDir = file.parentFile
                if (parentDir != null && parentDir.exists() && parentDir.isDirectory) {
                    val sidecars = parentDir.listFiles { _, name ->
                        name.startsWith(baseName) && (
                            name.endsWith(".srt", ignoreCase = true) ||
                            name.endsWith(".vtt", ignoreCase = true) ||
                            name.endsWith(".ass", ignoreCase = true)
                        )
                    }
                    sidecars?.forEach { sidecar ->
                        try { sidecar.delete() } catch (_: Exception) {}
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // 5. Notify MediaScanner so Android Gallery & all apps instantly remove this file
            try {
                MediaScannerConnection.scanFile(
                    appContext,
                    arrayOf(resolvedPath),
                    null
                ) { _, _ -> }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // 6. Purge from Room Database across all tables
        try {
            val db = AppDatabase.getDatabase(appContext)
            val recycleBinDao = db.recycleBinDao()
            val mediaDao = db.mediaDao()
            val watchHistoryDao = db.watchHistoryDao()
            val bookmarkDao = db.videoBookmarkDao()

            if (!mediaId.isNullOrBlank()) {
                recycleBinDao.deleteDeletedVideo(mediaId)
                mediaDao.deleteMedia(mediaId)
                bookmarkDao.deleteBookmarksForVideo(mediaId)
            }
            if (!resolvedPath.isNullOrBlank()) {
                recycleBinDao.deleteByPath(resolvedPath)
                watchHistoryDao.deleteWatchHistoryByUrl(resolvedPath)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return@withContext anyDeletionSucceeded
    }
}
