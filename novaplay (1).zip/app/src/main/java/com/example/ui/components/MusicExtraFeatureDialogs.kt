package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.viewmodel.MusicViewModel

@Composable
fun EdgeLightingDialog(
    musicViewModel: MusicViewModel,
    onDismiss: () -> Unit
) {
    val isEnabled by musicViewModel.edgeLightingEnabled.collectAsState()
    val currentStyle by musicViewModel.edgeLightingStyle.collectAsState()
    val intensity by musicViewModel.edgeLightingIntensity.collectAsState()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0xFF14141A))
                .border(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f), RoundedCornerShape(28.dp))
                .padding(22.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Header Icon & Title
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(currentStyle.colors)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF14141A)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.LightMode,
                            contentDescription = null,
                            tint = Color(0xFF00E5FF),
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Edge Lighting (साइड स्क्रीन लाइट)",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "Music ke bass & beat ke sath screen edges par glowing neon lights",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Toggle Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1E1E26))
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Edge Light Effect",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isEnabled) "Active on music play" else "Turned off",
                            color = if (isEnabled) Color(0xFF00E5FF) else Color.Gray,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { musicViewModel.setEdgeLightingEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF00E5FF)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Style Selection Label
                Text(
                    text = "NEON COLOR STYLE",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                // 5 Style Options
                EdgeLightingStyle.entries.forEach { style ->
                    val isSelected = currentStyle == style
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) Color(0xFF282836) else Color(0xFF1A1A22))
                            .border(
                                width = if (isSelected) 1.5.dp else 0.dp,
                                color = if (isSelected) Color(0xFF00E5FF) else Color.Transparent,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { musicViewModel.setEdgeLightingStyle(style) }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Swatch Circles
                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                style.colors.take(4).forEach { color ->
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .background(color)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = style.displayName,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }

                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Glow Intensity Slider
                Text(
                    text = "GLOW INTENSITY: ${(intensity * 100).toInt()}%",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )

                Slider(
                    value = intensity,
                    onValueChange = { musicViewModel.setEdgeLightingIntensity(it) },
                    valueRange = 0.5f..2.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF00E5FF),
                        activeTrackColor = Color(0xFF00E5FF),
                        inactiveTrackColor = Color.DarkGray
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = "Done",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun VocalRemoverDialog(
    musicViewModel: MusicViewModel,
    onDismiss: () -> Unit
) {
    val isEnabled by musicViewModel.vocalRemoverEnabled.collectAsState()
    val cutLevel by musicViewModel.vocalCutLevel.collectAsState()
    val bassRetention by musicViewModel.bassRetention.collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "VocalMicPulse")
    val micPulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "MicScale"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0xFF14141A))
                .border(1.dp, Color(0xFFE91E63).copy(alpha = 0.4f), RoundedCornerShape(28.dp))
                .padding(22.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Header Icon
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(listOf(Color(0xFFE91E63), Color(0xFFFF4081)))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isEnabled) Icons.Rounded.MicExternalOn else Icons.Rounded.Mic,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Vocal Remover (कराओके / आवाज़ हटाओ)",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "Singer ki aawaz mute karke background music & beat play karein taaki aap khud gaa sakein!",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Toggle Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1E1E26))
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Karaoke Mode",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isEnabled) "🎤 Singer voice muted — Karaoke beat active" else "Normal song playback",
                            color = if (isEnabled) Color(0xFFFF4081) else Color.Gray,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { musicViewModel.setVocalRemoverEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFFE91E63)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Vocal Cut Level Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "VOCAL MUTE LEVEL",
                        color = Color.LightGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${(cutLevel * 100).toInt()}%",
                        color = Color(0xFFFF4081),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Slider(
                    value = cutLevel,
                    onValueChange = { musicViewModel.setVocalCutLevel(it) },
                    valueRange = 0.0f..1.0f,
                    enabled = isEnabled,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFFFF4081),
                        activeTrackColor = Color(0xFFFF4081),
                        inactiveTrackColor = Color.DarkGray
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Bass & Drum Retention Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "BASS & DRUMS RETENTION",
                        color = Color.LightGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${(bassRetention * 100).toInt()}%",
                        color = Color(0xFF00E5FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Slider(
                    value = bassRetention,
                    onValueChange = { musicViewModel.setBassRetention(it) },
                    valueRange = 0.0f..1.0f,
                    enabled = isEnabled,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF00E5FF),
                        activeTrackColor = Color(0xFF00E5FF),
                        inactiveTrackColor = Color.DarkGray
                    )
                )

                Text(
                    text = "Bass preservation ensures the kick drum and bassline stay punchy while vocals are muted.",
                    color = Color.Gray,
                    fontSize = 10.sp,
                    lineHeight = 13.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE91E63)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = "Save & Enjoy Karaoke",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun ShakeToChangeDialog(
    musicViewModel: MusicViewModel,
    onDismiss: () -> Unit
) {
    val isEnabled by musicViewModel.shakeToChangeEnabled.collectAsState()
    val sensitivity by musicViewModel.shakeSensitivity.collectAsState()
    val hapticEnabled by musicViewModel.shakeHapticEnabled.collectAsState()
    val action by musicViewModel.shakeAction.collectAsState()
    val liveGForce by musicViewModel.liveShakeGForce.collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "ShakePhoneAnim")
    val shakeRotation by infiniteTransition.animateFloat(
        initialValue = -12f,
        targetValue = 12f,
        animationSpec = infiniteRepeatable(
            animation = tween(180, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ShakeRot"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0xFF14141A))
                .border(1.dp, Color(0xFFFF9800).copy(alpha = 0.4f), RoundedCornerShape(28.dp))
                .padding(22.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                // Header Animated Icon
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(listOf(Color(0xFFFF9800), Color(0xFFFF5722)))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ScreenRotation,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .size(30.dp)
                            .then(if (isEnabled) Modifier.graphicsLayer(rotationZ = shakeRotation) else Modifier)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Shake to Change (फ़ोन हिलाओ गाना बदलो)",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "Phone ko ek baar shake karne par agla gaana automatic play ho jayega!",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Main Toggle Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1E1E26))
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Shake to Change Song",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isEnabled) "Active: Shake phone to change song" else "Sensor is turned OFF",
                            color = if (isEnabled) Color(0xFFFF9800) else Color.Gray,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { musicViewModel.setShakeToChangeEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFFFF9800)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Shake Sensitivity Selector
                Text(
                    text = "SHAKE SENSITIVITY (सेंसिटिविटी)",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                val sensitivities = listOf(
                    Triple("high", "⚡ High (हल्का झटका)", "Light wrist flick"),
                    Triple("medium", "🎯 Medium (नॉर्मल)", "Recommended standard shake"),
                    Triple("firm", "💪 Firm (तेज़ झटका)", "Running & Gym safe (no false triggers)")
                )

                sensitivities.forEach { (key, label, desc) ->
                    val isSelected = sensitivity == key
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) Color(0xFF2E2620) else Color(0xFF1A1A22))
                            .border(
                                width = if (isSelected) 1.5.dp else 0.dp,
                                color = if (isSelected) Color(0xFFFF9800) else Color.Transparent,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable(enabled = isEnabled) { musicViewModel.setShakeSensitivity(key) }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = label,
                                color = if (isEnabled) Color.White else Color.Gray,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                            Text(
                                text = desc,
                                color = if (isSelected) Color(0xFFFFB74D) else Color.Gray,
                                fontSize = 10.sp
                            )
                        }

                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFFFF9800),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action on Shake (Next vs Shuffle)
                Text(
                    text = "ACTION ON SHAKE",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = action == "next",
                        onClick = { musicViewModel.setShakeAction("next") },
                        enabled = isEnabled,
                        label = { Text("⏭️ Skip Next", fontSize = 12.sp) },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFFF9800),
                            selectedLabelColor = Color.Black,
                            containerColor = Color(0xFF1E1E26),
                            labelColor = Color.LightGray
                        )
                    )

                    FilterChip(
                        selected = action == "shuffle",
                        onClick = { musicViewModel.setShakeAction("shuffle") },
                        enabled = isEnabled,
                        label = { Text("🔀 Random", fontSize = 12.sp) },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFFF9800),
                            selectedLabelColor = Color.Black,
                            containerColor = Color(0xFF1E1E26),
                            labelColor = Color.LightGray
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Vibrate Toggle Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF1A1A22))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Vibration,
                            contentDescription = null,
                            tint = Color(0xFFFF9800),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Haptic Vibration Pulse",
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }

                    Switch(
                        checked = hapticEnabled,
                        onCheckedChange = { musicViewModel.setShakeHapticEnabled(it) },
                        enabled = isEnabled,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFFFF9800)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Live Shake Meter
                if (isEnabled) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF1E1E26))
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "LIVE MOTION SENSOR",
                                color = Color.Gray,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = String.format("%.2f g", liveGForce),
                                color = if (liveGForce > 2.0f) Color(0xFFFF9800) else Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        val progress = ((liveGForce - 1.0f) / 3.0f).coerceIn(0f, 1f)
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = Color(0xFFFF9800),
                            trackColor = Color(0xFF2A2A36)
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = "Save Settings",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}
