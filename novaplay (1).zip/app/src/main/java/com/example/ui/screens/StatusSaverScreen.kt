package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.data.model.MediaEntity
import com.example.data.model.StatusFilter
import com.example.data.model.WhatsAppStatus
import com.example.data.model.WhatsAppType
import com.example.ui.viewmodel.MediaViewModel
import com.example.ui.viewmodel.StatusSaverViewModel

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun StatusSaverScreen(
    viewModel: StatusSaverViewModel = viewModel(),
    mediaViewModel: MediaViewModel? = null,
    onBack: (() -> Unit)? = null,
    showTopBar: Boolean = true
) {
    val context = LocalContext.current
    val selectedApp by viewModel.selectedApp.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()
    val allStatuses by viewModel.statuses.collectAsState()
    val filteredStatuses by viewModel.filteredStatuses.collectAsState()
    val savedStatuses by viewModel.savedStatuses.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val isSaving by viewModel.isSaving.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()
    val hasPermission by viewModel.hasAccessPermission.collectAsState()

    var previewStatus by remember { mutableStateOf<WhatsAppStatus?>(null) }
    var showHowItWorksDialog by remember { mutableStateOf(false) }

    // SAF Folder Picker Launcher
    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.onTreeUriGranted(uri)
        }
    }

    // Show toast for messages
    LaunchedEffect(userMessage) {
        userMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearUserMessage()
        }
    }

    // Handle system back button
    BackHandler(enabled = previewStatus != null || showHowItWorksDialog || onBack != null) {
        if (previewStatus != null) {
            previewStatus = null
        } else if (showHowItWorksDialog) {
            showHowItWorksDialog = false
        } else {
            onBack?.invoke()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0E14))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .then(if (showTopBar) Modifier.statusBarsPadding() else Modifier)
        ) {
            // 1. TOP HEADER BAR
            if (showTopBar) {
                HeaderBar(
                    selectedApp = selectedApp,
                    onBack = onBack,
                    onRefresh = { viewModel.refreshStatuses() },
                    onInfoClick = { showHowItWorksDialog = true },
                    onOpenWhatsApp = {
                        launchWhatsAppApp(context, selectedApp.packageName, selectedApp.title)
                    }
                )
            } else {
                // Compact Action Strip when embedded inside tab
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(Color(0xFF25D366), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.SaveAlt,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Saved Statuses",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = { viewModel.refreshStatuses() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = "Refresh",
                                tint = Color(0xFF25D366),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = { showHowItWorksDialog = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.HelpOutline,
                                contentDescription = "Help",
                                tint = Color.LightGray,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // 2. WHATSAPP & WA BUSINESS SWITCHER
            AppSwitcherRow(
                selectedApp = selectedApp,
                onAppSelected = { viewModel.setSelectedApp(it) },
                statusCount = allStatuses.size
            )

            // 3. CATEGORY FILTER CHIPS
            FilterChipsRow(
                selectedFilter = selectedFilter,
                onFilterSelected = { viewModel.setSelectedFilter(it) },
                videoCount = allStatuses.count { it.isVideo },
                photoCount = allStatuses.count { !it.isVideo },
                savedCount = savedStatuses.size
            )

            // 4. PERMISSION CARD (if Scoped Storage requires SAF or All Files Access grant)
            if (!hasPermission && allStatuses.isEmpty() && !isLoading) {
                SafPermissionBanner(
                    selectedApp = selectedApp,
                    onGrantClick = {
                        try {
                            val initialUri = com.example.utils.WhatsAppStatusManager.getInitialTreeUri(selectedApp == WhatsAppType.WHATSAPP_BUSINESS)
                            folderPickerLauncher.launch(initialUri)
                        } catch (_: Exception) {
                            try {
                                val intent = viewModel.createTreeUriIntent()
                                context.startActivity(intent)
                            } catch (_: Exception) {
                                context.startActivity(com.example.utils.WhatsAppStatusManager.getManageStorageIntent(context))
                            }
                        }
                    }
                )
            }

            // 5. STATUSES GRID OR EMPTY STATE
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                if (isLoading) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(
                            color = Color(0xFF25D366),
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                } else if (filteredStatuses.isEmpty()) {
                    EmptyStatusView(
                        selectedApp = selectedApp,
                        selectedFilter = selectedFilter,
                        onOpenWhatsApp = {
                            launchWhatsAppApp(context, selectedApp.packageName, selectedApp.title)
                        },
                        onGrantPermission = {
                            val intent = viewModel.createTreeUriIntent()
                            folderPickerLauncher.launch(intent.getParcelableExtra("android.provider.extra.INITIAL_URI"))
                        }
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 96.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filteredStatuses, key = { it.id }) { status ->
                            StatusGridCard(
                                status = status,
                                onPreview = { previewStatus = status },
                                onSave = { viewModel.saveStatus(status) },
                                onShare = { viewModel.shareStatus(status) },
                                onRepost = { viewModel.repostStatus(status) }
                            )
                        }
                    }
                }
            }
        }

        // FULLSCREEN PREVIEW DIALOG
        previewStatus?.let { status ->
            StatusPreviewDialog(
                status = status,
                onDismiss = { previewStatus = null },
                onSave = {
                    viewModel.saveStatus(status)
                },
                onShare = {
                    viewModel.shareStatus(status)
                },
                onRepost = {
                    viewModel.repostStatus(status)
                },
                onPlayInVidiopenPlayer = {
                    if (mediaViewModel != null && status.isVideo) {
                        val entity = MediaEntity(
                            id = status.id,
                            title = status.title,
                            url = status.uri.toString(),
                            duration = 30000L,
                            artist = "WhatsApp Status",
                            thumbnailUrl = status.uri.toString(),
                            category = "Status",
                            isFavorite = false,
                            lastPlayedPosition = 0L,
                            addedDate = status.lastModified
                        )
                        mediaViewModel.playMedia(entity)
                        previewStatus = null
                    }
                }
            )
        }

        // HOW IT WORKS DIALOG
        if (showHowItWorksDialog) {
            HowItWorksDialog(onDismiss = { showHowItWorksDialog = false })
        }
    }
}

@Composable
private fun HeaderBar(
    selectedApp: WhatsAppType,
    onBack: (() -> Unit)?,
    onRefresh: () -> Unit,
    onInfoClick: () -> Unit,
    onOpenWhatsApp: () -> Unit
) {
    var isRefreshing by remember { mutableStateOf(false) }
    val rotation by animateFloatAsState(
        targetValue = if (isRefreshing) 360f else 0f,
        animationSpec = tween(durationMillis = 600, easing = LinearEasing),
        finishedListener = { isRefreshing = false },
        label = "refresh_rotate"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color.White.copy(alpha = 0.08f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
            }

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF25D366), Color(0xFF128C7E))
                        ),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.SaveAlt,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Text(
                    text = "Status Saver",
                    color = Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.3).sp
                )
                Text(
                    text = "Saved Statuses",
                    color = Color(0xFF25D366),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Open App Button (Neon Emerald Glass)
            IconButton(
                onClick = onOpenWhatsApp,
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(0xFF25D366).copy(alpha = 0.22f),
                                Color(0xFF128C7E).copy(alpha = 0.35f)
                            )
                        ),
                        CircleShape
                    )
                    .border(
                        1.2.dp,
                        Color(0xFF25D366).copy(alpha = 0.55f),
                        CircleShape
                    )
            ) {
                Icon(
                    imageVector = Icons.Rounded.Chat,
                    contentDescription = "Open App",
                    tint = Color(0xFF25D366),
                    modifier = Modifier.size(20.dp)
                )
            }

            // 2. Refresh Button (Cyan Ice Glass with Rotation)
            IconButton(
                onClick = {
                    isRefreshing = true
                    onRefresh()
                },
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(0xFF0EA5E9).copy(alpha = 0.18f),
                                Color(0xFF0369A1).copy(alpha = 0.30f)
                            )
                        ),
                        CircleShape
                    )
                    .border(
                        1.2.dp,
                        Color(0xFF38BDF8).copy(alpha = 0.5f),
                        CircleShape
                    )
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = "Refresh",
                    tint = Color(0xFF38BDF8),
                    modifier = Modifier
                        .size(20.dp)
                        .rotate(rotation)
                )
            }

            // 3. Info / Help Button (Royal Purple Glass)
            IconButton(
                onClick = onInfoClick,
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(0xFF8B5CF6).copy(alpha = 0.18f),
                                Color(0xFF5B21B6).copy(alpha = 0.30f)
                            )
                        ),
                        CircleShape
                    )
                    .border(
                        1.2.dp,
                        Color(0xFFA78BFA).copy(alpha = 0.5f),
                        CircleShape
                    )
            ) {
                Icon(
                    imageVector = Icons.Rounded.HelpOutline,
                    contentDescription = "How it works",
                    tint = Color(0xFFA78BFA),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun AppSwitcherRow(
    selectedApp: WhatsAppType,
    onAppSelected: (WhatsAppType) -> Unit,
    statusCount: Int
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .background(Color(0xFF141923), RoundedCornerShape(12.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        WhatsAppType.entries.forEach { type ->
            val isSelected = selectedApp == type
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(9.dp))
                    .then(
                        if (isSelected) {
                            Modifier.background(
                                Brush.horizontalGradient(listOf(Color(0xFF128C7E), Color(0xFF25D366)))
                            )
                        } else {
                            Modifier
                        }
                    )
                    .clickable { onAppSelected(type) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (type == WhatsAppType.WHATSAPP) Icons.Rounded.Forum else Icons.Rounded.BusinessCenter,
                        contentDescription = null,
                        tint = if (isSelected) Color.White else Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = type.title,
                        color = if (isSelected) Color.White else Color.Gray,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
private fun FilterChipsRow(
    selectedFilter: StatusFilter,
    onFilterSelected: (StatusFilter) -> Unit,
    videoCount: Int,
    photoCount: Int,
    savedCount: Int
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatusFilter.entries.forEach { filter ->
            val isSelected = selectedFilter == filter
            val count = when (filter) {
                StatusFilter.ALL -> videoCount + photoCount
                StatusFilter.VIDEOS -> videoCount
                StatusFilter.PHOTOS -> photoCount
                StatusFilter.SAVED -> savedCount
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (isSelected) Color(0xFF25D366).copy(alpha = 0.2f)
                        else Color(0xFF141923)
                    )
                    .border(
                        1.dp,
                        if (isSelected) Color(0xFF25D366) else Color.White.copy(alpha = 0.08f),
                        RoundedCornerShape(20.dp)
                    )
                    .clickable { onFilterSelected(filter) }
                    .padding(vertical = 7.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = filter.title,
                        color = if (isSelected) Color(0xFF25D366) else Color.LightGray,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                    if (count > 0) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "($count)",
                            color = if (isSelected) Color(0xFF25D366).copy(alpha = 0.8f) else Color.Gray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SafPermissionBanner(
    selectedApp: WhatsAppType,
    onGrantClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131D24)),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(listOf(Color(0xFF25D366).copy(alpha = 0.4f), Color(0xFF128C7E).copy(alpha = 0.4f)))
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.FolderOpen,
                    contentDescription = null,
                    tint = Color(0xFF25D366),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Permission Required",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Android requires permission to read the .Statuses folder of ${selectedApp.title} status media. Tap below and click 'Use this folder'.",
                color = Color.LightGray,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onGrantClick,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Rounded.CheckCircle,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Grant Folder Access",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun StatusGridCard(
    status: WhatsAppStatus,
    onPreview: () -> Unit,
    onSave: () -> Unit,
    onShare: () -> Unit,
    onRepost: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onPreview() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131822)),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.verticalGradient(
                listOf(
                    if (status.isSaved) Color(0xFF25D366).copy(alpha = 0.5f) else Color.White.copy(alpha = 0.12f),
                    Color.Transparent
                )
            )
        )
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = status.uri,
                    contentDescription = status.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Top right tag (Video badge)
                if (status.isVideo) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = null,
                                tint = Color(0xFF25D366),
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "VIDEO",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // If already saved indicator
                if (status.isSaved) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .background(Color(0xFF25D366), CircleShape)
                            .size(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Check,
                            contentDescription = "Saved",
                            tint = Color.Black,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                // Center Play Icon for Video
                if (status.isVideo) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(44.dp)
                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                            .border(1.5.dp, Color.White.copy(alpha = 0.8f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = "Play",
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }

            // Bottom Action Bar on Card
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF161C27))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Save Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (status.isSaved) Color(0xFF25D366).copy(alpha = 0.2f)
                            else Color(0xFF25D366)
                        )
                        .clickable(enabled = !status.isSaved) { onSave() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (status.isSaved) Icons.Rounded.Done else Icons.Rounded.Download,
                            contentDescription = "Save",
                            tint = if (status.isSaved) Color(0xFF25D366) else Color.Black,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (status.isSaved) "Saved" else "Save",
                            color = if (status.isSaved) Color(0xFF25D366) else Color.Black,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Repost to WhatsApp
                    IconButton(
                        onClick = onRepost,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Repeat,
                            contentDescription = "Repost",
                            tint = Color(0xFF25D366),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Share
                    IconButton(
                        onClick = onShare,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Share,
                            contentDescription = "Share",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyStatusView(
    selectedApp: WhatsAppType,
    selectedFilter: StatusFilter,
    onOpenWhatsApp: () -> Unit,
    onGrantPermission: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(76.dp)
                .background(Color(0xFF25D366).copy(alpha = 0.12f), CircleShape)
                .border(1.dp, Color(0xFF25D366).copy(alpha = 0.3f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.BrowseGallery,
                contentDescription = null,
                tint = Color(0xFF25D366),
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = if (selectedFilter == StatusFilter.SAVED) "No Saved Statuses" else "No Statuses Found",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = if (selectedFilter == StatusFilter.SAVED) {
                "Statuses you download will appear here permanently."
            } else {
                "View a status in your messaging app, and come back here to save it."
            },
            color = Color.Gray,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            lineHeight = 18.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        if (selectedFilter != StatusFilter.SAVED) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onOpenWhatsApp,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.OpenInNew,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Open App",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                OutlinedButton(
                    onClick = onGrantPermission,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF25D366)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF25D366)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.FolderOpen,
                        contentDescription = null,
                        tint = Color(0xFF25D366),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Folder Access",
                        color = Color(0xFF25D366),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusPreviewDialog(
    status: WhatsAppStatus,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
    onShare: () -> Unit,
    onRepost: () -> Unit,
    onPlayInVidiopenPlayer: () -> Unit
) {
    val context = LocalContext.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.95f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
            ) {
                // Top Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color.White.copy(alpha = 0.15f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }

                    Text(
                        text = if (status.isVideo) "Video Status" else "Photo Status",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Play in Vidiopen player button (if video)
                    if (status.isVideo) {
                        IconButton(
                            onClick = onPlayInVidiopenPlayer,
                            modifier = Modifier
                                .size(38.dp)
                                .background(Color(0xFF00E5FF).copy(alpha = 0.2f), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Fullscreen,
                                contentDescription = "Full Player",
                                tint = Color(0xFF00E5FF)
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.size(38.dp))
                    }
                }

                // Media Preview Center
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    if (status.isVideo) {
                        // In-Dialog Video Player
                        val exoPlayer = remember(status.uri) {
                            ExoPlayer.Builder(context).build().apply {
                                setMediaItem(MediaItem.fromUri(status.uri))
                                prepare()
                                playWhenReady = true
                            }
                        }

                        DisposableEffect(exoPlayer) {
                            onDispose {
                                try {
                                    exoPlayer.stop()
                                    exoPlayer.release()
                                } catch (_: Exception) {}
                            }
                        }

                        AndroidView(
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    player = exoPlayer
                                    useController = true
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        // Image Preview
                        AsyncImage(
                            model = status.uri,
                            contentDescription = status.title,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    }
                }

                // Bottom Action Sheet
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Save Button
                    Button(
                        onClick = onSave,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (status.isSaved) Color(0xFF25D366).copy(alpha = 0.25f) else Color(0xFF25D366)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) {
                        Icon(
                            imageVector = if (status.isSaved) Icons.Rounded.Done else Icons.Rounded.Download,
                            contentDescription = null,
                            tint = if (status.isSaved) Color(0xFF25D366) else Color.Black
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (status.isSaved) "Saved to Gallery" else "Save to Gallery",
                            color = if (status.isSaved) Color(0xFF25D366) else Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    // Repost
                    IconButton(
                        onClick = onRepost,
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color(0xFF25D366).copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Repeat,
                            contentDescription = "Repost",
                            tint = Color(0xFF25D366)
                        )
                    }

                    // Share
                    IconButton(
                        onClick = onShare,
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color.White.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Share,
                            contentDescription = "Share",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HowItWorksDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF131822),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.Info,
                    contentDescription = null,
                    tint = Color(0xFF25D366),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "How Status Saver Works",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                StepItem(
                    step = "1",
                    title = "Open Messenger",
                    desc = "Watch the status of your contact in your messaging app."
                )
                StepItem(
                    step = "2",
                    title = "Come to Vidiopen",
                    desc = "Open this Status Saver tab to see all viewed statuses automatically."
                )
                StepItem(
                    step = "3",
                    title = "Save or Share",
                    desc = "Tap 'Save' to keep photos & videos permanently in your phone's Gallery!"
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(
                    text = "Got it!",
                    color = Color(0xFF25D366),
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    )
}

@Composable
private fun StepItem(step: String, title: String, desc: String) {
    Row(verticalAlignment = Alignment.Top) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .background(Color(0xFF25D366), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = step,
                color = Color.Black,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = desc,
                color = Color.Gray,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }
    }
}

fun launchWhatsAppApp(context: android.content.Context, packageName: String, appTitle: String) {
    val pm = context.packageManager

    // 1. Try specified package
    try {
        val launchIntent = pm.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            return
        }
    } catch (_: Exception) {}

    // 2. Try variant packages
    val variants = if (packageName.contains("w4b")) {
        listOf("com.whatsapp.w4b", "com.whatsapp")
    } else {
        listOf("com.whatsapp", "com.whatsapp.w4b", "com.gbwhatsapp", "com.fmwhatsapp", "com.yowhatsapp", "com.whatsapp.plus")
    }
    for (pkg in variants) {
        try {
            val variantIntent = pm.getLaunchIntentForPackage(pkg)
            if (variantIntent != null) {
                variantIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(variantIntent)
                return
            }
        } catch (_: Exception) {}
    }

    // 3. Try whatsapp:// URI scheme
    try {
        val schemeIntent = Intent(Intent.ACTION_VIEW, Uri.parse("whatsapp://send?text=")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(schemeIntent)
        return
    } catch (_: Exception) {}

    // 4. Try ACTION_MAIN category LAUNCHER with packageName
    try {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setPackage(packageName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return
    } catch (_: Exception) {}

    // 5. Open Play Store or notify
    try {
        val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(marketIntent)
    } catch (_: Exception) {
        Toast.makeText(context, "Please open $appTitle from your home screen", Toast.LENGTH_SHORT).show()
    }
}
