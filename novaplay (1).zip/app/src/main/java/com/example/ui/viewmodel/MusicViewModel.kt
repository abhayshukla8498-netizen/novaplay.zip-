package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.ScannedSong
import com.example.data.model.MoodCategory
import com.example.ui.components.EdgeLightingStyle
import com.example.data.repository.MusicRepository
import com.example.data.repository.MusicThemeRepository
import com.example.player.MusicPlayerManager
import com.example.player.PlayerState
import com.example.player.ShakeDetector
import com.example.ui.theme.MusicTheme
import com.example.ui.theme.MusicThemeRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.io.File

class MusicViewModel(
    application: Application,
    private val musicRepository: MusicRepository,
    private val musicPlayerManager: MusicPlayerManager,
    private val musicThemeRepository: MusicThemeRepository
) : AndroidViewModel(application) {

    // Themes logic
    val selectedThemeId: StateFlow<String> = musicThemeRepository.selectedThemeId
        .stateIn(viewModelScope, SharingStarted.Eagerly, "moonlight_night")

    val customThemeImageUri: StateFlow<String?> = musicThemeRepository.customThemeImageUri
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val currentTheme: StateFlow<MusicTheme> = combine(
        selectedThemeId,
        customThemeImageUri
    ) { themeId, imageUri ->
        MusicThemeRegistry.getThemeById(themeId, imageUri)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, MusicThemeRegistry.BuiltInThemes.first())

    fun selectTheme(themeId: String) {
        viewModelScope.launch {
            musicThemeRepository.saveSelectedThemeId(themeId)
        }
    }

    fun setCustomThemeImage(uriString: String?) {
        viewModelScope.launch {
            musicThemeRepository.saveCustomThemeImageUri(uriString)
            if (uriString != null) {
                musicThemeRepository.saveSelectedThemeId("custom_image")
            } else {
                musicThemeRepository.saveSelectedThemeId("moonlight_night")
            }
        }
    }

    // Favorites Logic
    private val sharedPrefs = application.getSharedPreferences("music_player_prefs", Context.MODE_PRIVATE)
    private val _favoriteSongIds = MutableStateFlow<Set<Long>>(emptySet())
    val favoriteSongIds: StateFlow<Set<Long>> = _favoriteSongIds

    init {
        val favs = sharedPrefs.getStringSet("favorites", emptySet()) ?: emptySet()
        _favoriteSongIds.value = favs.mapNotNull { it.toLongOrNull() }.toSet()
    }

    fun toggleFavorite(songId: Long) {
        val current = _favoriteSongIds.value.toMutableSet()
        if (current.contains(songId)) {
            current.remove(songId)
        } else {
            current.add(songId)
        }
        _favoriteSongIds.value = current
        sharedPrefs.edit().putStringSet("favorites", current.map { it.toString() }.toSet()).apply()
    }

    fun isFavorite(songId: Long): Boolean {
        return _favoriteSongIds.value.contains(songId)
    }

    // Edge Lighting (Neon Side Lights on Music)
    private val _edgeLightingEnabled = MutableStateFlow(sharedPrefs.getBoolean("edge_lighting_enabled", true))
    val edgeLightingEnabled: StateFlow<Boolean> = _edgeLightingEnabled.asStateFlow()

    private val _edgeLightingStyle = MutableStateFlow(
        EdgeLightingStyle.fromId(sharedPrefs.getString("edge_lighting_style", "rainbow") ?: "rainbow")
    )
    val edgeLightingStyle: StateFlow<EdgeLightingStyle> = _edgeLightingStyle.asStateFlow()

    private val _edgeLightingIntensity = MutableStateFlow(sharedPrefs.getFloat("edge_lighting_intensity", 1.0f))
    val edgeLightingIntensity: StateFlow<Float> = _edgeLightingIntensity.asStateFlow()

    fun setEdgeLightingEnabled(enabled: Boolean) {
        _edgeLightingEnabled.value = enabled
        sharedPrefs.edit().putBoolean("edge_lighting_enabled", enabled).apply()
    }

    fun setEdgeLightingStyle(style: EdgeLightingStyle) {
        _edgeLightingStyle.value = style
        sharedPrefs.edit().putString("edge_lighting_style", style.id).apply()
    }

    fun setEdgeLightingIntensity(intensity: Float) {
        val clamped = intensity.coerceIn(0.5f, 2.0f)
        _edgeLightingIntensity.value = clamped
        sharedPrefs.edit().putFloat("edge_lighting_intensity", clamped).apply()
    }

    // Vocal Remover (Karaoke) flows delegated from MusicPlayerManager
    val vocalRemoverEnabled: StateFlow<Boolean> = musicPlayerManager.vocalRemoverEnabled
    val vocalCutLevel: StateFlow<Float> = musicPlayerManager.vocalCutLevel
    val bassRetention: StateFlow<Float> = musicPlayerManager.bassRetention

    fun setVocalRemoverEnabled(enabled: Boolean) {
        musicPlayerManager.setVocalRemoverEnabled(enabled)
    }

    fun setVocalCutLevel(level: Float) {
        musicPlayerManager.setVocalCutLevel(level)
    }

    fun setBassRetention(retention: Float) {
        musicPlayerManager.setBassRetention(retention)
    }

    // -------------------------------------------------------------
    // Shake to Change Song (फोन हिलाकर गाना बदलना)
    // -------------------------------------------------------------
    private val shakeDetector = ShakeDetector(application)
    val liveShakeGForce: StateFlow<Float> = shakeDetector.liveGForce

    private val _shakeToChangeEnabled = MutableStateFlow(sharedPrefs.getBoolean("shake_to_change_enabled", false))
    val shakeToChangeEnabled: StateFlow<Boolean> = _shakeToChangeEnabled.asStateFlow()

    private val _shakeSensitivity = MutableStateFlow(sharedPrefs.getString("shake_sensitivity", "medium") ?: "medium")
    val shakeSensitivity: StateFlow<String> = _shakeSensitivity.asStateFlow()

    private val _shakeHapticEnabled = MutableStateFlow(sharedPrefs.getBoolean("shake_haptic_enabled", true))
    val shakeHapticEnabled: StateFlow<Boolean> = _shakeHapticEnabled.asStateFlow()

    private val _shakeAction = MutableStateFlow(sharedPrefs.getString("shake_action", "next") ?: "next")
    val shakeAction: StateFlow<String> = _shakeAction.asStateFlow()

    fun setShakeToChangeEnabled(enabled: Boolean) {
        _shakeToChangeEnabled.value = enabled
        sharedPrefs.edit().putBoolean("shake_to_change_enabled", enabled).apply()
        updateShakeDetectorState()
    }

    fun setShakeSensitivity(sensitivity: String) {
        _shakeSensitivity.value = sensitivity
        sharedPrefs.edit().putString("shake_sensitivity", sensitivity).apply()
        shakeDetector.sensitivity = when (sensitivity) {
            "high" -> 1.8f
            "firm" -> 3.2f
            else -> 2.4f
        }
    }

    fun setShakeHapticEnabled(enabled: Boolean) {
        _shakeHapticEnabled.value = enabled
        sharedPrefs.edit().putBoolean("shake_haptic_enabled", enabled).apply()
        shakeDetector.hapticEnabled = enabled
    }

    fun setShakeAction(action: String) {
        _shakeAction.value = action
        sharedPrefs.edit().putString("shake_action", action).apply()
    }

    private fun updateShakeDetectorState() {
        if (_shakeToChangeEnabled.value) {
            shakeDetector.startListening()
        } else {
            shakeDetector.stopListening()
        }
    }

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    private val vaultDao = com.example.data.database.AppDatabase.getDatabase(getApplication()).vaultDao()
    private val vaultItems = vaultDao.getVaultItems()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _songs = MutableStateFlow<List<ScannedSong>>(emptyList())
    val songs: StateFlow<List<ScannedSong>> = combine(_songs, vaultItems) { songList, vaultList ->
        val vaultTitles = vaultList.map { it.title.lowercase() }.toSet()
        val vaultPaths = vaultList.map { it.path.lowercase() }.toSet()
        songList.filter { song ->
            val titleLower = song.title.lowercase()
            val pathLower = song.path.lowercase()
            !vaultTitles.contains(titleLower) &&
            !vaultPaths.contains(pathLower) &&
            !pathLower.contains("vidiopen_vault")
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Playback state flows delegated from MusicPlayerManager
    val currentPlayingSong: StateFlow<ScannedSong?> = musicPlayerManager.currentPlayingSong
    val isPlaying: StateFlow<Boolean> = musicPlayerManager.isPlaying
    val playerState: StateFlow<PlayerState> = musicPlayerManager.playerState
    val currentPosition: StateFlow<Long> = musicPlayerManager.currentPosition
    val duration: StateFlow<Long> = musicPlayerManager.duration
    val queue: StateFlow<List<ScannedSong>> = musicPlayerManager.queue
    val repeatMode: StateFlow<Int> = musicPlayerManager.repeatMode
    val shuffleModeEnabled: StateFlow<Boolean> = musicPlayerManager.shuffleModeEnabled
    val playbackSpeed: StateFlow<Float> = musicPlayerManager.playbackSpeed

    // Premium Audio Effects and Equalizer states
    val eqEnabled = MutableStateFlow(musicPlayerManager.audioEffectsManager.eqEnabled)
    val selectedPreset = MutableStateFlow(musicPlayerManager.audioEffectsManager.selectedPreset)
    val eqBands = MutableStateFlow(musicPlayerManager.audioEffectsManager.eqBands.clone())

    val bassBoostEnabled = MutableStateFlow(musicPlayerManager.audioEffectsManager.bassBoostEnabled)
    val bassBoostStrength = MutableStateFlow(musicPlayerManager.audioEffectsManager.bassBoostStrength)

    val virtualizerEnabled = MutableStateFlow(musicPlayerManager.audioEffectsManager.virtualizerEnabled)
    val virtualizerStrength = MutableStateFlow(musicPlayerManager.audioEffectsManager.virtualizerStrength)

    val loudnessEnabled = MutableStateFlow(musicPlayerManager.audioEffectsManager.loudnessEnabled)
    val loudnessGain = MutableStateFlow(musicPlayerManager.audioEffectsManager.loudnessGain)

    val balance = MutableStateFlow(musicPlayerManager.getBalance())
    val reverbPreset = MutableStateFlow(musicPlayerManager.audioEffectsManager.reverbPreset)

    // Premium Sleep Timer and Fading states
    val sleepTimerRemaining = musicPlayerManager.sleepTimerRemaining
    val sleepTimerMode = musicPlayerManager.sleepTimerMode

    val fadeInEnabled = musicPlayerManager.fadeInEnabled
    val fadeInDurationMs = musicPlayerManager.fadeInDurationMs
    val fadeOutEnabled = musicPlayerManager.fadeOutEnabled
    val fadeOutDurationMs = musicPlayerManager.fadeOutDurationMs

    // Categories
    val allSongs: StateFlow<List<ScannedSong>> = songs

    val albums: StateFlow<List<AlbumItem>> = songs.map { songList ->
        songList.groupBy { it.album ?: "Unknown Album" }
            .map { (albumName, songs) ->
                AlbumItem(
                    name = albumName,
                    artist = songs.firstOrNull()?.artist ?: "Unknown Artist",
                    artworkUri = songs.firstOrNull()?.artworkUri,
                    songs = songs,
                    totalSize = songs.sumOf { it.size },
                    totalDuration = songs.sumOf { it.duration }
                )
            }.sortedBy { it.name }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val artists: StateFlow<List<ArtistItem>> = songs.map { songList ->
        songList.groupBy { it.artist ?: "Unknown Artist" }
            .map { (artistName, songs) ->
                ArtistItem(
                    name = artistName,
                    songs = songs,
                    totalSize = songs.sumOf { it.size },
                    totalDuration = songs.sumOf { it.duration },
                    artworkUri = songs.firstOrNull()?.artworkUri
                )
            }.sortedBy { it.name }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val folders: StateFlow<List<FolderItem>> = songs.map { songList ->
        songList.groupBy { 
            val file = File(it.path)
            file.parentFile?.absolutePath ?: "Unknown"
        }.map { (folderPath, songs) ->
            FolderItem(
                name = File(folderPath).name,
                path = folderPath,
                songs = songs,
                totalSize = songs.sumOf { it.size },
                totalDuration = songs.sumOf { it.duration }
            )
        }.sortedBy { it.name }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentlyAdded: StateFlow<List<ScannedSong>> = songs.map { songList ->
        songList.sortedByDescending { it.dateAdded }.take(50)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Mood-Based Smart Playlists (Workout, Late Night, Chill, Romantic, Party, Sad)
    private val _selectedMoodFilter = MutableStateFlow<MoodCategory?>(null)
    val selectedMoodFilter: StateFlow<MoodCategory?> = _selectedMoodFilter.asStateFlow()

    private val _moodOverrides = MutableStateFlow<Map<Long, String>>(emptyMap())

    val moodPlaylists: StateFlow<Map<MoodCategory, List<ScannedSong>>> = combine(songs, _moodOverrides) { songList, overrides ->
        val map = mutableMapOf<MoodCategory, MutableList<ScannedSong>>()
        for (mood in MoodCategory.entries) {
            map[mood] = mutableListOf()
        }
        for (song in songList) {
            val overrideMood = overrides[song.id]
            val mood = MoodCategory.categorizeSong(song, overrideMood)
            map[mood]?.add(song)
        }
        map
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    fun setMoodFilter(mood: MoodCategory?) {
        _selectedMoodFilter.value = mood
    }

    fun setSongMoodOverride(songId: Long, mood: MoodCategory) {
        val updated = _moodOverrides.value.toMutableMap()
        updated[songId] = mood.id
        _moodOverrides.value = updated
        sharedPrefs.edit().putString("song_mood_$songId", mood.id).apply()
    }

    fun playMood(mood: MoodCategory) {
        val playlist = moodPlaylists.value[mood].orEmpty()
        if (playlist.isNotEmpty()) {
            playSong(playlist.first(), playlist)
        }
    }

    fun shuffleMood(mood: MoodCategory) {
        val playlist = moodPlaylists.value[mood].orEmpty().shuffled()
        if (playlist.isNotEmpty()) {
            playSong(playlist.first(), playlist)
        }
    }

    init {
        val allPrefs = sharedPrefs.all
        val overrides = mutableMapOf<Long, String>()
        for ((key, value) in allPrefs) {
            if (key.startsWith("song_mood_") && value is String) {
                val songId = key.removePrefix("song_mood_").toLongOrNull()
                if (songId != null) {
                    overrides[songId] = value
                }
            }
        }
        _moodOverrides.value = overrides

        shakeDetector.sensitivity = when (_shakeSensitivity.value) {
            "high" -> 1.8f
            "firm" -> 3.2f
            else -> 2.4f
        }
        shakeDetector.hapticEnabled = _shakeHapticEnabled.value
        shakeDetector.setOnShakeListener {
            if (_shakeToChangeEnabled.value && isPlaying.value) {
                if (_shakeAction.value == "shuffle") {
                    val currentQueue = queue.value
                    if (currentQueue.size > 1) {
                        val remaining = currentQueue.filter { it.id != currentPlayingSong.value?.id }
                        if (remaining.isNotEmpty()) {
                            playSong(remaining.random(), currentQueue)
                        } else {
                            next()
                        }
                    } else {
                        next()
                    }
                } else {
                    next()
                }
            }
        }
        if (_shakeToChangeEnabled.value) {
            shakeDetector.startListening()
        }

        val initialCached = musicRepository.getCachedSongs()
        if (initialCached.isNotEmpty()) {
            _songs.value = initialCached
            musicPlayerManager.syncScannedSongs(initialCached)
        }
        scanMusicFiles()
    }

    fun scanMusicFiles(forceRefresh: Boolean = false) {
        viewModelScope.launch {
            if (_songs.value.isEmpty()) {
                val cached = musicRepository.getCachedSongs()
                if (cached.isNotEmpty()) {
                    _songs.value = cached
                    musicPlayerManager.syncScannedSongs(cached)
                } else {
                    _isScanning.value = true
                }
            }
            try {
                val scanned = musicRepository.scanAudio(forceRefresh = forceRefresh)
                _songs.value = scanned
                musicPlayerManager.syncScannedSongs(scanned)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isScanning.value = false
            }
        }
    }

    // Playback Control Delegates
    fun playSong(song: ScannedSong, contextList: List<ScannedSong>) {
        musicPlayerManager.playSong(song, contextList)
    }

    fun togglePlayPause() = musicPlayerManager.togglePlayPause()
    fun play() = musicPlayerManager.play()
    fun pause() = musicPlayerManager.pause()
    fun next() = musicPlayerManager.next()
    fun previous() = musicPlayerManager.previous()
    fun stop() = musicPlayerManager.stop()
    fun closePlayer() = musicPlayerManager.closePlayer()
    fun seekTo(positionMs: Long) = musicPlayerManager.seekTo(positionMs)
    fun fastSeekForward() = musicPlayerManager.fastSeekForward()
    fun fastSeekBackward() = musicPlayerManager.fastSeekBackward()
    fun replay() = musicPlayerManager.replay()

    // Queue Control Delegates
    fun playNext(song: ScannedSong) = musicPlayerManager.playNext(song)
    fun addToQueue(song: ScannedSong) = musicPlayerManager.addToQueue(song)
    fun removeFromQueue(songId: Long) = musicPlayerManager.removeFromQueue(songId)
    fun clearQueue() = musicPlayerManager.clearQueue()
    fun reorderQueue(fromIndex: Int, toIndex: Int) = musicPlayerManager.reorderQueue(fromIndex, toIndex)

    // Play Mode Delegates
    fun setRepeatMode(mode: Int) = musicPlayerManager.setRepeatMode(mode)
    fun setShuffleMode(enabled: Boolean) = musicPlayerManager.setShuffleMode(enabled)
    fun setPlaybackSpeed(speed: Float) = musicPlayerManager.setPlaybackSpeed(speed)

    // Premium Equalizer and Audio Effects Actions
    fun setEqEnabled(enabled: Boolean) {
        musicPlayerManager.audioEffectsManager.eqEnabled = enabled
        eqEnabled.value = enabled
    }

    fun setEqBand(bandIndex: Int, gainDb: Int) {
        musicPlayerManager.audioEffectsManager.setEqBand(bandIndex, gainDb)
        eqBands.value = musicPlayerManager.audioEffectsManager.eqBands.clone()
        eqEnabled.value = musicPlayerManager.audioEffectsManager.eqEnabled
    }

    fun selectPreset(presetName: String) {
        musicPlayerManager.audioEffectsManager.selectedPreset = presetName
        selectedPreset.value = presetName
        eqBands.value = musicPlayerManager.audioEffectsManager.eqBands.clone()
        eqEnabled.value = musicPlayerManager.audioEffectsManager.eqEnabled
    }

    fun saveCustomPreset(name: String, bands: IntArray) {
        musicPlayerManager.audioEffectsManager.saveCustomPreset(name, bands)
    }

    fun getCustomPresetNames(): Set<String> {
        return musicPlayerManager.audioEffectsManager.getCustomPresetNames()
    }

    fun deleteCustomPreset(name: String) {
        musicPlayerManager.audioEffectsManager.deleteCustomPreset(name)
    }

    fun setBassBoostEnabled(enabled: Boolean) {
        musicPlayerManager.audioEffectsManager.bassBoostEnabled = enabled
        bassBoostEnabled.value = enabled
    }

    fun setBassBoostStrength(strength: Int) {
        musicPlayerManager.audioEffectsManager.bassBoostStrength = strength
        bassBoostStrength.value = strength
        bassBoostEnabled.value = musicPlayerManager.audioEffectsManager.bassBoostEnabled
    }

    fun setVirtualizerEnabled(enabled: Boolean) {
        musicPlayerManager.audioEffectsManager.virtualizerEnabled = enabled
        virtualizerEnabled.value = enabled
    }

    fun setVirtualizerStrength(strength: Int) {
        musicPlayerManager.audioEffectsManager.virtualizerStrength = strength
        virtualizerStrength.value = strength
        virtualizerEnabled.value = musicPlayerManager.audioEffectsManager.virtualizerEnabled
    }

    fun setLoudnessEnabled(enabled: Boolean) {
        musicPlayerManager.audioEffectsManager.loudnessEnabled = enabled
        loudnessEnabled.value = enabled
    }

    fun setLoudnessGain(gainDb: Float) {
        musicPlayerManager.audioEffectsManager.loudnessGain = gainDb
        loudnessGain.value = gainDb
        loudnessEnabled.value = musicPlayerManager.audioEffectsManager.loudnessEnabled
    }

    fun setBalance(bal: Float) {
        musicPlayerManager.setBalance(bal)
        balance.value = bal
    }

    fun setReverbPreset(preset: Short) {
        musicPlayerManager.audioEffectsManager.reverbPreset = preset
        reverbPreset.value = preset
    }

    fun setSleepTimer(minutes: Int?) {
        musicPlayerManager.setSleepTimer(minutes)
    }

    fun setSleepTimerEndOfSong() {
        musicPlayerManager.setSleepTimerEndOfSong()
    }

    fun setFadeInEnabled(enabled: Boolean) {
        musicPlayerManager.setFadeInEnabled(enabled)
    }

    fun setFadeInDuration(ms: Long) {
        musicPlayerManager.setFadeInDuration(ms)
    }

    fun setFadeOutEnabled(enabled: Boolean) {
        musicPlayerManager.setFadeOutEnabled(enabled)
    }

    fun setFadeOutDuration(ms: Long) {
        musicPlayerManager.setFadeOutDuration(ms)
    }

    override fun onCleared() {
        super.onCleared()
        shakeDetector.stopListening()
    }
}

// Grouping classes representing nested structures
data class AlbumItem(
    val name: String,
    val artist: String,
    val artworkUri: String?,
    val songs: List<ScannedSong>,
    val totalSize: Long,
    val totalDuration: Long
)

data class ArtistItem(
    val name: String,
    val songs: List<ScannedSong>,
    val totalSize: Long,
    val totalDuration: Long,
    val artworkUri: String? = null
)

data class FolderItem(
    val name: String,
    val path: String,
    val songs: List<ScannedSong>,
    val totalSize: Long,
    val totalDuration: Long
)

class MusicViewModelFactory(
    private val application: Application,
    private val musicRepository: MusicRepository,
    private val musicPlayerManager: MusicPlayerManager,
    private val musicThemeRepository: MusicThemeRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MusicViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MusicViewModel(application, musicRepository, musicPlayerManager, musicThemeRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
