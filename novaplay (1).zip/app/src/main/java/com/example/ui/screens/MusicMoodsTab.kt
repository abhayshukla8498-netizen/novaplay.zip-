package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.MoodCategory
import com.example.data.model.ScannedSong
import com.example.ui.viewmodel.MusicViewModel

@Composable
fun MusicMoodsTab(
    musicViewModel: MusicViewModel,
    appLang: String,
    onTrackSpecsClicked: (ScannedSong) -> Unit,
    modifier: Modifier = Modifier
) {
    val moodPlaylists by musicViewModel.moodPlaylists.collectAsState()
    val selectedFilter by musicViewModel.selectedMoodFilter.collectAsState()
    var viewingMood by remember { mutableStateOf<MoodCategory?>(null) }

    if (viewingMood != null) {
        val mood = viewingMood!!
        val songs = moodPlaylists[mood].orEmpty()
        MoodPlaylistDetailView(
            mood = mood,
            songs = songs,
            appLang = appLang,
            onBack = { viewingMood = null },
            onPlaySong = { song -> musicViewModel.playSong(song, songs) },
            onPlayAll = { musicViewModel.playMood(mood) },
            onShuffleAll = { musicViewModel.shuffleMood(mood) },
            onTrackSpecsClicked = onTrackSpecsClicked
        )
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header Info Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFF1E1B4B), Color(0xFF312E81))
                        )
                    )
                    .border(1.dp, Color(0xFF818CF8).copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "🎭",
                                fontSize = 20.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (appLang == "hi") "स्मार्ट मूड प्लेलिस्ट" else "Smart Mood Playlists",
                                color = Color.White,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (appLang == "hi")
                                "ऑटो-फ़िल्टर: वर्कआउट, देर रात, सुकून, रोमांटिक, पार्टी और उदास गानों का स्मार्ट संग्रह"
                            else
                                "Auto-categorized: Workout, Late Night, Chill, Romantic, Party & Sad songs filter",
                            color = Color(0xFFC7D2FE),
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 6 Mood Cards in 2-Column Grid
            val moods = MoodCategory.entries
            for (i in moods.indices step 2) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MoodCardItem(
                        mood = moods[i],
                        songs = moodPlaylists[moods[i]].orEmpty(),
                        appLang = appLang,
                        onClick = { viewingMood = moods[i] },
                        onQuickPlay = { musicViewModel.playMood(moods[i]) },
                        modifier = Modifier.weight(1f)
                    )

                    if (i + 1 < moods.size) {
                        MoodCardItem(
                            mood = moods[i + 1],
                            songs = moodPlaylists[moods[i + 1]].orEmpty(),
                            appLang = appLang,
                            onClick = { viewingMood = moods[i + 1] },
                            onQuickPlay = { musicViewModel.playMood(moods[i + 1]) },
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
fun MoodCardItem(
    mood: MoodCategory,
    songs: List<ScannedSong>,
    appLang: String,
    onClick: () -> Unit,
    onQuickPlay: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(170.dp)
            .clip(RoundedCornerShape(22.dp))
            .clickable { onClick() }
            .testTag("mood_card_${mood.id}"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(mood.gradientColors))
                .padding(14.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = mood.emoji,
                            fontSize = 22.sp
                        )
                    }

                    if (songs.isNotEmpty()) {
                        IconButton(
                            onClick = onQuickPlay,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.9f))
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = "Play Mood",
                                tint = Color.Black,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }

                Column {
                    Text(
                        text = if (appLang == "hi") mood.titleHi else mood.titleEn,
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${songs.size} ${if (songs.size == 1) "Song" else "Songs"}",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun MoodPlaylistDetailView(
    mood: MoodCategory,
    songs: List<ScannedSong>,
    appLang: String,
    onBack: () -> Unit,
    onPlaySong: (ScannedSong) -> Unit,
    onPlayAll: () -> Unit,
    onShuffleAll: () -> Unit,
    onTrackSpecsClicked: (ScannedSong) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0C0C0E))
    ) {
        // Mood Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(mood.gradientColors))
                .statusBarsPadding()
                .padding(16.dp)
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.3f))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = mood.emoji,
                        fontSize = 26.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (appLang == "hi") mood.titleHi else mood.titleEn,
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (appLang == "hi") mood.descriptionHi else mood.descriptionEn,
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons (Play All & Shuffle)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onPlayAll,
                        enabled = songs.isNotEmpty(),
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (appLang == "hi") "सभी बजाएं" else "Play All",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = onShuffleAll,
                        enabled = songs.isNotEmpty(),
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color.White
                        ),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Shuffle,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (appLang == "hi") "शफ़ल" else "Shuffle",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Song List or Empty State
        if (songs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = mood.emoji, fontSize = 48.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (appLang == "hi") "इस मूड में अभी कोई गाना नहीं है" else "No songs in this mood yet",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (appLang == "hi") "गाने स्कैन करें या लाइब्रेरी में नए गाने जोड़ें" else "Scan music or add new tracks to your library",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(songs, key = { _, s -> s.id }) { index, song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF18181C))
                            .clickable { onPlaySong(song) }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${index + 1}",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            modifier = Modifier.width(26.dp)
                        )

                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF2A2A32)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (!song.artworkUri.isNullOrEmpty()) {
                                AsyncImage(
                                    model = song.artworkUri,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.MusicNote,
                                    contentDescription = null,
                                    tint = mood.gradientColors.first(),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = song.artist ?: "Unknown Artist",
                                color = Color.Gray,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        IconButton(onClick = { onTrackSpecsClicked(song) }) {
                            Icon(
                                imageVector = Icons.Rounded.MoreVert,
                                contentDescription = "Options",
                                tint = Color.Gray,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
                
                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }
    }
}

@Composable
fun MoodQuickFilterChips(
    selectedMood: MoodCategory?,
    onMoodSelected: (MoodCategory?) -> Unit,
    appLang: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // "All" filter chip
        FilterChip(
            selected = selectedMood == null,
            onClick = { onMoodSelected(null) },
            label = {
                Text(
                    text = if (appLang == "hi") "🌟 सब" else "🌟 All",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = Color(0xFF25D366),
                selectedLabelColor = Color.Black,
                containerColor = Color(0xFF1E1E24),
                labelColor = Color.LightGray
            ),
            border = null,
            shape = RoundedCornerShape(20.dp)
        )

        MoodCategory.entries.forEach { mood ->
            val isSelected = selectedMood == mood
            FilterChip(
                selected = isSelected,
                onClick = { onMoodSelected(if (isSelected) null else mood) },
                label = {
                    Text(
                        text = "${mood.emoji} ${if (appLang == "hi") mood.titleHi else mood.titleEn}",
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = mood.gradientColors.first(),
                    selectedLabelColor = Color.White,
                    containerColor = Color(0xFF1E1E24),
                    labelColor = Color.LightGray
                ),
                border = null,
                shape = RoundedCornerShape(20.dp)
            )
        }
    }
}
