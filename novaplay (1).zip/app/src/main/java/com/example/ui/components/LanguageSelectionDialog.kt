package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LocalIsLightTheme
import com.example.ui.theme.RoyalPurple

@Composable
fun LanguageSelectionOverlay(
    currentLanguage: String = "en",
    onDismiss: (() -> Unit)? = null,
    onLanguageSelected: (String) -> Unit
) {
    var selectedLang by remember { mutableStateOf(if (currentLanguage.isEmpty()) "en" else currentLanguage) }
    val isLight = LocalIsLightTheme.current
    val scrollState = rememberScrollState()

    // Smooth ambient background animations
    val infiniteTransition = rememberInfiniteTransition(label = "LanguageScreenAmbient")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )

    val shimmerOffset by infiniteTransition.animateFloat(
        initialValue = -300f,
        targetValue = 900f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ShimmerOffset"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isLight) Color(0xFFF8FAFC) else Color(0xFF080B11))
            .clickable(enabled = false) {}, // Intercept clicks so outside screen is guarded
        contentAlignment = Alignment.Center
    ) {
        // Multi-layered Glowing Atmosphere Orbs
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            if (isLight) Color(0x2238BDF8) else Color(0x3500D9FF),
                            Color.Transparent
                        ),
                        radius = 900f,
                        center = androidx.compose.ui.geometry.Offset(200f, 300f)
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            if (isLight) Color(0x1A818CF8) else Color(0x307C4DFF),
                            Color.Transparent
                        ),
                        radius = 1000f,
                        center = androidx.compose.ui.geometry.Offset(800f, 1400f)
                    )
                )
        )

        // Close button if onDismiss is provided (e.g., opened from Settings)
        if (onDismiss != null) {
            IconButton(
                onClick = { onDismiss() },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
                    .statusBarsPadding()
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(if (isLight) Color.Black.copy(alpha = 0.06f) else Color.White.copy(alpha = 0.12f))
            ) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Close",
                    tint = if (isLight) Color.Black else Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // Main Content in scrollable column to prevent cutting off on any device size
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(scrollState)
                .padding(horizontal = 22.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // ==========================================
            // 1. ATTRACTIVE BRAND LOGO & GLOWING AURA
            // ==========================================
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(110.dp)
            ) {
                // Outer pulsing ambient ring
                Box(
                    modifier = Modifier
                        .size(104.dp)
                        .scale(pulseScale)
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    ElectricBlue.copy(alpha = 0.35f),
                                    RoyalPurple.copy(alpha = 0.20f),
                                    Color.Transparent
                                )
                            ),
                            shape = CircleShape
                        )
                )

                // Outer Glass Ring
                Box(
                    modifier = Modifier
                        .size(88.dp)
                        .background(
                            brush = Brush.linearGradient(
                                colors = if (isLight) {
                                    listOf(Color.White, Color(0xFFE2E8F0))
                                } else {
                                    listOf(Color(0xFF1E2638), Color(0xFF0F172A))
                                }
                            ),
                            shape = CircleShape
                        )
                        .border(
                            width = 2.dp,
                            brush = Brush.sweepGradient(
                                colors = listOf(
                                    ElectricBlue,
                                    RoyalPurple,
                                    Color(0xFF00F5D4),
                                    ElectricBlue
                                )
                            ),
                            shape = CircleShape
                        )
                        .shadow(
                            elevation = 14.dp,
                            shape = CircleShape,
                            ambientColor = ElectricBlue,
                            spotColor = RoyalPurple
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_vidiopen_logo),
                        contentDescription = "Vidiopen Pro Logo",
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Fit
                    )
                }

                // Sparkle badge in bottom-right of logo
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .offset(x = (-4).dp, y = (-2).dp)
                        .size(28.dp)
                        .background(
                            brush = Brush.linearGradient(listOf(Color(0xFF00D9FF), Color(0xFF7C4DFF))),
                            shape = CircleShape
                        )
                        .border(1.5.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Language,
                        contentDescription = "Language",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Welcome Badge Pill
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(30.dp))
                    .background(
                        if (isLight) Color(0xFFEEF2FF) else Color(0x332563EB)
                    )
                    .border(
                        1.dp,
                        if (isLight) Color(0xFFC7D2FE) else Color(0x5538BDF8),
                        RoundedCornerShape(30.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "✦",
                    color = ElectricBlue,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "VIDIOPEN PRO • HD MEDIA & DOWNLOADER",
                    color = if (isLight) Color(0xFF3730A3) else Color(0xFF93C5FD),
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ==========================================
            // 2. ATTRACTIVE HEADINGS & DUAL-TEXT
            // ==========================================
            Text(
                text = "Choose App Language",
                color = if (isLight) Color(0xFF0F172A) else Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                letterSpacing = (-0.5).sp
            )

            Spacer(modifier = Modifier.height(3.dp))

            Text(
                text = "अपनी पसंदीदा भाषा चुनें",
                color = ElectricBlue,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Select language to personalize your video player, music & downloader experience.\nबेहतरीन अनुभव के लिए अपनी पसंदीदा भाषा का चयन करें।",
                color = if (isLight) Color(0xFF475569) else Color(0xFF94A3B8),
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp,
                modifier = Modifier.padding(horizontal = 12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Feature Highlights Chips Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LanguageFeatureBadge(
                    icon = Icons.Rounded.PlayArrow,
                    label = "1080P HD",
                    isLight = isLight
                )
                Spacer(modifier = Modifier.width(8.dp))
                LanguageFeatureBadge(
                    icon = Icons.Rounded.Download,
                    label = "Fast Download",
                    isLight = isLight
                )
                Spacer(modifier = Modifier.width(8.dp))
                LanguageFeatureBadge(
                    icon = Icons.Rounded.MusicNote,
                    label = "Hi-Res Audio",
                    isLight = isLight
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ==========================================
            // 3. ATTRACTIVE LANGUAGE SELECTION CARDS
            // ==========================================
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // English Card
                AttractiveLanguageCard(
                    langCode = "en",
                    nativeName = "English",
                    englishName = "Default / Global",
                    hindiHelper = "सिस्टम डिफ़ॉल्ट भाषा",
                    badgeText = "EN",
                    badgeGradient = listOf(Color(0xFF2563EB), Color(0xFF06B6D4)),
                    flagPillText = "GLOBAL",
                    flagPillBg = if (isLight) Color(0xFFDBEAFE) else Color(0x333B82F6),
                    flagPillTextColor = if (isLight) Color(0xFF1D4ED8) else Color(0xFF93C5FD),
                    previewText = "“1080P Player, Downloader & Music”",
                    tags = listOf("Clean & Modern", "Worldwide"),
                    isSelected = selectedLang == "en",
                    isLight = isLight,
                    onClick = { selectedLang = "en" }
                )

                // Hindi Card (हिन्दी)
                AttractiveLanguageCard(
                    langCode = "hi",
                    nativeName = "हिन्दी",
                    englishName = "Hindi (Devanagari)",
                    hindiHelper = "भारत की अपनी मातृभाषा",
                    badgeText = "अ",
                    badgeGradient = listOf(Color(0xFFFF9933), Color(0xFFEA580C)),
                    flagPillText = "🇮🇳 भारत / INDIA",
                    flagPillBg = if (isLight) Color(0xFFFFEDD5) else Color(0x33F97316),
                    flagPillTextColor = if (isLight) Color(0xFFC2410C) else Color(0xFFFDBA74),
                    previewText = "“1080P वीडियो, संगीत व सुपरफ़ास्ट डाउनलोड”",
                    tags = listOf("पूर्ण हिंदी सपोर्ट", "100% अनुशंसित"),
                    isSelected = selectedLang == "hi",
                    isLight = isLight,
                    onClick = { selectedLang = "hi" }
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // ==========================================
            // 4. DYNAMIC ACTION BUTTON (CTA) WITH SHIMMER
            // ==========================================
            val buttonInteractionSource = remember { MutableInteractionSource() }
            val isButtonPressed by buttonInteractionSource.collectIsPressedAsState()
            val buttonScale by animateFloatAsState(
                targetValue = if (isButtonPressed) 0.97f else 1.0f,
                animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
                label = "ButtonPressScale"
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .scale(buttonScale)
                    .shadow(
                        elevation = 16.dp,
                        shape = RoundedCornerShape(18.dp),
                        ambientColor = ElectricBlue,
                        spotColor = RoyalPurple
                    )
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xFF00D9FF),
                                Color(0xFF2563EB),
                                Color(0xFF7C4DFF)
                            )
                        )
                    )
                    .clickable(
                        interactionSource = buttonInteractionSource,
                        indication = ripple()
                    ) {
                        onLanguageSelected(selectedLang)
                    }
                    .padding(vertical = 16.dp, horizontal = 24.dp),
                contentAlignment = Alignment.Center
            ) {
                // Shimmer light streak
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.White.copy(alpha = 0.22f),
                                    Color.Transparent
                                ),
                                startX = shimmerOffset,
                                endX = shimmerOffset + 240f
                            )
                        )
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (selectedLang == "hi") "हिन्दी में जारी रखें  ➔" else "Continue in English  ➔",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.4.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (selectedLang == "hi") "Vidiopen Pro का आनंद लें" else "Start exploring Vidiopen Pro",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Reassurance footer: You can change anytime
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Settings,
                    contentDescription = "Settings",
                    tint = if (isLight) Color(0xFF64748B) else Color(0xFF64748B),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "You can change language anytime in Settings • सेटिंग्स में कभी भी बदलें",
                    color = if (isLight) Color(0xFF64748B) else Color(0xFF64748B),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

@Composable
fun LanguageFeatureBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isLight: Boolean
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                if (isLight) Color(0xFFF1F5F9) else Color(0xFF131B2A)
            )
            .border(
                1.dp,
                if (isLight) Color(0xFFE2E8F0) else Color(0x3338BDF8),
                RoundedCornerShape(20.dp)
            )
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = ElectricBlue,
            modifier = Modifier.size(12.dp)
        )
        Text(
            text = label,
            color = if (isLight) Color(0xFF334155) else Color(0xFFCBD5E1),
            fontSize = 10.5.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun AttractiveLanguageCard(
    langCode: String,
    nativeName: String,
    englishName: String,
    hindiHelper: String,
    badgeText: String,
    badgeGradient: List<Color>,
    flagPillText: String,
    flagPillBg: Color,
    flagPillTextColor: Color,
    previewText: String,
    tags: List<String>,
    isSelected: Boolean,
    isLight: Boolean,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val cardScale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else if (isSelected) 1.01f else 1.0f,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 450f),
        label = "CardScale"
    )

    // Animated glow pulse on selected card
    val infiniteTransition = rememberInfiniteTransition(label = "CardGlowTransition")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "GlowAlpha"
    )

    val radioScale by animateFloatAsState(
        targetValue = if (isSelected) 1.0f else 0.85f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "RadioScale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(cardScale)
            .shadow(
                elevation = if (isSelected) 14.dp else 2.dp,
                shape = RoundedCornerShape(22.dp),
                ambientColor = if (isSelected) ElectricBlue.copy(alpha = glowAlpha) else Color.Transparent,
                spotColor = if (isSelected) RoyalPurple.copy(alpha = glowAlpha) else Color.Transparent
            )
            .clip(RoundedCornerShape(22.dp))
            .background(
                brush = if (isSelected) {
                    if (isLight) Brush.linearGradient(listOf(Color(0xFFF0FDF4), Color(0xFFDCFCE7).copy(alpha = 0.6f)))
                    else Brush.linearGradient(
                        listOf(
                            Color(0xFF0F1E36),
                            Color(0xFF141F3B),
                            Color(0xFF1A173B)
                        )
                    )
                } else {
                    if (isLight) Brush.linearGradient(listOf(Color.White, Color(0xFFF8FAFC)))
                    else Brush.linearGradient(
                        listOf(
                            Color(0xFF0F172A).copy(alpha = 0.85f),
                            Color(0xFF0B132B).copy(alpha = 0.85f)
                        )
                    )
                }
            )
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                brush = if (isSelected) {
                    Brush.linearGradient(
                        colors = listOf(
                            ElectricBlue,
                            Color(0xFF818CF8),
                            RoyalPurple
                        )
                    )
                } else {
                    Brush.linearGradient(
                        colors = if (isLight) {
                            listOf(Color(0xFFE2E8F0), Color(0xFFCBD5E1))
                        } else {
                            listOf(Color(0x33FFFFFF), Color(0x15FFFFFF))
                        }
                    )
                },
                shape = RoundedCornerShape(22.dp)
            )
            .clickable(
                interactionSource = interactionSource,
                indication = ripple()
            ) {
                onClick()
            }
            .padding(16.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left Icon Badge & Text info
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    // Attractive 3D-styled Badge Icon
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .shadow(
                                elevation = if (isSelected) 8.dp else 3.dp,
                                shape = RoundedCornerShape(16.dp),
                                ambientColor = badgeGradient.first(),
                                spotColor = badgeGradient.last()
                            )
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                Brush.linearGradient(colors = badgeGradient)
                            )
                            .border(
                                1.5.dp,
                                Color.White.copy(alpha = 0.4f),
                                RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = badgeText,
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    // Titles & Helpers
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = nativeName,
                                color = if (isLight) Color(0xFF0F172A) else Color.White,
                                fontSize = 19.sp,
                                fontWeight = FontWeight.Bold
                            )

                            // Country / Global Pill
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(flagPillBg)
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = flagPillText,
                                    color = flagPillTextColor,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = englishName,
                            color = if (isSelected) ElectricBlue else if (isLight) Color(0xFF64748B) else Color(0xFF94A3B8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Text(
                            text = hindiHelper,
                            color = if (isLight) Color(0xFF94A3B8) else Color(0xFF64748B),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }
                }

                // Radio Selector Indicator
                Box(
                    modifier = Modifier
                        .scale(radioScale)
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(
                            if (isSelected) ElectricBlue else Color.Transparent
                        )
                        .border(
                            width = if (isSelected) 0.dp else 2.dp,
                            color = if (isSelected) Color.Transparent else if (isLight) Color(0xFFCBD5E1) else Color(0x55FFFFFF),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Rounded.Check,
                            contentDescription = "Selected",
                            tint = Color.Black,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Preview Quote Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isSelected) {
                            if (isLight) Color(0xFFE0F2FE) else Color(0x3300D9FF)
                        } else {
                            if (isLight) Color(0xFFF8FAFC) else Color(0x22FFFFFF)
                        }
                    )
                    .border(
                        0.5.dp,
                        if (isSelected) ElectricBlue.copy(alpha = 0.4f) else Color.Transparent,
                        RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 7.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        tint = if (isSelected) ElectricBlue else if (isLight) Color(0xFF64748B) else Color(0xFF94A3B8),
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = previewText,
                        color = if (isSelected) (if (isLight) Color(0xFF0369A1) else Color(0xFFE0F2FE)) else if (isLight) Color(0xFF64748B) else Color(0xFF94A3B8),
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Tags row
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                tags.forEach { tag ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isSelected) {
                                    if (isLight) Color(0xFFDCFCE7) else Color(0x2222C55E)
                                } else {
                                    if (isLight) Color(0xFFF1F5F9) else Color(0x15FFFFFF)
                                }
                            )
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = tag,
                            color = if (isSelected) {
                                if (isLight) Color(0xFF15803D) else Color(0xFF4ADE80)
                            } else {
                                if (isLight) Color(0xFF64748B) else Color(0xFF94A3B8)
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
