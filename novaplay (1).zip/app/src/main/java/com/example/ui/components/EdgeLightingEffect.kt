package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

enum class EdgeLightingStyle(val id: String, val displayName: String, val colors: List<Color>) {
    RAINBOW(
        "rainbow",
        "🌈 Rainbow Flow",
        listOf(
            Color(0xFFFF0055),
            Color(0xFFFF9900),
            Color(0xFFFFFF00),
            Color(0xFF00FF66),
            Color(0xFF00E5FF),
            Color(0xFF7000FF),
            Color(0xFFFF00AA),
            Color(0xFFFF0055)
        )
    ),
    CYBERPUNK(
        "cyberpunk",
        "💎 Cyberpunk Neon",
        listOf(
            Color(0xFF00E5FF),
            Color(0xFFFF007F),
            Color(0xFF7000FF),
            Color(0xFF00E5FF)
        )
    ),
    BASS_FIRE(
        "bass_fire",
        "🔥 Bass Fire",
        listOf(
            Color(0xFFFFD700),
            Color(0xFFFF6D00),
            Color(0xFFFF1744),
            Color(0xFFFF6D00),
            Color(0xFFFFD700)
        )
    ),
    COSMIC_VIOLET(
        "cosmic_violet",
        "🌌 Cosmic Violet",
        listOf(
            Color(0xFFE040FB),
            Color(0xFF7C4DFF),
            Color(0xFF00E5FF),
            Color(0xFF7C4DFF),
            Color(0xFFE040FB)
        )
    ),
    ACID_LIME(
        "acid_lime",
        "💚 Acid Lime Matrix",
        listOf(
            Color(0xFF76FF03),
            Color(0xFF00E676),
            Color(0xFF00B0FF),
            Color(0xFF00E676),
            Color(0xFF76FF03)
        )
    );

    companion object {
        fun fromId(id: String): EdgeLightingStyle = entries.firstOrNull { it.id == id } ?: RAINBOW
    }
}

@Composable
fun EdgeLightingOverlay(
    isPlaying: Boolean,
    style: EdgeLightingStyle = EdgeLightingStyle.RAINBOW,
    intensity: Float = 1.0f,
    cornerRadius: Dp = 28.dp,
    modifier: Modifier = Modifier
) {
    if (!isPlaying) return

    val infiniteTransition = rememberInfiniteTransition(label = "EdgeLighting")
    
    // Continuous rotation angle of the neon sweep
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "SweepAngle"
    )

    // Beat / Bass Pulse animation mimicking rhythmic audio bass
    val bassPulse by infiniteTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 480, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BassPulse"
    )

    val currentGlowAlpha = (0.75f * bassPulse * intensity).coerceIn(0.2f, 1.0f)
    val outerStrokeWidth = (8.dp * bassPulse * intensity)
    val innerStrokeWidth = (3.5.dp * bassPulse)

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val center = Offset(w / 2f, h / 2f)

            if (w <= 0f || h <= 0f) return@Canvas

            // Rotating sweep gradient brush
            val sweepBrush = Brush.sweepGradient(
                colors = style.colors,
                center = center
            )

            // Outer soft diffuse glow (wider stroke, lower alpha)
            drawRoundRect(
                brush = sweepBrush,
                topLeft = Offset(0f, 0f),
                size = Size(w, h),
                cornerRadius = CornerRadius(cornerRadius.toPx(), cornerRadius.toPx()),
                style = Stroke(
                    width = outerStrokeWidth.toPx(),
                    cap = StrokeCap.Round
                ),
                alpha = currentGlowAlpha * 0.55f
            )

            // Mid neon layer
            drawRoundRect(
                brush = sweepBrush,
                topLeft = Offset(0f, 0f),
                size = Size(w, h),
                cornerRadius = CornerRadius(cornerRadius.toPx(), cornerRadius.toPx()),
                style = Stroke(
                    width = (outerStrokeWidth * 0.6f).toPx(),
                    cap = StrokeCap.Round
                ),
                alpha = currentGlowAlpha * 0.85f
            )

            // Crisp inner neon core (white-tinted/bright)
            drawRoundRect(
                brush = sweepBrush,
                topLeft = Offset(0f, 0f),
                size = Size(w, h),
                cornerRadius = CornerRadius(cornerRadius.toPx(), cornerRadius.toPx()),
                style = Stroke(
                    width = innerStrokeWidth.toPx(),
                    cap = StrokeCap.Round
                ),
                alpha = 1.0f
            )
        }
    }
}
