package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.StatusFilter
import com.example.data.model.WhatsAppStatus
import com.example.data.model.WhatsAppType
import com.example.utils.WhatsAppStatusManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class StatusSaverViewModel(application: Application) : AndroidViewModel(application) {

    private val _selectedApp = MutableStateFlow(WhatsAppType.WHATSAPP)
    val selectedApp: StateFlow<WhatsAppType> = _selectedApp.asStateFlow()

    private val _selectedFilter = MutableStateFlow(StatusFilter.ALL)
    val selectedFilter: StateFlow<StatusFilter> = _selectedFilter.asStateFlow()

    private val _statuses = MutableStateFlow<List<WhatsAppStatus>>(emptyList())
    val statuses: StateFlow<List<WhatsAppStatus>> = _statuses.asStateFlow()

    private val _savedStatuses = MutableStateFlow<List<WhatsAppStatus>>(emptyList())
    val savedStatuses: StateFlow<List<WhatsAppStatus>> = _savedStatuses.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    private val _hasAccessPermission = MutableStateFlow(true)
    val hasAccessPermission: StateFlow<Boolean> = _hasAccessPermission.asStateFlow()

    val filteredStatuses: StateFlow<List<WhatsAppStatus>> = combine(
        _statuses,
        _savedStatuses,
        _selectedFilter
    ) { currentStatuses, currentSaved, filter ->
        when (filter) {
            StatusFilter.ALL -> currentStatuses
            StatusFilter.VIDEOS -> currentStatuses.filter { it.isVideo }
            StatusFilter.PHOTOS -> currentStatuses.filter { !it.isVideo }
            StatusFilter.SAVED -> currentSaved
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        refreshStatuses()
    }

    fun setSelectedApp(type: WhatsAppType) {
        if (_selectedApp.value != type) {
            _selectedApp.value = type
            refreshStatuses()
        }
    }

    fun setSelectedFilter(filter: StatusFilter) {
        _selectedFilter.value = filter
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun refreshStatuses() {
        viewModelScope.launch {
            _isLoading.value = true
            val context = getApplication<Application>()
            val currentType = _selectedApp.value

            val items = WhatsAppStatusManager.loadStatuses(context, currentType)
            val saved = WhatsAppStatusManager.loadSavedStatuses(context)

            _statuses.value = items
            _savedStatuses.value = saved

            // Check if permission prompt is needed:
            val treeUri = WhatsAppStatusManager.getPersistedTreeUri(context, currentType)
            val storageGranted = WhatsAppStatusManager.isStorageAccessGranted(context)
            _hasAccessPermission.value = items.isNotEmpty() || treeUri != null || storageGranted

            _isLoading.value = false
        }
    }

    fun onTreeUriGranted(uri: Uri) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) {
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (ex: Exception) {
                    ex.printStackTrace()
                }
            }
            WhatsAppStatusManager.savePersistedTreeUri(context, _selectedApp.value, uri)
            _hasAccessPermission.value = true
            refreshStatuses()
            _userMessage.value = "Folder access granted successfully! ✅"
        }
    }

    fun saveStatus(status: WhatsAppStatus) {
        viewModelScope.launch {
            _isSaving.value = true
            val context = getApplication<Application>()
            val success = WhatsAppStatusManager.saveStatusToGallery(context, status)
            if (success) {
                // Update local status item to saved = true
                _statuses.value = _statuses.value.map {
                    if (it.id == status.id || it.title == status.title) it.copy(isSaved = true) else it
                }
                // Reload saved statuses
                _savedStatuses.value = WhatsAppStatusManager.loadSavedStatuses(context)
                _userMessage.value = if (status.isVideo) "Video saved to Gallery! 🎬" else "Photo saved to Gallery! 📸"
            } else {
                _userMessage.value = "Failed to save status. Please try again."
            }
            _isSaving.value = false
        }
    }

    fun shareStatus(status: WhatsAppStatus) {
        val context = getApplication<Application>()
        WhatsAppStatusManager.shareStatus(context, status)
    }

    fun repostStatus(status: WhatsAppStatus) {
        val context = getApplication<Application>()
        val packageName = _selectedApp.value.packageName
        WhatsAppStatusManager.shareStatus(context, status, targetPackage = packageName)
    }

    fun createTreeUriIntent(): Intent {
        return WhatsAppStatusManager.createOpenDocumentTreeIntent(_selectedApp.value == WhatsAppType.WHATSAPP_BUSINESS)
    }
}
