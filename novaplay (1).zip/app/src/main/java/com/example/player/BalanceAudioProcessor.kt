package com.example.player

import androidx.annotation.OptIn
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.audio.AudioProcessor.UnhandledAudioFormatException
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.nio.ByteOrder

@OptIn(UnstableApi::class)
class BalanceAudioProcessor : AudioProcessor {
    private var leftVolume = 1.0f
    private var rightVolume = 1.0f
    private var balanceValue = 0.0f
    
    // Vocal Remover (Karaoke) parameters
    @Volatile
    var vocalRemoverEnabled: Boolean = false
        private set
    @Volatile
    var vocalCutLevel: Float = 1.0f
        private set
    @Volatile
    var bassRetention: Float = 0.85f
        private set
        
    private var lowpassBass = 0.0f

    private var pendingInputAudioFormat = AudioFormat.NOT_SET
    private var inputAudioFormat = AudioFormat.NOT_SET
    private var buffer = AudioProcessor.EMPTY_BUFFER
    private var outputBuffer = AudioProcessor.EMPTY_BUFFER
    private var inputEnded = false

    fun setBalance(balance: Float) {
        balanceValue = balance
        // balance ranges from -1.0f (full left) to 1.0f (full right)
        if (balance < 0) {
            leftVolume = 1.0f
            rightVolume = 1.0f + balance
        } else {
            leftVolume = 1.0f - balance
            rightVolume = 1.0f
        }
    }

    fun getBalance(): Float = balanceValue

    fun setVocalRemover(enabled: Boolean, cutLevel: Float = 1.0f, bassBoost: Float = 0.85f) {
        vocalRemoverEnabled = enabled
        vocalCutLevel = cutLevel.coerceIn(0.0f, 1.0f)
        bassRetention = bassBoost.coerceIn(0.0f, 1.0f)
    }

    override fun configure(inputAudioFormat: AudioFormat): AudioFormat {
        if (inputAudioFormat.encoding != androidx.media3.common.C.ENCODING_PCM_16BIT) {
            throw UnhandledAudioFormatException(inputAudioFormat)
        }
        pendingInputAudioFormat = inputAudioFormat
        return if (inputAudioFormat.channelCount == 2) inputAudioFormat else AudioFormat.NOT_SET
    }

    override fun isActive(): Boolean {
        return pendingInputAudioFormat.channelCount == 2
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!inputBuffer.hasRemaining()) return
        val position = inputBuffer.position()
        val limit = inputBuffer.limit()
        val size = limit - position
        
        if (buffer.capacity() < size) {
            buffer = ByteBuffer.allocateDirect(size).order(ByteOrder.nativeOrder())
        } else {
            buffer.clear()
        }

        // Process stereo 16-bit PCM audio samples
        val isVocalMute = vocalRemoverEnabled
        val cut = vocalCutLevel
        val bassBoost = bassRetention

        while (inputBuffer.hasRemaining()) {
            if (inputBuffer.remaining() < 4) {
                // Not enough bytes for a full stereo sample, copy remaining
                while (inputBuffer.hasRemaining()) {
                    buffer.put(inputBuffer.get())
                }
                break
            }
            val leftSample = inputBuffer.getShort()
            val rightSample = inputBuffer.getShort()

            if (isVocalMute) {
                // Vocal Center Channel Cancellation + Bass Retention (OOPS DSP)
                val center = (leftSample.toFloat() + rightSample.toFloat()) * 0.5f
                // Lowpass filter for preserving kick drums and bass guitar (<200Hz)
                lowpassBass += 0.035f * (center - lowpassBass)
                
                // Side channel: vocals cancel out because they are in the center
                val side = (leftSample.toFloat() - rightSample.toFloat()) * 0.5f
                
                // Instrumental reconstruction: side + preserved punchy bass
                val karaokeL = (side * 1.15f + lowpassBass * bassBoost)
                val karaokeR = (-side * 1.15f + lowpassBass * bassBoost)
                
                // Blend with original based on cut level and apply stereo balance
                val finalL = (leftSample * (1.0f - cut) + karaokeL * cut) * leftVolume
                val finalR = (rightSample * (1.0f - cut) + karaokeR * cut) * rightVolume

                buffer.putShort(finalL.toInt().coerceIn(-32768, 32767).toShort())
                buffer.putShort(finalR.toInt().coerceIn(-32768, 32767).toShort())
            } else {
                val processedLeft = (leftSample * leftVolume).toInt().coerceIn(-32768, 32767).toShort()
                val processedRight = (rightSample * rightVolume).toInt().coerceIn(-32768, 32767).toShort()

                buffer.putShort(processedLeft)
                buffer.putShort(processedRight)
            }
        }
        buffer.flip()
        outputBuffer = buffer
    }

    override fun queueEndOfStream() {
        inputEnded = true
    }

    override fun getOutput(): ByteBuffer {
        val out = outputBuffer
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        return out
    }

    override fun isEnded(): Boolean {
        return inputEnded && outputBuffer == AudioProcessor.EMPTY_BUFFER
    }

    override fun flush() {
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        inputEnded = false
        lowpassBass = 0.0f
        inputAudioFormat = pendingInputAudioFormat
    }

    override fun reset() {
        flush()
        buffer = AudioProcessor.EMPTY_BUFFER
        pendingInputAudioFormat = AudioFormat.NOT_SET
        inputAudioFormat = AudioFormat.NOT_SET
    }
}
