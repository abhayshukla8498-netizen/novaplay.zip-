package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Download
import com.example.downloader.ui.DownloaderScreen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.Brush
import com.example.ui.components.EdgeLightingOverlay
import com.example.ui.viewmodel.MediaConversionState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.database.AppDatabase
import com.example.data.repository.MediaRepository
import com.example.ui.components.*
import com.example.ui.components.Text
import com.example.ui.components.Icon
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.LocalIsLightTheme
import com.example.ui.viewmodel.MediaViewModel
import com.example.ui.viewmodel.MediaViewModelFactory
import com.example.ui.viewmodel.MediaStoreViewModel
import com.example.ui.viewmodel.MediaStoreViewModelFactory
import com.example.ui.viewmodel.SmartCollectionsViewModel
import com.example.ui.viewmodel.SmartCollectionsViewModelFactory
import com.example.ui.viewmodel.MusicViewModel
import com.example.ui.viewmodel.MusicViewModelFactory
import com.example.ui.viewmodel.WifiTransferViewModel
import com.example.ui.viewmodel.WifiTransferViewModelFactory

class MainActivity : androidx.fragment.app.FragmentActivity() {
    private lateinit var viewModel: MediaViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Use manual Dependency Injection via Application Container
        val appContainer = (application as VidiopenApplication).container
        val repository = appContainer.mediaRepository
        val factory = MediaViewModelFactory(application, repository)
        viewModel = ViewModelProvider(this, factory)[MediaViewModel::class.java]

        val mediaStoreRepository = appContainer.mediaStoreRepository
        val mediaStoreFactory = MediaStoreViewModelFactory(application, mediaStoreRepository)
        val mediaStoreViewModel = ViewModelProvider(this, mediaStoreFactory)[MediaStoreViewModel::class.java]

        val smartCollectionsFactory = SmartCollectionsViewModelFactory(application, repository)
        val smartCollectionsViewModel = ViewModelProvider(this, smartCollectionsFactory)[SmartCollectionsViewModel::class.java]

        val musicRepository = appContainer.musicRepository
        val musicPlayerManager = appContainer.musicPlayerManager
        val musicThemeRepository = appContainer.musicThemeRepository
        val musicFactory = MusicViewModelFactory(application, musicRepository, musicPlayerManager, musicThemeRepository)
        val musicViewModel = ViewModelProvider(this, musicFactory)[MusicViewModel::class.java]

        val wifiTransferRepository = appContainer.wifiTransferRepository
        val wifiTransferFactory = WifiTransferViewModelFactory(application, wifiTransferRepository)
        val wifiTransferViewModel = ViewModelProvider(this, wifiTransferFactory)[WifiTransferViewModel::class.java]

        // Immediately trigger fast media scan for videos and music as soon as app launches / starts
        mediaStoreViewModel.scanVideos()
        musicViewModel.scanMusicFiles(forceRefresh = false)

        setContent {
            val selectedThemeId by viewModel.selectedThemeId.collectAsState()
            val musicCustomThemeUri by musicViewModel.customThemeImageUri.collectAsState()
            val musicThemeState by musicViewModel.currentTheme.collectAsState()
            val customBackgroundUri by viewModel.customBackgroundUri.collectAsState()

            val effectiveCustomBackgroundUri = if (customBackgroundUri.isNotEmpty()) customBackgroundUri else (musicCustomThemeUri ?: "")
            val effectiveThemeId = if (selectedThemeId == "custom_image" || musicThemeState.id == "custom_image" || effectiveCustomBackgroundUri.isNotEmpty()) {
                "custom_image"
            } else {
                selectedThemeId
            }

            MyApplicationTheme(isLightTheme = effectiveThemeId == "light_color") {
                VidiopenAppFrame(
                    viewModel = viewModel,
                    mediaStoreViewModel = mediaStoreViewModel,
                    smartCollectionsViewModel = smartCollectionsViewModel,
                    musicViewModel = musicViewModel,
                    wifiTransferViewModel = wifiTransferViewModel
                )
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (::viewModel.isInitialized) {
            val isPlayingVideo = viewModel.currentPlayingMedia.value != null && 
                                 viewModel.currentPlayingMedia.value?.category != "Music"
            val autoEnter = viewModel.autoEnterPip.value
            if (isPlayingVideo && autoEnter) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    val params = android.app.PictureInPictureParams.Builder().build()
                    enterPictureInPictureMode(params)
                }
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (::viewModel.isInitialized) {
            viewModel.setIsInPictureInPictureMode(isInPictureInPictureMode)
        }
    }
}

sealed class Screen(val route: String, val title: String, val activeIcon: ImageVector, val inactiveIcon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Filled.Home, Icons.Outlined.Home)
    object Videos : Screen("videos", "VIDEO", Icons.Filled.Movie, Icons.Outlined.Movie)
    object Music : Screen("music", "MUSIC", Icons.Filled.MusicNote, Icons.Outlined.MusicNote)
    object Downloader : Screen("downloader", "Download Now", Icons.Filled.Download, Icons.Outlined.Download)
    object Files : Screen("files", "Files", Icons.Filled.Folder, Icons.Outlined.Folder)
    object Settings : Screen("settings", "Me", Icons.Filled.Person, Icons.Outlined.Person)
    object Vault : Screen("vault", "Privacy", Icons.Filled.Lock, Icons.Outlined.Lock) // Separate route
}

@Composable
fun VidiopenAppFrame(
    viewModel: MediaViewModel,
    mediaStoreViewModel: MediaStoreViewModel,
    smartCollectionsViewModel: com.example.ui.viewmodel.SmartCollectionsViewModel,
    musicViewModel: MusicViewModel,
    wifiTransferViewModel: WifiTransferViewModel
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val context = androidx.compose.ui.platform.LocalContext.current

    val currentPlayingMedia by viewModel.currentPlayingMedia.collectAsState()
    val appLanguage by viewModel.appLanguage.collectAsState()
    val customBackgroundUri by viewModel.customBackgroundUri.collectAsState()
    val selectedThemeId by viewModel.selectedThemeId.collectAsState()
    val offlineCurrentPlayingSong by musicViewModel.currentPlayingSong.collectAsState()
    var isMusicPlaying by remember { mutableStateOf(false) }
    var isMusicExpanded by remember { mutableStateOf(false) }
    var showSplash by remember { mutableStateOf(true) }

    val isVideoPlaying = currentPlayingMedia != null && currentPlayingMedia?.category != "Music"
    val isFloatingMode by viewModel.isFloatingMode.collectAsState()

    androidx.activity.compose.BackHandler(enabled = isMusicExpanded) {
        isMusicExpanded = false
    }

    androidx.activity.compose.BackHandler(enabled = isVideoPlaying && !isFloatingMode) {
        val activeMedia = currentPlayingMedia
        if (activeMedia != null) {
            val lastPos = try {
                viewModel.getOrCreatePlayer(context).currentPosition
            } catch (e: Exception) {
                0L
            }
            viewModel.updatePlaybackPosition(activeMedia.id, lastPos)
            viewModel.closePlayer()
        }
    }

    val scannedVideos by mediaStoreViewModel.scannedVideos.collectAsState()
    LaunchedEffect(scannedVideos) {
        smartCollectionsViewModel.updateScannedVideos(scannedVideos)
    }

    // Navigation items
    val navigationItems = listOf(
        Screen.Videos,
        Screen.Music,
        Screen.Downloader,
        Screen.Settings
    )

    val musicCustomThemeUri by musicViewModel.customThemeImageUri.collectAsState()
    val musicThemeState by musicViewModel.currentTheme.collectAsState()

    val customThemeScaleType by viewModel.customThemeScaleType.collectAsState()
    val customThemeZoom by viewModel.customThemeZoom.collectAsState()
    val customThemeOpacity by viewModel.customThemeOpacity.collectAsState()
    val customThemeAlignment by viewModel.customThemeAlignment.collectAsState()

    val effectiveCustomBackgroundUri = if (customBackgroundUri.isNotEmpty()) {
        customBackgroundUri
    } else {
        musicCustomThemeUri ?: ""
    }

    val effectiveThemeId = if (selectedThemeId == "custom_image" || musicThemeState.id == "custom_image" || effectiveCustomBackgroundUri.isNotEmpty()) {
        "custom_image"
    } else {
        selectedThemeId
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (!showSplash) {
            AppThemeBackground(
                selectedThemeId = effectiveThemeId,
                customBackgroundUri = effectiveCustomBackgroundUri,
                scaleType = customThemeScaleType,
                zoomScale = customThemeZoom,
                overlayOpacity = customThemeOpacity,
                alignment = customThemeAlignment
            )
        }
        if (showSplash) {
            SplashAnimationScreen(
                appLanguage = appLanguage,
                onFinished = { showSplash = false }
            )
        } else {
            Scaffold(
            bottomBar = {
                // Only show bottom navigation if a full screen video player is NOT open
                val isMusicTrackPlaying = offlineCurrentPlayingSong != null
                val isVideoPlaying = currentPlayingMedia != null && currentPlayingMedia?.category != "Music"
                val isHideBottomBarRoute = currentRoute == "vault" || currentRoute == "wifi_transfer" || currentRoute == "status_saver"

                if (!isVideoPlaying && !isHideBottomBarRoute) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                    ) {
                        // Persistently present mini player if a music track is active and not expanded
                        if (isMusicTrackPlaying && !isMusicExpanded) {
                            MusicMiniPlayer(
                                musicViewModel = musicViewModel,
                                onExpand = { isMusicExpanded = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 8.dp)
                            )
                        }

                        // Glassmorphic navigation bar
                        val isLightNav = LocalIsLightTheme.current
                        NavigationBar(
                            containerColor = if (isLightNav) Color.White.copy(alpha = 0.95f) else Color.Black.copy(alpha = 0.85f),
                            tonalElevation = 8.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(64.dp)
                                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                                .testTag("bottom_nav_bar")
                        ) {
                            navigationItems.forEach { screen ->
                                val selected = currentRoute == screen.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = {
                                        try {
                                            if (currentRoute != screen.route) {
                                                navController.navigate(screen.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) {
                                                        saveState = true
                                                    }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            }
                                        } catch (e: Exception) {
                                            try {
                                                navController.navigate(screen.route)
                                            } catch (e2: Exception) {
                                                timber.log.Timber.e(e2, "Navigation error switching tab to ${screen.route}")
                                            }
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) screen.activeIcon else screen.inactiveIcon,
                                            contentDescription = screen.title,
                                            tint = if (selected) (if (isLightNav) Color.Black else Color(0xFF10B981)) else (if (isLightNav) Color.DarkGray else Color.Gray)
                                        )
                                    },
                                    label = {
                                        val translatedLabel = when (screen.title) {
                                            "VIDEO" -> if (appLanguage == "hi") "वीडियो" else "VIDEO"
                                            "MUSIC" -> if (appLanguage == "hi") "संगीत" else "MUSIC"
                                            "Download Now" -> if (appLanguage == "hi") "डाउनलोड" else "Download Now"
                                            "ME", "Me" -> if (appLanguage == "hi") "मैं" else "Me"
                                            else -> screen.title
                                        }
                                        Text(
                                            text = translatedLabel,
                                            color = if (selected) (if (isLightNav) Color.Black else Color(0xFF10B981)) else (if (isLightNav) Color.DarkGray else Color.Gray),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        indicatorColor = if (isLightNav) Color.Black.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.1f)
                                    ),
                                    modifier = Modifier.testTag("nav_item_${screen.route}")
                                )
                            }
                        }
                    }
                }
            },
            containerColor = Color.Transparent
        ) { innerPadding ->
            // Sub-screen safe navigator to prevent any crash when navigating between features
            val safeNavigate: (String) -> Unit = { targetRoute ->
                try {
                    when {
                        targetRoute == "movies" || targetRoute == "tvshows" -> {
                            navController.navigate("videos/$targetRoute") {
                                launchSingleTop = true
                            }
                        }
                        targetRoute == "music" -> {
                            navController.navigate(Screen.Music.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                        targetRoute == "videos" || targetRoute == "video" -> {
                            navController.navigate(Screen.Videos.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                        targetRoute == "settings" || targetRoute == "me" -> {
                            navController.navigate(Screen.Settings.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                        targetRoute == "downloader" || targetRoute == "download" -> {
                            navController.navigate(Screen.Downloader.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                        targetRoute == "files" -> {
                            navController.navigate(Screen.Files.route) {
                                launchSingleTop = true
                            }
                        }
                        targetRoute in listOf("vault", "wifi_transfer", "status_saver") ||
                        targetRoute.startsWith("collection/") ||
                        targetRoute.startsWith("videos/") -> {
                            navController.navigate(targetRoute) {
                                launchSingleTop = true
                            }
                        }
                        else -> {
                            timber.log.Timber.w("MainActivity: Target route not recognized: $targetRoute")
                        }
                    }
                } catch (e: Exception) {
                    timber.log.Timber.e(e, "MainActivity: Navigation failed for route $targetRoute")
                }
            }

            NavHost(
                navController = navController,
                startDestination = Screen.Videos.route,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = if (currentPlayingMedia != null || currentRoute == "vault" || currentRoute == "wifi_transfer" || currentRoute == "status_saver") 0.dp else innerPadding.calculateBottomPadding())
            ) {
                composable(Screen.Home.route) {
                    HomeScreen(
                        viewModel = viewModel,
                        smartCollectionsViewModel = smartCollectionsViewModel,
                        onNavigateToSection = safeNavigate,
                        onPlayVideo = { video ->
                            try {
                                musicViewModel.pause()
                            } catch (e: Exception) {
                                timber.log.Timber.e(e, "Error pausing music")
                            }
                            viewModel.playMedia(video)
                        },
                        onOpenVault = { safeNavigate("vault") },
                        onAddCustomVideo = { viewModel.addLocalVideo("Cinema", "", 120000) }
                    )
                }

                composable("collection/{collectionId}") { backStackEntry ->
                    val collectionId = backStackEntry.arguments?.getString("collectionId") ?: ""
                    CollectionDetailScreen(
                        collectionId = collectionId,
                        viewModel = viewModel,
                        smartCollectionsViewModel = smartCollectionsViewModel,
                        onBack = { navController.popBackStack() },
                        onPlayVideo = { video ->
                            try {
                                musicViewModel.pause()
                            } catch (e: Exception) {
                                timber.log.Timber.e(e, "Error pausing music")
                            }
                            viewModel.playMedia(video)
                        }
                    )
                }

                composable("videos") {
                    VideosScreen(
                        viewModel = viewModel,
                        mediaStoreViewModel = mediaStoreViewModel,
                        initialCategory = "movies",
                        smartCollectionsViewModel = smartCollectionsViewModel,
                        onNavigateToSection = safeNavigate
                    ) { video ->
                        try {
                            musicViewModel.pause()
                        } catch (e: Exception) {
                            timber.log.Timber.e(e, "Error pausing music")
                        }
                        viewModel.playMedia(video)
                    }
                }

                composable("videos/{category}") { backStackEntry ->
                    val category = backStackEntry.arguments?.getString("category") ?: "movies"
                    VideosScreen(
                        viewModel = viewModel,
                        mediaStoreViewModel = mediaStoreViewModel,
                        initialCategory = category,
                        smartCollectionsViewModel = smartCollectionsViewModel,
                        onNavigateToSection = safeNavigate
                    ) { video ->
                        try {
                            musicViewModel.pause()
                        } catch (e: Exception) {
                            timber.log.Timber.e(e, "Error pausing music")
                        }
                        viewModel.playMedia(video)
                    }
                }

                composable(Screen.Music.route) {
                    MusicScreen(
                        viewModel = viewModel,
                        musicViewModel = musicViewModel
                    ) { track ->
                        try {
                            viewModel.closePlayer()
                        } catch (e: Exception) {
                            timber.log.Timber.e(e, "Error closing video player")
                        }
                        viewModel.playMedia(track)
                        isMusicPlaying = true
                    }
                }

                composable(Screen.Files.route) {
                    FilesScreen(
                        viewModel = viewModel,
                        mediaStoreViewModel = mediaStoreViewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Screen.Settings.route) {
                    SettingsScreen(
                        viewModel = viewModel,
                        musicViewModel = musicViewModel,
                        onNavigateToSection = safeNavigate,
                        onOpenVault = { safeNavigate("vault") }
                    )
                }

                composable("vault") {
                    PrivateVaultScreen(
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable("wifi_transfer") {
                    WifiTransferScreen(
                        wifiTransferViewModel = wifiTransferViewModel,
                        mediaViewModel = viewModel,
                        musicViewModel = musicViewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Screen.Downloader.route) {
                    DownloaderScreen(
                        onPlayVideo = { videoFile ->
                            try {
                                musicViewModel.pause()
                            } catch (e: Exception) {
                                timber.log.Timber.e(e, "Error pausing music")
                            }
                            viewModel.playMedia(
                                com.example.data.model.MediaEntity(
                                    id = videoFile.absolutePath,
                                    title = videoFile.nameWithoutExtension,
                                    url = videoFile.absolutePath,
                                    duration = 0L,
                                    artist = "Vidiopen Downloader",
                                    thumbnailUrl = null,
                                    category = "Downloaded"
                                )
                            )
                        },
                        onOpenStatusSaver = { safeNavigate("status_saver") }
                    )
                }

                composable("status_saver") {
                    com.example.ui.screens.StatusSaverScreen(
                        mediaViewModel = viewModel,
                        onBack = { navController.popBackStack() },
                        showTopBar = true
                    )
                }
            }
        }

        // Expanded full-screen Music Player Layer
        val isMusicTrackActive = offlineCurrentPlayingSong != null
        val isMusicCurrentlyPlaying by musicViewModel.isPlaying.collectAsState()
        val edgeLightingEnabled by musicViewModel.edgeLightingEnabled.collectAsState()
        val edgeLightingStyle by musicViewModel.edgeLightingStyle.collectAsState()
        val edgeLightingIntensity by musicViewModel.edgeLightingIntensity.collectAsState()

        // Edge Lighting Effect across the screen borders when music is playing
        if (edgeLightingEnabled && !isMusicExpanded && isMusicCurrentlyPlaying && isMusicTrackActive) {
            EdgeLightingOverlay(
                isPlaying = true,
                style = edgeLightingStyle,
                intensity = edgeLightingIntensity,
                cornerRadius = 0.dp
            )
        }

        AnimatedVisibility(
            visible = isMusicTrackActive && isMusicExpanded,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            MusicExpandedPlayer(
                musicViewModel = musicViewModel,
                mediaViewModel = viewModel,
                onCollapse = { isMusicExpanded = false }
            )
        }

        // Full Screen Video Player Layer
        val isVideoPlaying = currentPlayingMedia != null && currentPlayingMedia?.category != "Music"
        val isFloatingMode by viewModel.isFloatingMode.collectAsState()

        AnimatedVisibility(
            visible = isVideoPlaying && !isFloatingMode,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            val activeMedia = currentPlayingMedia
            if (activeMedia != null) {
                VideoPlayerView(
                    media = activeMedia,
                    viewModel = viewModel,
                    onClose = { lastPos ->
                        viewModel.updatePlaybackPosition(activeMedia.id, lastPos)
                        viewModel.closePlayer()
                    },
                    onAudioConverted = {
                        musicViewModel.scanMusicFiles()
                    },
                    onNavigateToMusic = {
                        navController.navigate(Screen.Music.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    musicViewModel = musicViewModel
                )
            }
        }

        // Floating Window Video Player Layer
        val activeFloatingMedia = currentPlayingMedia
        if (isFloatingMode && isVideoPlaying && activeFloatingMedia != null) {
            FloatingVideoPlayer(
                media = activeFloatingMedia,
                viewModel = viewModel,
                onClose = {
                    viewModel.closePlayer()
                },
                onReturnToFull = {
                    viewModel.setFloatingMode(false)
                }
            )
        }

        // First launch language selection overlay
        androidx.compose.animation.AnimatedVisibility(
            visible = appLanguage.isEmpty(),
            enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(400)) + androidx.compose.animation.scaleIn(initialScale = 0.95f),
            exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(300)) + androidx.compose.animation.scaleOut(targetScale = 1.05f)
        ) {
            com.example.ui.components.LanguageSelectionOverlay(
                onLanguageSelected = { lang ->
                    viewModel.setAppLanguage(lang)
                    android.widget.Toast.makeText(
                        context,
                        if (lang == "hi") "Vidiopen Pro में आपका स्वागत है! (हिन्दी)" else "Welcome to Vidiopen Pro! (English)",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            )
        }

        // Global High-Fidelity MP3 Conversion Dialog
        val conversionState by viewModel.conversionState.collectAsState()
        if (conversionState !is MediaConversionState.Idle) {
            GlobalConversionDialog(
                state = conversionState,
                appLanguage = appLanguage,
                onDismiss = { viewModel.clearConversionState() },
                onPlayConvertedSong = { filePath, fileName, title ->
                    viewModel.clearConversionState()
                    try {
                        viewModel.closePlayer()
                    } catch (e: Exception) {}
                    musicViewModel.scanMusicFiles(forceRefresh = true)
                    viewModel.playMedia(
                        com.example.data.model.MediaEntity(
                            id = filePath,
                            title = title ?: fileName,
                            url = filePath,
                            duration = 180000L,
                            artist = "Converted MP3",
                            thumbnailUrl = null,
                            category = "Music"
                        )
                    )
                    isMusicPlaying = true
                }
            )
        }
        }
    }
}

// -----------------------------------------------------------------------------
// GLOBAL HIGH-FIDELITY MP3 CONVERSION DIALOG
// -----------------------------------------------------------------------------
@Composable
fun GlobalConversionDialog(
    state: MediaConversionState,
    appLanguage: String,
    onDismiss: () -> Unit,
    onPlayConvertedSong: (filePath: String, fileName: String, videoTitle: String?) -> Unit
) {
    Dialog(
        onDismissRequest = {
            if (state !is MediaConversionState.Converting) {
                onDismiss()
            }
        },
        properties = DialogProperties(
            dismissOnBackPress = state !is MediaConversionState.Converting,
            dismissOnClickOutside = state !is MediaConversionState.Converting
        )
    ) {
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = BorderStroke(
                1.5.dp,
                when (state) {
                    is MediaConversionState.Converting -> Color(0xFF10B981).copy(alpha = 0.5f)
                    is MediaConversionState.Success -> Color(0xFF10B981)
                    is MediaConversionState.Error -> Color(0xFFEF4444)
                    else -> Color.Transparent
                }
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (state) {
                    is MediaConversionState.Converting -> {
                        // Header
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF10B981).copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.5.dp,
                                    color = Color(0xFF10B981)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (appLanguage == "hi") "MP3 कनवर्ट हो रहा है..." else "Converting to MP3...",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Video title card
                        if (state.videoTitle != null) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFF1E293B),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0xFF833AB4), Color(0xFFFD1D1D))
                                                )
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.MusicNote,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = state.videoTitle,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color.White,
                                            maxLines = 1,
                                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = if (appLanguage == "hi") "मूल वीडियो" else "Source Video",
                                            fontSize = 11.sp,
                                            color = Color(0xFF10B981)
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                        }

                        // Progress Bar
                        LinearProgressIndicator(
                            progress = { state.progress },
                            color = Color(0xFF10B981),
                            trackColor = Color(0xFF334155),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = state.statusMessage,
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.7f),
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${(state.progress * 100).toInt()}%",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF10B981)
                            )
                        }
                    }

                    is MediaConversionState.Success -> {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981).copy(alpha = 0.18f))
                                .border(1.5.dp, Color(0xFF10B981), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("✓", fontSize = 28.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = if (appLanguage == "hi") "🎉 MP3 कनवर्ट हो गया!" else "🎉 MP3 Conversion Successful!",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = state.fileName,
                            fontSize = 13.sp,
                            color = Color(0xFF00E5FF),
                            fontWeight = FontWeight.SemiBold,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            maxLines = 2,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = if (appLanguage == "hi") "फ़ाइल Music/Vidiopen में सुरक्षित सेव हो गई है" else "Saved safely in Music/Vidiopen",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        // Action Buttons: "Play Now" and "Done"
                        Button(
                            onClick = {
                                onPlayConvertedSong(state.filePath, state.fileName, state.videoTitle)
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                            contentPadding = PaddingValues(vertical = 12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (appLanguage == "hi") "अभी गाना चलाएं (Play Now)" else "Play Song Now",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = if (appLanguage == "hi") "बंद करें (Done)" else "Done", fontSize = 13.sp)
                        }
                    }

                    is MediaConversionState.Error -> {
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEF4444).copy(alpha = 0.15f))
                                .border(1.5.dp, Color(0xFFEF4444), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("✕", fontSize = 24.sp, color = Color(0xFFEF4444), fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = if (appLanguage == "hi") "कन्वर्जन पूरा नहीं हो सका" else "Conversion Failed",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = state.errorMessage,
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.7f),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = if (appLanguage == "hi") "ठीक है (OK)" else "OK", fontSize = 13.sp)
                        }
                    }

                    else -> {}
                }
            }
        }
    }
}

@Composable
fun AppThemeBackground(
    selectedThemeId: String,
    customBackgroundUri: String,
    scaleType: String = "CROP",
    zoomScale: Float = 1.0f,
    overlayOpacity: Float = 0.55f,
    alignment: String = "CENTER"
) {
    Box(modifier = Modifier.fillMaxSize()) {
        when (selectedThemeId) {
            "light_color" -> {
                // Light color vibrant abstract gradient theme
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFFF1F5F9),
                                    Color(0xFFF8FAFC),
                                    Color(0xFFEFF6FF)
                                )
                            )
                        )
                ) {
                    // Soft vibrant ambient wave glows
                    androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                        drawCircle(
                            color = Color(0xFF38BDF8).copy(alpha = 0.15f),
                            radius = size.width * 0.7f,
                            center = androidx.compose.ui.geometry.Offset(size.width * 0.9f, size.height * 0.15f)
                        )
                        drawCircle(
                            color = Color(0xFFA855F7).copy(alpha = 0.12f),
                            radius = size.width * 0.8f,
                            center = androidx.compose.ui.geometry.Offset(-size.width * 0.1f, size.height * 0.5f)
                        )
                        drawCircle(
                            color = Color(0xFF10B981).copy(alpha = 0.14f),
                            radius = size.width * 0.7f,
                            center = androidx.compose.ui.geometry.Offset(size.width * 0.8f, size.height * 0.85f)
                        )
                    }
                }
            }
            "custom_image" -> {
                if (customBackgroundUri.isNotEmpty()) {
                    val fileModel = remember(customBackgroundUri) {
                        if (customBackgroundUri.startsWith("file://")) {
                            val path = android.net.Uri.parse(customBackgroundUri).path
                            if (path != null) java.io.File(path) else customBackgroundUri
                        } else if (customBackgroundUri.startsWith("/")) {
                            java.io.File(customBackgroundUri)
                        } else {
                            customBackgroundUri
                        }
                    }

                    val contentScale = when (scaleType) {
                        "FIT" -> androidx.compose.ui.layout.ContentScale.Fit
                        "FILL_BOUNDS" -> androidx.compose.ui.layout.ContentScale.FillBounds
                        "INSIDE" -> androidx.compose.ui.layout.ContentScale.Inside
                        else -> androidx.compose.ui.layout.ContentScale.Crop
                    }

                    val contentAlignment = when (alignment) {
                        "TOP" -> androidx.compose.ui.Alignment.TopCenter
                        "BOTTOM" -> androidx.compose.ui.Alignment.BottomCenter
                        else -> androidx.compose.ui.Alignment.Center
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black),
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        coil.compose.AsyncImage(
                            model = fileModel,
                            contentDescription = "Custom theme background",
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(
                                    scaleX = zoomScale.coerceIn(0.5f, 3.0f),
                                    scaleY = zoomScale.coerceIn(0.5f, 3.0f)
                                ),
                            contentScale = contentScale,
                            alignment = contentAlignment
                        )

                        // High contrast vertical gradient scrim & opacity overlay
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = overlayOpacity.coerceIn(0.05f, 0.95f)))
                        )
                    }
                } else {
                    // Fallback to dark_color
                    DarkStarryBackground()
                }
            }
            else -> { // "dark_color" or default
                DarkStarryBackground()
            }
        }
    }
}

@Composable
fun DarkStarryBackground() {
    val bgBrush = remember {
        androidx.compose.ui.graphics.Brush.verticalGradient(
            colors = listOf(
                Color(0xFF0F172A),
                Color(0xFF0D0E15),
                Color(0xFF050508)
            )
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgBrush)
    ) {
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            // Vibrant cosmic aurora ambient radial glows
            drawCircle(
                color = Color(0xFF00D9FF).copy(alpha = 0.12f),
                radius = size.width * 0.75f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.85f, size.height * 0.12f)
            )
            drawCircle(
                color = Color(0xFF7C4DFF).copy(alpha = 0.14f),
                radius = size.width * 0.85f,
                center = androidx.compose.ui.geometry.Offset(-size.width * 0.1f, size.height * 0.45f)
            )
            drawCircle(
                color = Color(0xFFFF2E93).copy(alpha = 0.08f),
                radius = size.width * 0.6f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.25f)
            )
            drawCircle(
                color = Color(0xFF10B981).copy(alpha = 0.18f),
                radius = size.width * 0.7f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.6f, size.height * 1.05f)
            )
            drawCircle(
                color = Color(0xFF047857).copy(alpha = 0.25f),
                radius = size.width * 0.45f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.6f, size.height * 1.05f)
            )

            // Draw stars directly with fixed relative coordinates to avoid list allocations
            val w = size.width
            val h = size.height
            drawCircle(Color.White.copy(alpha = 0.85f), 3.5f, androidx.compose.ui.geometry.Offset(w * 0.15f, h * 0.08f))
            drawCircle(Color.White.copy(alpha = 0.5f), 2f, androidx.compose.ui.geometry.Offset(w * 0.35f, h * 0.12f))
            drawCircle(Color.White.copy(alpha = 0.5f), 2f, androidx.compose.ui.geometry.Offset(w * 0.72f, h * 0.05f))
            drawCircle(Color.White.copy(alpha = 0.85f), 3.5f, androidx.compose.ui.geometry.Offset(w * 0.85f, h * 0.18f))
            drawCircle(Color.White.copy(alpha = 0.5f), 2f, androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.15f))
            drawCircle(Color.White.copy(alpha = 0.5f), 2f, androidx.compose.ui.geometry.Offset(w * 0.25f, h * 0.22f))
            drawCircle(Color.White.copy(alpha = 0.85f), 3.5f, androidx.compose.ui.geometry.Offset(w * 0.62f, h * 0.28f))
            drawCircle(Color.White.copy(alpha = 0.5f), 2f, androidx.compose.ui.geometry.Offset(w * 0.9f, h * 0.35f))
            drawCircle(Color.White.copy(alpha = 0.5f), 2f, androidx.compose.ui.geometry.Offset(w * 0.1f, h * 0.4f))
            drawCircle(Color.White.copy(alpha = 0.85f), 3.5f, androidx.compose.ui.geometry.Offset(w * 0.45f, h * 0.04f))

            // Draw a bright sparkling star (diamond shape)
            val centerStarX = w * 0.55f
            val centerStarY = h * 0.1f
            val path = androidx.compose.ui.graphics.Path().apply {
                moveTo(centerStarX, centerStarY - 10f)
                lineTo(centerStarX + 4f, centerStarY - 2f)
                lineTo(centerStarX + 10f, centerStarY)
                lineTo(centerStarX + 4f, centerStarY + 2f)
                lineTo(centerStarX, centerStarY + 10f)
                lineTo(centerStarX - 4f, centerStarY + 2f)
                lineTo(centerStarX - 10f, centerStarY)
                lineTo(centerStarX - 4f, centerStarY - 2f)
                close()
            }
            drawPath(path, Color.White.copy(alpha = 0.95f))

            drawCircle(
                color = Color.White.copy(alpha = 0.15f),
                radius = 18f,
                center = androidx.compose.ui.geometry.Offset(centerStarX, centerStarY)
            )
        }
    }
}

@androidx.compose.ui.tooling.preview.Preview(showBackground = true, showSystemUi = true)
@Composable
fun VidiopenAppPreview() {
    MyApplicationTheme {
        SplashAnimationScreen(
            appLanguage = "en",
            onFinished = {}
        )
    }
}

