package com.example.data.model

import androidx.compose.ui.graphics.Color

enum class MoodCategory(
    val id: String,
    val titleEn: String,
    val titleHi: String,
    val emoji: String,
    val gradientColors: List<Color>,
    val descriptionEn: String,
    val descriptionHi: String,
    val keywords: List<String>
) {
    WORKOUT(
        id = "workout",
        titleEn = "Workout",
        titleHi = "वर्कआउट & जिम",
        emoji = "⚡",
        gradientColors = listOf(Color(0xFFFF5722), Color(0xFFFF9800)),
        descriptionEn = "High energy & gym pumping beats",
        descriptionHi = "हाई एनर्जी, जोश और तेज़ बीट्स",
        keywords = listOf("workout", "gym", "pump", "power", "fitness", "run", "beast", "energy", "rock", "hard", "fast", "charge", "fire", "josh", "tezz", "dangal", "sultan", "bhaag", "motivat", "strong")
    ),
    LATE_NIGHT(
        id = "late_night",
        titleEn = "Late Night",
        titleHi = "देर रात / नाइट वाइब्स",
        emoji = "🌙",
        gradientColors = listOf(Color(0xFF3F51B5), Color(0xFF1A237E)),
        descriptionEn = "Deep, atmospheric & midnight tunes",
        descriptionHi = "धीमी, सुकून भरी रात की धुनें",
        keywords = listOf("night", "raat", "midnight", "moon", "star", "dark", "silent", "quiet", "sleep", "soja", "deep", "lofi", "lo-fi", "insomnia", "bedtime", "chandra", "lights", "stars")
    ),
    CHILL(
        id = "chill",
        titleEn = "Chill",
        titleHi = "सुकून / चिल & लो-फ़ाई",
        emoji = "☕",
        gradientColors = listOf(Color(0xFF009688), Color(0xFF4CAF50)),
        descriptionEn = "Relaxing acoustic & soothing sounds",
        descriptionHi = "आरामदेह, शांत और हल्की मेलोडी",
        keywords = listOf("chill", "relax", "calm", "coffee", "peace", "easy", "breeze", "morning", "sukoon", "shanti", "hawa", "chai", "acoustic", "soft", "zen", "fresh", "piano", "nature", "rain")
    ),
    ROMANTIC(
        id = "romantic",
        titleEn = "Romantic",
        titleHi = "रोमांटिक & दिल से",
        emoji = "💖",
        gradientColors = listOf(Color(0xFFE91E63), Color(0xFFFF4081)),
        descriptionEn = "Melodic love songs & soulful tunes",
        descriptionHi = "प्यार भरे गीत और दिल को छूने वाली आवाज़",
        keywords = listOf("romantic", "love", "dil", "ishq", "pyaar", "mohabbat", "heart", "humsafar", "jaan", "deewana", "sanam", "sweet", "tera", "meri", "kiss", "forever", "khuda", "sufi", "valentin", "soulmate")
    ),
    PARTY(
        id = "party",
        titleEn = "Party",
        titleHi = "पार्टी & डांस क्लब",
        emoji = "🎉",
        gradientColors = listOf(Color(0xFF9C27B0), Color(0xFFE040FB)),
        descriptionEn = "Upbeat dance, club bangers & remix",
        descriptionHi = "धमाकेदार पार्टी, रीमिक्स और डांस बीट्स",
        keywords = listOf("party", "dance", "club", "dj", "remix", "beat", "bass", "dhol", "bhangra", "sharab", "nach", "thumka", "disco", "mashup", "dhamaka", "blast", "celebration", "edm", "groove")
    ),
    SAD(
        id = "sad",
        titleEn = "Sad",
        titleHi = "दर्द & इमोशनल",
        emoji = "🌧️",
        gradientColors = listOf(Color(0xFF607D8B), Color(0xFF37474F)),
        descriptionEn = "Heartbreak & slow acoustic melodies",
        descriptionHi = "दर्द भरी धुनें और दिल के करीब एहसास",
        keywords = listOf("sad", "dard", "broken", "tears", "alone", "tanha", "judai", "bewafa", "cry", "pain", "bhula", "khamosh", "yaad", "rona", "sorrow", "grief", "melanchol", "alvida", "dhokha")
    );

    companion object {
        fun fromId(id: String): MoodCategory = entries.firstOrNull { it.id == id } ?: CHILL

        fun categorizeSong(song: ScannedSong, userOverride: String? = null): MoodCategory {
            if (!userOverride.isNullOrBlank()) {
                val matched = entries.firstOrNull { it.id == userOverride }
                if (matched != null) return matched
            }

            val text = "${song.title} ${song.artist ?: ""} ${song.album ?: ""} ${song.path}".lowercase()
            for (mood in entries) {
                if (mood.keywords.any { text.contains(it) }) {
                    return mood
                }
            }

            // Deterministic distributed fallback based on track identity
            val hash = kotlin.math.abs(song.id.hashCode() xor song.title.hashCode())
            val allMoods = entries
            return allMoods[hash % allMoods.size]
        }
    }
}
