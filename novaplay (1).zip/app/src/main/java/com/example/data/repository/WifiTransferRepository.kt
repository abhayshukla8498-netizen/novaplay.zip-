package com.example.data.repository

import android.content.Context
import android.net.wifi.WifiManager
import com.example.data.database.AppDatabase
import com.example.data.model.ActiveTransfer
import com.example.data.model.ConnectionRequest
import com.example.data.model.DiscoveredDevice
import com.example.data.model.TransferHistoryEntity
import com.example.data.model.TransferStatus
import com.example.service.WifiTransferServer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import timber.log.Timber
import java.io.File
import java.io.FileInputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale
import java.util.concurrent.TimeUnit

class WifiTransferRepository(private val database: AppDatabase) {

    private val repositoryScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var server: WifiTransferServer? = null

    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _serverIp = MutableStateFlow<String?>(null)
    val serverIp: StateFlow<String?> = _serverIp.asStateFlow()

    private val _serverPort = MutableStateFlow(8080)
    val serverPort: StateFlow<Int> = _serverPort.asStateFlow()

    private val _sessionCode = MutableStateFlow<String?>(null)
    val sessionCode: StateFlow<String?> = _sessionCode.asStateFlow()

    private val _connectionRequest = MutableStateFlow<ConnectionRequest?>(null)
    val connectionRequest: StateFlow<ConnectionRequest?> = _connectionRequest.asStateFlow()

    private val _activeTransfers = MutableStateFlow<List<ActiveTransfer>>(emptyList())
    val activeTransfers: StateFlow<List<ActiveTransfer>> = _activeTransfers.asStateFlow()

    private val _discoveredDevices = MutableStateFlow<List<String>>(emptyList())
    val discoveredDevices: StateFlow<List<String>> = _discoveredDevices.asStateFlow()

    private val _discoveredDeviceObjects = MutableStateFlow<List<DiscoveredDevice>>(emptyList())
    val discoveredDeviceObjects: StateFlow<List<DiscoveredDevice>> = _discoveredDeviceObjects.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    val transferHistory = database.transferHistoryDao().getAllHistory()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.MINUTES) // support massive files
        .writeTimeout(120, TimeUnit.MINUTES)
        .build()

    fun startServer(context: Context) {
        if (_isServerRunning.value) return

        val ip = getLocalWifiIpAddress(context) ?: "127.0.0.1"

        val serverInstance = WifiTransferServer(
            context = context,
            port = 8080,
            onConnectionRequest = { ipAddress, code, onResponse ->
                _connectionRequest.value = ConnectionRequest(
                    deviceIp = ipAddress,
                    deviceName = "Remote Device (IP: $ipAddress)",
                    sessionCode = code,
                    onResponse = { approved ->
                        onResponse(approved)
                        _connectionRequest.value = null
                    }
                )
            },
            onTransferUpdated = { transfer ->
                val currentList = _activeTransfers.value.toMutableList()
                val index = currentList.indexOfFirst { it.id == transfer.id }
                if (index != -1) {
                    currentList[index] = transfer
                } else {
                    currentList.add(transfer)
                }
                _activeTransfers.value = currentList
            },
            onTransferSaved = { name, size, isIncoming, success ->
                repositoryScope.launch {
                    val statusStr = if (success) "Completed" else "Cancelled/Failed"
                    database.transferHistoryDao().insertHistory(
                        TransferHistoryEntity(
                            fileName = name,
                            fileSize = size,
                            deviceName = if (isIncoming) "Web Client" else "Device",
                            status = statusStr,
                            isIncoming = isIncoming
                        )
                    )
                }
            }
        )

        server = serverInstance
        val actualPort = serverInstance.start()
        _serverIp.value = ip
        _serverPort.value = if (actualPort > 0) actualPort else 8080
        _sessionCode.value = serverInstance.sessionCode
        _isServerRunning.value = true
        Timber.d("WifiTransferRepository: Server started at http://$ip:${_serverPort.value} code: ${_sessionCode.value}")
    }

    fun stopServer() {
        if (!_isServerRunning.value) return
        server?.stop()
        server = null
        _isServerRunning.value = false
        _serverIp.value = null
        _sessionCode.value = null
        _connectionRequest.value = null
        _activeTransfers.value = emptyList()
        Timber.d("WifiTransferRepository: Server stopped")
    }

    fun approveConnection(approved: Boolean) {
        val request = _connectionRequest.value
        if (request != null) {
            request.onResponse(approved)
        }
    }

    fun cancelTransfer(id: String) {
        server?.cancelTransfer(id)
        // Also cancel native client sends
        val currentList = _activeTransfers.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == id }
        if (index != -1) {
            currentList[index] = currentList[index].copy(status = TransferStatus.CANCELLED)
            _activeTransfers.value = currentList
        }
    }

    suspend fun clearHistory() {
        database.transferHistoryDao().clearHistory()
    }

    // Android-to-Android native sender implementation
    suspend fun sendFilesNatively(
        targetIp: String,
        targetPort: Int,
        files: List<File>,
        targetSessionCode: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // 1. Send auth code request to target server
            val authUrl = "http://$targetIp:$targetPort/api/auth?code=$targetSessionCode"
            val authRequest = Request.Builder()
                .url(authUrl)
                .addHeader("X-Session-Code", targetSessionCode)
                .post(RequestBody.create(null, ByteArray(0)))
                .build()

            val authResponse = okHttpClient.newCall(authRequest).execute()
            if (!authResponse.isSuccessful) {
                return@withContext Result.failure(Exception("Rejected by remote device: ${authResponse.message}"))
            }

            val authBody = authResponse.body?.string() ?: ""
            var approved = authBody.contains("\"status\":\"approved\"")

            // If not immediately approved, poll briefly (up to 6s)
            if (!approved) {
                for (i in 1..4) {
                    delay(1500)
                    val statusUrl = "http://$targetIp:$targetPort/api/auth/status"
                    val statusRequest = Request.Builder().url(statusUrl).build()
                    val statusResponse = okHttpClient.newCall(statusRequest).execute()
                    if (statusResponse.isSuccessful) {
                        val body = statusResponse.body?.string() ?: ""
                        if (body.contains("\"status\":\"approved\"")) {
                            approved = true
                            break
                        }
                    }
                }
            }

            if (!approved) {
                return@withContext Result.failure(Exception("Connection approval timed out or declined."))
            }

            // 3. Upload files sequentially
            for (file in files) {
                val uploadUrl = "http://$targetIp:$targetPort/api/upload?filename=${java.net.URLEncoder.encode(file.name, "UTF-8")}&code=$targetSessionCode"
                val transferId = file.absolutePath

                val activeTransfer = ActiveTransfer(
                    id = transferId,
                    fileName = file.name,
                    fileSize = file.length(),
                    bytesTransferred = 0L,
                    isIncoming = false,
                    status = TransferStatus.IN_PROGRESS
                )
                updateActiveTransfer(activeTransfer)

                val customRequestBody = object : RequestBody() {
                    override fun contentType(): MediaType? = "application/octet-stream".toMediaTypeOrNull()
                    override fun contentLength(): Long = file.length()
                    override fun writeTo(sink: BufferedSink) {
                        val input = java.io.BufferedInputStream(FileInputStream(file), 1024 * 1024)
                        val buffer = ByteArray(1024 * 1024)
                        var bytesRead: Int
                        var totalBytesWritten = 0L
                        var lastUpdate = System.currentTimeMillis()
                        var lastBytes = 0L

                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            sink.write(buffer, 0, bytesRead)
                            totalBytesWritten += bytesRead

                            val now = System.currentTimeMillis()
                            if (now - lastUpdate >= 200) {
                                val speed = ((totalBytesWritten - lastBytes) * 1000) / (now - lastUpdate)
                                val eta = if (speed > 0) (file.length() - totalBytesWritten) / speed else 0L

                                updateActiveTransfer(
                                    activeTransfer.copy(
                                        bytesTransferred = totalBytesWritten,
                                        speedBytesPerSecond = speed,
                                        remainingTimeSeconds = eta
                                    )
                                )
                                lastUpdate = now
                                lastBytes = totalBytesWritten
                            }
                        }
                        input.close()
                    }
                }

                val uploadRequest = Request.Builder()
                    .url(uploadUrl)
                    .addHeader("X-Session-Code", targetSessionCode)
                    .addHeader("Content-Length", file.length().toString())
                    .post(customRequestBody)
                    .build()

                try {
                    val uploadResponse = okHttpClient.newCall(uploadRequest).execute()
                    if (uploadResponse.isSuccessful) {
                        updateActiveTransfer(activeTransfer.copy(bytesTransferred = file.length(), status = TransferStatus.SUCCESS))
                        database.transferHistoryDao().insertHistory(
                            TransferHistoryEntity(
                                fileName = file.name,
                                fileSize = file.length(),
                                deviceName = "Android Peer ($targetIp)",
                                status = "Completed",
                                isIncoming = false
                            )
                        )
                    } else {
                        throw Exception("Server returned error: ${uploadResponse.code}")
                    }
                } catch (e: Exception) {
                    updateActiveTransfer(activeTransfer.copy(status = TransferStatus.FAILED))
                    database.transferHistoryDao().insertHistory(
                        TransferHistoryEntity(
                            fileName = file.name,
                            fileSize = file.length(),
                            deviceName = "Android Peer ($targetIp)",
                            status = "Failed",
                            isIncoming = false
                        )
                    )
                    return@withContext Result.failure(e)
                }
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun updateActiveTransfer(transfer: ActiveTransfer) {
        val currentList = _activeTransfers.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == transfer.id }
        if (index != -1) {
            currentList[index] = transfer
        } else {
            currentList.add(transfer)
        }
        _activeTransfers.value = currentList
    }

    private var udpListenerJob: Job? = null

    fun startUdpDiscoveryListener(context: Context) {
        if (udpListenerJob?.isActive == true) return
        udpListenerJob = repositoryScope.launch(Dispatchers.IO) {
            var socket: java.net.DatagramSocket? = null
            try {
                socket = java.net.DatagramSocket(null).apply {
                    reuseAddress = true
                    bind(java.net.InetSocketAddress(8888))
                    broadcast = true
                }
                val buffer = ByteArray(1024)
                val packet = java.net.DatagramPacket(buffer, buffer.size)
                val localIp = getLocalWifiIpAddress(context) ?: "127.0.0.1"

                while (isActive) {
                    try {
                        socket.receive(packet)
                        val senderIp = packet.address?.hostAddress ?: continue
                        if (senderIp == localIp || senderIp == "127.0.0.1") continue

                        val message = String(packet.data, 0, packet.length, Charsets.UTF_8)
                        if (message.startsWith("VIDIOPEN_BEACON|")) {
                            val parts = message.split("|")
                            if (parts.size >= 6) {
                                val code = parts[1]
                                // CRITICAL: Skip discovering this device itself!
                                val myCode = _sessionCode.value
                                if (myCode != null && code == myCode) continue

                                val port = parts[2].toIntOrNull() ?: 8080
                                val devName = parts[3]
                                val model = parts[4]
                                val devId = parts[5]

                                val discovered = DiscoveredDevice(
                                    ip = senderIp,
                                    deviceName = devName,
                                    deviceModel = model,
                                    deviceId = devId,
                                    sessionCode = code,
                                    port = port
                                )

                                val current = _discoveredDeviceObjects.value.toMutableList()
                                val idx = current.indexOfFirst { it.ip == senderIp }
                                if (idx != -1) {
                                    current[idx] = discovered
                                } else {
                                    current.add(discovered)
                                }
                                _discoveredDeviceObjects.value = current
                                _discoveredDevices.value = current.map { it.ip }
                            }
                        }
                    } catch (e: Exception) {
                        if (!isActive) break
                        delay(300)
                    }
                }
            } catch (e: Exception) {
                Timber.w("UDP listener on port 8888 note: ${e.message}")
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }
    }

    fun scanForDevices(context: Context) {
        if (_isScanning.value) return
        _isScanning.value = true

        startUdpDiscoveryListener(context)

        repositoryScope.launch {
            try {
                val localIp = getLocalWifiIpAddress(context) ?: "127.0.0.1"
                if (localIp == "127.0.0.1" || localIp == "0.0.0.0") {
                    _isScanning.value = false
                    return@launch
                }

                val prefix = localIp.substringBeforeLast(".") + "."
                val allDiscovered = _discoveredDeviceObjects.value.toMutableList()
                val myCode = _sessionCode.value

                // Scan in parallel batches of 32 sockets for fast subnet detection
                val ipBatches = (1..254).toList().chunked(32)

                for (batch in ipBatches) {
                    val jobs = batch.mapNotNull { i ->
                        val targetIp = "$prefix$i"
                        if (targetIp == localIp) return@mapNotNull null
                        async(Dispatchers.IO) {
                            var socket: java.net.Socket? = null
                            try {
                                socket = java.net.Socket()
                                socket.connect(java.net.InetSocketAddress(targetIp, 8080), 250)
                                socket.close()
                                socket = null

                                var devName = "Vidiopen Receiver"
                                var devModel = "Direct Device"
                                var devId = "VDP-${kotlin.math.abs(targetIp.hashCode()) % 9000 + 1000}"
                                var sessCode = "1234"
                                var targetPort = 8080

                                try {
                                    val request = Request.Builder()
                                        .url("http://$targetIp:8080/api/info")
                                        .get()
                                        .build()
                                    val response = okHttpClient.newCall(request).execute()
                                    if (response.isSuccessful) {
                                        val body = response.body?.string() ?: ""
                                        if (body.contains("\"app\":\"vidiopen\"") || body.contains("vidiopen")) {
                                            val nameMatch = Regex("\"name\":\"([^\"]+)\"").find(body)
                                            val modelMatch = Regex("\"model\":\"([^\"]+)\"").find(body)
                                            val idMatch = Regex("\"deviceId\":\"([^\"]+)\"").find(body)
                                            val codeMatch = Regex("\"code\":\"([^\"]+)\"").find(body)
                                            val portMatch = Regex("\"port\":([0-9]+)").find(body)

                                            if (nameMatch != null) devName = nameMatch.groupValues[1]
                                            if (modelMatch != null) devModel = modelMatch.groupValues[1]
                                            if (idMatch != null) devId = idMatch.groupValues[1]
                                            if (codeMatch != null) sessCode = codeMatch.groupValues[1]
                                            if (portMatch != null) targetPort = portMatch.groupValues[1].toIntOrNull() ?: 8080
                                        }
                                    }
                                } catch (_: Exception) {}

                                // Never list self
                                if (myCode != null && sessCode == myCode) return@async null

                                DiscoveredDevice(
                                    ip = targetIp,
                                    deviceName = devName,
                                    deviceModel = devModel,
                                    deviceId = devId,
                                    sessionCode = sessCode,
                                    port = targetPort
                                )
                            } catch (_: Exception) {
                                null
                            } finally {
                                try { socket?.close() } catch (_: Exception) {}
                            }
                        }
                    }
                    val batchResults = jobs.awaitAll().filterNotNull()
                    if (batchResults.isNotEmpty()) {
                        for (item in batchResults) {
                            if (myCode != null && item.sessionCode == myCode) continue
                            if (allDiscovered.none { it.ip == item.ip }) {
                                allDiscovered.add(item)
                            }
                        }
                        _discoveredDevices.value = allDiscovered.map { it.ip }
                        _discoveredDeviceObjects.value = allDiscovered.toList()
                    }
                }

                _discoveredDevices.value = allDiscovered.map { it.ip }
                _discoveredDeviceObjects.value = allDiscovered.toList()
            } catch (e: Exception) {
                Timber.e(e, "Error scanning local subnet")
            } finally {
                _isScanning.value = false
            }
        }
    }

    suspend fun findDeviceByCode(context: Context, code: String): DiscoveredDevice? = withContext(Dispatchers.IO) {
        val cleanCode = code.trim()
        if (cleanCode.length != 6) return@withContext null

        // 1. Check already discovered devices
        val existing = _discoveredDeviceObjects.value.find { it.sessionCode == cleanCode }
        if (existing != null) return@withContext existing

        // 2. Start UDP listener & wait briefly for beacon
        startUdpDiscoveryListener(context)
        for (i in 1..4) {
            delay(150)
            val found = _discoveredDeviceObjects.value.find { it.sessionCode == cleanCode }
            if (found != null) return@withContext found
        }

        // 3. Scan local network quickly to locate this specific 6-digit code
        val localIp = getLocalWifiIpAddress(context) ?: "127.0.0.1"
        if (localIp == "127.0.0.1" || localIp == "0.0.0.0") {
            return@withContext null
        }

        val prefix = localIp.substringBeforeLast(".") + "."
        val ipBatches = (1..254).toList().chunked(32)

        for (batch in ipBatches) {
            val jobs = batch.mapNotNull { i ->
                val targetIp = "$prefix$i"
                if (targetIp == localIp) return@mapNotNull null
                async(Dispatchers.IO) {
                    var socket: java.net.Socket? = null
                    try {
                        socket = java.net.Socket()
                        socket.connect(java.net.InetSocketAddress(targetIp, 8080), 250)
                        socket.close()
                        socket = null

                        val request = Request.Builder()
                            .url("http://$targetIp:8080/api/info")
                            .get()
                            .build()
                        val response = okHttpClient.newCall(request).execute()
                        if (response.isSuccessful) {
                            val body = response.body?.string() ?: ""
                            if (body.contains("\"code\":\"$cleanCode\"")) {
                                val nameMatch = Regex("\"name\":\"([^\"]+)\"").find(body)
                                val modelMatch = Regex("\"model\":\"([^\"]+)\"").find(body)
                                val idMatch = Regex("\"deviceId\":\"([^\"]+)\"").find(body)
                                val portMatch = Regex("\"port\":([0-9]+)").find(body)
                                val devPort = portMatch?.groupValues?.get(1)?.toIntOrNull() ?: 8080

                                return@async DiscoveredDevice(
                                    ip = targetIp,
                                    deviceName = nameMatch?.groupValues?.get(1) ?: "Vidiopen Device",
                                    deviceModel = modelMatch?.groupValues?.get(1) ?: "Phone",
                                    deviceId = idMatch?.groupValues?.get(1) ?: "VDP-$cleanCode",
                                    sessionCode = cleanCode,
                                    port = devPort
                                )
                            }
                        }
                    } catch (_: Exception) {
                    } finally {
                        try { socket?.close() } catch (_: Exception) {}
                    }
                    null
                }
            }
            val match = jobs.awaitAll().filterNotNull().firstOrNull()
            if (match != null) {
                val current = _discoveredDeviceObjects.value.toMutableList()
                if (current.none { it.ip == match.ip }) {
                    current.add(match)
                    _discoveredDeviceObjects.value = current
                }
                return@withContext match
            }
        }

        null
    }

    private fun getLocalWifiIpAddress(context: Context): String? {
        // Method 1: ConnectivityManager (Recommended for modern Android)
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
            val activeNetwork = cm?.activeNetwork
            if (activeNetwork != null) {
                val linkProperties = cm.getLinkProperties(activeNetwork)
                val linkAddrs = linkProperties?.linkAddresses
                if (linkAddrs != null) {
                    for (linkAddr in linkAddrs) {
                        val addr = linkAddr.address
                        if (addr is Inet4Address && !addr.isLoopbackAddress) {
                            val host = addr.hostAddress
                            if (!host.isNullOrEmpty() && host != "127.0.0.1") {
                                return host
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "ConnectivityManager IP resolution bypassed")
        }

        // Method 2: Active NetworkInterfaces (supports Hotspot/AP & Wi-Fi)
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            val preferredIps = mutableListOf<String>()
            val fallbackIps = mutableListOf<String>()

            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (!networkInterface.isUp || networkInterface.isLoopback) continue
                val name = networkInterface.name.lowercase(Locale.ROOT)
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        val host = address.hostAddress ?: continue
                        if (host == "127.0.0.1") continue
                        if (name.contains("wlan") || name.contains("ap") || name.contains("p2p") ||
                            name.contains("swlan") || name.contains("softap") || name.contains("tether")) {
                            preferredIps.add(host)
                        } else {
                            fallbackIps.add(host)
                        }
                    }
                }
            }

            if (preferredIps.isNotEmpty()) return preferredIps.first()
            if (fallbackIps.isNotEmpty()) return fallbackIps.first()
        } catch (e: Exception) {
            Timber.e(e, "Error getting IP address from NetworkInterface")
        }

        // Method 3: WifiManager fallback
        try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val ipAddress = wm?.connectionInfo?.ipAddress ?: 0
            if (ipAddress != 0) {
                val ip = String.format(
                    Locale.US,
                    "%d.%d.%d.%d",
                    ipAddress and 0xff,
                    ipAddress shr 8 and 0xff,
                    ipAddress shr 16 and 0xff,
                    ipAddress shr 24 and 0xff
                )
                if (ip != "0.0.0.0" && ip != "127.0.0.1") return ip
            }
        } catch (_: Exception) {}

        return null
    }
}
